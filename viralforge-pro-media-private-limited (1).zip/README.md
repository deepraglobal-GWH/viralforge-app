# 🚀 VIRAL CLOUD FACTORY (v5.0.0-SIMPLE)

Professional AI Content Domination Engine for YouTube Shorts, Instagram Reels, and Facebook Reels.

## 🌟 Overview
This system is a production-grade automated content factory designed to generate, synthesize, and distribute high-fidelity viral videos at scale (50-100 videos/day).

### Key Features:
- **Neural Intelligence**: Analyzes trends and plans strategic content swarms.
- **FFmpeg Production**: Heavy-duty vertical video synthesis with dynamic captions and "DEEPRA | MEDIA" branding.
- **Auto-Pilot (Auto-Upload)**: Zero-touch automation for synthesis and distribution.
- **Multi-Platform Support**: YouTube (Direct API), Facebook (Direct API), and Instagram (Orchestration Chain).
- **Anti-Repetition**: Dynamic asset rotation to bypass platform spam filters.

---

## 🛠 Setup & Environment Variables

You MUST configure the following env variables for the system to operate:

### 🔑 Core Keys
- `GEMINI_API_KEY`: Google Gemini API for the script engine.
- `ADMIN_FIREBASE_UID`: The authoritative Firebase UID for data persistence.

### 📡 Platform Credentials
- `YOUTUBE_API_KEY`: OAuth2 token for YouTube Data API.
- `FB_ACCESS_TOKEN`: Page access token for Facebook Graph API.
- `FB_PAGE_ID`: Your Facebook Page ID.
- `IG_ACCESS_TOKEN`: Instagram Graph API token.
- `IG_USER_ID`: Your Instagram Business Account ID.

### ⚙️ Engine Tuning
- `AUTO_UPLOAD`: Set to `true` for full automation.
- `CHECK_SCORE`: (0-100) Minimum quality score for auto-release.
- `GAP_TIME`: Milliseconds between video cycles (Default: 300000 / 5 mins).
- `RETRY_LIMIT`: Max retries for failed network operations.
- `POST_DELAY`: Milliseconds to wait after video creation before uploading.

---

## 🏃 Execution

1. **Install Dependencies**:
   ```bash
   npm install
   ```

2. **Start the Domination Engine**:
   ```bash
   npm run dev
   ```

3. **Production Build**:
   ```bash
   npm run build
   ```

---

## 📂 Project Structure
- `/src/factory/core`: Configuration, Intelligence, and Stability layers.
- `/src/factory/brain`: AI Script and Trend generation.
- `/src/factory/production`: FFmpeg Orchestration and Asset Library.
- `/src/factory/distribution`: Multi-channel upload logic (YT, FB, IG).
- `/src/factory/data`: Firebase Admin persistence.
- `/src/components`: The Domination Dashboard UI.

---

## 🛡 Stability & Security
- **Auto-Cleanup**: Automatically purges old video files to prevent disk crash.
- **Self-Healing**: Implements retry logic and stability guards for all API calls.
- **Encrypted Storage**: Sensitive data is stored in the `_encryption_vault` within Firebase.

**Maintained by DEEPRA | MEDIA**
