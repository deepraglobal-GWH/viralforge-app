# Security Specification for ViralForge Pro

## 1. Data Invariants
- All documents (Projects, Logs, Earnings, Configs, Assets) MUST belong to a valid User document.
- Only the authenticated owner of the `userId` prefix can read or write data under `/users/{userId}/`.
- Timestamps (`createdAt`, `updatedAt`) must be server-generated.
- Brand names, platform names, and statuses must follow strict enum values or string formats.
- Metrics must be non-negative numbers.

## 2. The "Dirty Dozen" Payloads (Denial Tests)
1. **Identity Theft**: Attempt to create a project under `user_A`'s ID while authenticated as `user_B`.
2. **Path Poisoning**: Create an asset with a document ID that is a 2MB base64 string.
3. **Enum Bypass**: Set `Asset.platform` to "tiktok" (not in allowed enum: youtube, instagram, facebook).
4. **Metric Forgery**: Set `metrics.views` to `-1`.
5. **Timestamp Manual Set**: Try to set `createdAt` to a date in the past instead of `request.time`.
6. **Shadow Field Injection**: Create a `User` profile with an extra `isAdmin: true` field not in schema.
7. **Cross-User Leak**: Authenticated user trying to query `/users/another_user/projects`.
8. **Invalid ID Format**: Create a project with special characters in ID (e.g., `proj!!!`).
9. **Large String Attack**: Set `Project.topic` to a 500KB string (beyond 500 char limit).
10. **Unverified Email**: Attempt to write data with an unverified email account (when `request.auth.token.email_verified == false`).
11. **Negative Earnings**: Create an `Earning` record with `amount: -100`.
12. **Status Skipping**: Update a `Project` status from 'draft' to 'completed' without the intermediary steps (if applicable, though here we prioritize field-level locking).

## 3. Test Runner Strategy
We will use `firestore.rules.test.ts` to assert that:
- `get`, `list`, `create`, `update`, `delete` all fail if `userId != request.auth.uid`.
- Creation fails if schema validation (`isValid[Entity]`) is violated.
- Updates fail if immutable fields (like `brandName` or `platform` in existing Assets) are changed erroneously or if `hasOnly` is violated.
