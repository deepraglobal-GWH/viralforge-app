/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { BrandDashboard } from './components/BrandDashboard';
import { WarRoom } from './lib/WarRoom';
import { UploadCenter } from './components/UploadCenter';
import { Earnings } from './components/Earnings';
import { motion, AnimatePresence } from 'framer-motion';
import { auth, db, googleProvider } from './lib/firebase';
import { handleFirestoreError, OperationType } from './services/error-handler';
import { onAuthStateChanged, User, signInWithPopup } from 'firebase/auth';
import { doc, setDoc, serverTimestamp, collection, query, orderBy, onSnapshot, limit } from 'firebase/firestore';
import { Video, Zap, ArrowRight, ShieldAlert, Bell, Loader2, Sparkles } from 'lucide-react';
import { cn } from './lib/utils';

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);

  useEffect(() => {
    if (!user) return;
    const q = query(
      collection(db, 'users', user.uid, 'notifications'),
      orderBy('timestamp', 'desc'),
      limit(5)
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setNotifications(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });
    return () => unsubscribe();
  }, [user]);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setUser(user);
      setLoading(false);
      if (user) {
        // Sync user to Firestore
        try {
          await setDoc(doc(db, 'users', user.uid), {
            uid: user.uid,
            email: user.email,
            displayName: user.displayName,
            photoURL: user.photoURL,
            lastLogin: serverTimestamp()
          }, { merge: true });
        } catch (error) {
          handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}`);
        }
      }
    });
    return () => unsubscribe();
  }, []);

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error("Login Error:", error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-primary flex items-center justify-center">
        <div className="flex flex-col items-center">
          <Loader2 className="w-12 h-12 text-accent animate-spin mb-4" />
          <p className="text-zinc-500 font-bold uppercase tracking-[0.3em] text-[10px]">Initializing Engine</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-primary flex items-center justify-center p-6 relative overflow-hidden">
        {/* Subtle Background Glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-accent/10 blur-[150px] rounded-full pointer-events-none" />

        <div className="max-w-xl w-full text-center space-y-12 relative z-10">
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="flex justify-center"
          >
            <div className="w-24 h-24 bg-zinc-900 border border-white/10 rounded-[2rem] flex items-center justify-center shadow-2xl relative">
              <Zap className="text-accent w-12 h-12 fill-accent/10" />
              <div className="absolute inset-0 bg-accent/20 blur-2xl rounded-full -z-10 animate-pulse" />
            </div>
          </motion.div>

          <div className="space-y-4">
            <motion.h1 
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="text-7xl font-extrabold tracking-tighter text-white uppercase"
            >
              ViralForge Pro
            </motion.h1>
            <motion.p 
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.4 }}
              className="text-lg text-zinc-400 font-medium tracking-tight"
            >
              Autonomous 33-Brand 99-Asset Multi-Platform Factory.<br/>
              <span className="text-xs uppercase tracking-widest text-zinc-600 font-bold">DeePra Enterprises Media Private Limited</span>
            </motion.p>
          </div>

          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.6 }}
          >
            <button 
              onClick={handleLogin}
              className="w-full bg-accent text-white py-5 rounded-2xl font-bold text-lg hover:bg-accent/90 transition-all flex items-center justify-center gap-4 group shadow-xl shadow-accent/20 active:scale-95"
            >
              <Sparkles className="w-5 h-5" />
              Sign in with Google
              <ArrowRight className="w-5 h-5 group-hover:translate-x-2 transition-transform" />
            </button>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
            className="pt-16 border-t border-white/5 opacity-40"
          >
            <div className="flex justify-center gap-12 mb-6">
              <div className="flex items-center gap-2 text-zinc-500 text-[10px] font-bold uppercase tracking-widest">
                <ShieldAlert className="w-3 h-3" /> Secure Access
              </div>
              <div className="flex items-center gap-2 text-zinc-500 text-[10px] font-bold uppercase tracking-widest">
                <Zap className="w-3 h-3" /> Real-time Nodes
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': return <Dashboard setActiveTab={setActiveTab} user={user} />;
      case 'brands': return <BrandDashboard />;
      case 'warroom': return <WarRoom />;
      case 'monetization': return <Earnings />;
      case 'settings': return <UploadCenter />;
      default: return <Dashboard setActiveTab={setActiveTab} user={user} />;
    }
  };

  return (
    <div className="flex h-screen bg-primary text-zinc-200 font-sans selection:bg-accent/30 selection:text-accent overflow-hidden">
      <Sidebar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        user={user} 
        onActivateMoneyMode={() => setActiveTab('monetization')}
      />
      
      <main className="flex-1 overflow-y-auto relative flex flex-col bg-primary custom-scrollbar">
        {/* Simple SaaS Header */}
        <header className="h-20 border-b border-white/5 flex items-center justify-between px-10 bg-primary/80 backdrop-blur-xl sticky top-0 z-50">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-zinc-500 uppercase tracking-[0.3em]">ViralForge Pro Media Pvt Ltd</span>
          </div>
          
          <div className="flex items-center gap-8">
            <div className="flex items-center gap-2.5 px-4 py-1.5 bg-accent/5 border border-accent/20 rounded-full">
               <div className="relative">
                  <div className="w-2 h-2 rounded-full bg-accent" />
                  <div className="absolute inset-0 w-2 h-2 rounded-full bg-accent animate-ping opacity-60" />
               </div>
               <span className="text-[10px] font-bold text-accent uppercase tracking-widest">System Operational</span>
            </div>

            <button 
              onClick={() => setShowNotifications(!showNotifications)}
              className={cn(
                "relative p-2.5 rounded-xl transition-all",
                showNotifications ? "bg-white/10 text-white" : "text-zinc-500 hover:text-white hover:bg-white/5"
              )}
            >
              <Bell className="w-5.5 h-5.5" />
              {notifications.some(n => !n.read) && (
                <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-accent rounded-full border-2 border-primary" />
              )}
            </button>

            <AnimatePresence>
              {showNotifications && (
                <motion.div 
                   initial={{ opacity: 0, y: 15, scale: 0.95 }}
                   animate={{ opacity: 1, y: 0, scale: 1 }}
                   exit={{ opacity: 0, y: 15, scale: 0.95 }}
                   className="absolute top-16 right-0 w-96 saas-card z-[100] p-6 shadow-2xl mr-4"
                >
                  <div className="flex items-center justify-between mb-6">
                    <h4 className="text-[11px] font-bold text-zinc-500 uppercase tracking-widest">System Signal History</h4>
                    <span className="text-[9px] text-zinc-700 uppercase tracking-widest">Last 5 Events</span>
                  </div>
                  <div className="space-y-2 max-h-80 overflow-y-auto custom-scrollbar">
                    {notifications.length > 0 ? (
                      notifications.map((n) => (
                        <div key={n.id} className="p-4 bg-zinc-800/40 rounded-xl border border-white/5 hover:border-white/10 transition-colors">
                          <p className="text-[12px] text-zinc-300 leading-relaxed font-medium">{n.message}</p>
                          <span className="text-[9px] text-zinc-600 block mt-2 uppercase font-bold tracking-widest">{new Date(n.timestamp?.toDate ? n.timestamp.toDate() : n.timestamp).toLocaleTimeString()}</span>
                        </div>
                      ))
                    ) : (
                      <div className="py-12 text-center text-zinc-700">
                        <p className="text-[10px] uppercase tracking-widest font-bold">No active signals found</p>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </header>

        <div className="p-10 lg:p-16 w-full">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              {renderContent()}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}
