import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  ShieldAlert, 
  Activity, 
  Terminal, 
  Cpu, 
  Globe, 
  Zap, 
  AlertTriangle,
  CheckCircle2,
  Clock,
  Search,
  Eye,
  BrainCircuit,
  Loader2
} from 'lucide-react';
import { cn } from './utils';
import { db, auth } from './firebase';
import { collection, query, orderBy, limit, onSnapshot, doc, where } from 'firebase/firestore';
import { orchestrator } from '../services/bridge';

interface LogEntry {
  id: string;
  timestamp: any;
  agent: string;
  action: string;
  status: 'info' | 'success' | 'warning' | 'error';
}

export function WarRoom() {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [activeAgents, setActiveAgents] = useState(5);
  const [systemHealth, setSystemHealth] = useState(100);
  const [learningInsights, setLearningInsights] = useState<any>(null);
  const [currentSwarm, setCurrentSwarm] = useState<any>(null);
  const [isSimulating, setIsSimulating] = useState(false);
  const [isContinuous, setIsContinuous] = useState(false);
  const [queue, setQueue] = useState<any[]>([]);

  useEffect(() => {
    const interval = setInterval(() => {
      setQueue([...orchestrator.getQueue()]);
    }, 2000);
    return () => clearInterval(interval);
  }, []);
  const [stats, setStats] = useState({
    projects: 0,
    reach: '0',
    threat: 'Low'
  });

  useEffect(() => {
    if (!auth.currentUser) return;

    // 1. Real-time Logs
    const qLogs = query(
      collection(db, 'users', auth.currentUser.uid, 'logs'),
      orderBy('timestamp', 'desc'),
      limit(15)
    );

    const unsubscribeLogs = onSnapshot(qLogs, (snapshot) => {
      const logsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as LogEntry[];
      setLogs(logsData);
    });

    // 2. Real-time Self-Learning Insights
    const unsubscribeLearning = onSnapshot(doc(db, 'users', auth.currentUser.uid, 'config', 'self_learning'), (doc) => {
      if (doc.exists()) {
        setLearningInsights(doc.data());
      }
    });

    // 3. Real-time Project Stats & Current Swarm Data
    const qProjects = query(
      collection(db, 'users', auth.currentUser.uid, 'projects'),
      orderBy('createdAt', 'desc'),
      limit(1)
    );
    
    const unsubscribeProjects = onSnapshot(qProjects, (snapshot) => {
      if (!snapshot.empty) {
        const latest = snapshot.docs[0].data();
        if (latest.swarmData) {
          setCurrentSwarm(latest.swarmData);
        }
      }
      
      setStats(prev => ({
        ...prev,
        projects: snapshot.size > 0 ? prev.projects + 1 : prev.projects,
        reach: (prev.projects * 12.5).toFixed(1) + 'K'
      }));
    });

    return () => {
      unsubscribeLogs();
      unsubscribeLearning();
      unsubscribeProjects();
    };
  }, []);

  const handleResimulate = async () => {
    setIsSimulating(true);
    try {
      await orchestrator.startFullAutoPipeline('AI Technology');
    } catch (e) {
      console.error(e);
    } finally {
      setIsSimulating(false);
    }
  };

  const toggleContinuous = () => {
    if (isContinuous) {
      orchestrator.stopContinuousEngine();
      setIsContinuous(false);
    } else {
      orchestrator.startContinuousEngine('AI Technology');
      setIsContinuous(true);
    }
  };

  const formatTime = (timestamp: any) => {
    if (!timestamp) return '--:--:--';
    const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
    return date.toLocaleTimeString([], { hour12: false });
  };

  return (
    <div className="space-y-12 relative z-10 pb-20">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8">
        <div>
          <div className="flex items-center gap-3 mb-4">
            <div className="px-2 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded text-[10px] font-mono text-emerald-500 uppercase tracking-widest animate-pulse">Monitoring Active</div>
          </div>
          <h2 className="text-5xl font-display text-white uppercase tracking-tighter">Activity Logs</h2>
          <p className="text-zinc-500 font-mono text-xs uppercase tracking-[0.2em] mt-2">Real-time task and progress logs</p>
        </div>
        
        <div className="flex flex-wrap items-center gap-6">
          <button
            onClick={toggleContinuous}
            className={cn(
              "px-10 py-5 rounded-2xl font-bold transition-all active:scale-95 flex items-center gap-3 shadow-2xl uppercase tracking-widest text-sm",
              isContinuous 
                ? "bg-emerald-600 text-white shadow-emerald-600/20" 
                : "bg-zinc-900/50 border border-white/5 text-zinc-500 hover:text-white"
            )}
          >
            <Activity className={cn("w-5 h-5", isContinuous && "animate-pulse")} />
            {isContinuous ? 'Continuous: ON' : 'Start Engine'}
          </button>
          <button 
            onClick={handleResimulate}
            disabled={isSimulating}
            className="bg-white text-black px-10 py-5 rounded-2xl font-bold hover:bg-zinc-200 transition-all active:scale-95 flex items-center gap-3 disabled:opacity-50 shadow-2xl shadow-white/10 uppercase tracking-widest text-sm"
          >
            {isSimulating ? <Loader2 className="w-5 h-5 animate-spin" /> : <Zap className="w-5 h-5 text-emerald-500 fill-emerald-500" />}
            {isSimulating ? 'Restarting...' : 'Reboot All'}
          </button>
          
          <div className="bg-zinc-900/50 border border-white/5 px-6 py-4 rounded-2xl flex items-center gap-5 hardware-border">
            <div className="flex flex-col items-end">
              <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">System Health</span>
              <span className="text-emerald-500 font-mono font-bold text-lg">{systemHealth}%</span>
            </div>
            <div className="w-12 h-12 bg-emerald-500/10 rounded-xl flex items-center justify-center border border-emerald-500/20">
              <Activity className="text-emerald-500 w-6 h-6 animate-pulse" />
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {[
          { label: 'Network Nodes', value: activeAgents, icon: Cpu, color: 'text-emerald-500' },
          { label: 'Active Jobs', value: stats.projects, icon: Zap, color: 'text-omega-gold' },
          { label: 'Global Reach', value: stats.reach, icon: Globe, color: 'text-emerald-500' },
          { label: 'Risk Factor', value: stats.threat, icon: ShieldAlert, color: 'text-red-500' },
        ].map((stat, i) => (
          <div key={i} className="glass-card p-8 relative overflow-hidden group hover:border-white/20 transition-all">
            <div className="absolute top-0 right-0 p-6 opacity-5 group-hover:opacity-10 transition-opacity pointer-events-none">
              <stat.icon className="w-24 h-24" />
            </div>
            <div className="flex items-center gap-4 mb-4">
              <div className={cn("p-2 rounded-lg bg-white/5 border border-white/5", stat.color)}>
                <stat.icon className="w-5 h-5" />
              </div>
              <span className="text-zinc-500 text-[10px] font-mono uppercase tracking-widest">{stat.label}</span>
            </div>
            <p className="text-4xl font-display text-white uppercase tracking-tight">{stat.value}</p>
          </div>
        ))}
      </div>

      {/* Engagement Network Visual */}
      <div className="glass-card p-8 border-omega-gold/10 overflow-hidden relative">
        <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/5 via-transparent to-omega-gold/5 pointer-events-none" />
        <div className="flex items-center justify-between mb-8 relative z-10">
          <div>
            <h3 className="text-xl font-display text-white uppercase tracking-tight">Brand Neural Matrix</h3>
            <p className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Autonomous Heartbeat: 33 Pillars / 99 Assets</p>
          </div>
          <div className="flex items-center gap-4 text-[9px] font-mono uppercase tracking-widest">
            <div className="flex items-center gap-2"><span className="w-2 h-2 bg-emerald-500 rounded-full" /> Synchronized</div>
            <div className="flex items-center gap-2"><span className="w-2 h-2 bg-omega-gold rounded-full animate-pulse" /> Optimizing</div>
            <div className="flex items-center gap-2"><span className="w-2 h-2 bg-zinc-800 rounded-full" /> Standby</div>
          </div>
        </div>
        
        <div className="grid grid-cols-11 md:grid-cols-33 gap-1 relative z-10">
          {Array.from({ length: 33 }).map((_, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0.1 }}
              animate={{ 
                opacity: [0.1, 0.8, 0.1],
                backgroundColor: i % 3 === 0 ? '#fbbf24' : '#10b981'
              }}
              transition={{ 
                duration: 2 + (i % 5),
                repeat: Infinity,
                delay: i * 0.1
              }}
              title={`Brand Node #${i+1}`}
              className="aspect-square rounded-full border border-white/5 relative group cursor-help"
            >
               <div className="absolute -inset-2 bg-emerald-500/20 rounded-full blur-xl opacity-0 group-hover:opacity-100 transition-opacity" />
            </motion.div>
          ))}
        </div>
      </div>

      {/* Live Operations Queue */}
      {queue.length > 0 && (
        <div className="mb-12">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-2 h-2 bg-omega-infinity rounded-full animate-pulse" />
            <h3 className="text-xl font-display text-white uppercase tracking-tight">Live Operations Queue</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {queue.map((task) => (
              <div key={task.id} className="glass-card p-6 border-white/5">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">{task.type}</span>
                  <div className={cn(
                    "px-2 py-0.5 rounded text-[8px] font-mono uppercase tracking-widest",
                    task.status === 'completed' ? "bg-emerald-500/10 text-emerald-500" :
                    task.status === 'processing' ? "bg-blue-500/10 text-blue-500 animate-pulse" :
                    task.status === 'pending_approval' ? "bg-omega-gold/10 text-omega-gold animate-pulse" :
                    task.status === 'failed' ? "bg-red-500/10 text-red-500" :
                    "bg-zinc-800 text-zinc-500"
                  )}>
                    {task.status.replace('_', ' ')}
                  </div>
                </div>
                <h4 className="text-white font-bold text-sm truncate mb-2">{task.payload.topic}</h4>
                <div className="w-full bg-zinc-900 h-1 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: task.status === 'completed' ? '100%' : (task.status === 'processing' || task.status === 'pending_approval') ? '60%' : '0%' }}
                    className={cn(
                      "h-full",
                      task.status === 'completed' ? "bg-emerald-500" : "bg-blue-500"
                    )}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        <div className="lg:col-span-2 space-y-8">
          <div className="glass-card overflow-hidden border-emerald-500/20">
            <div className="p-8 border-b border-white/5 flex items-center justify-between bg-white/5">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-emerald-500/10 rounded-xl flex items-center justify-center border border-emerald-500/20">
                  <Terminal className="text-emerald-500 w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-xl font-display text-white uppercase tracking-tight">System Logs</h3>
                  <p className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Real-time Activity</p>
                </div>
              </div>
              <div className="flex items-center gap-3 px-4 py-2 bg-black/40 rounded-full border border-white/5">
                <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.8)]" />
                <span className="text-[10px] font-mono text-emerald-500 uppercase tracking-widest">Live Feed</span>
              </div>
            </div>
            <div className="p-6 font-mono text-[11px] space-y-3 max-h-[600px] overflow-y-auto custom-scrollbar bg-black/20">
              {logs.length > 0 ? logs.map((log, i) => (
                <motion.div 
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.05 }}
                  key={log.id} 
                  className="flex items-start gap-6 p-3 hover:bg-white/5 rounded-xl transition-all group border border-transparent hover:border-white/5"
                >
                  <span className="text-zinc-600 shrink-0 font-mono">[{formatTime(log.timestamp)}]</span>
                  <span className={cn(
                    "font-bold shrink-0 w-28 uppercase tracking-tighter",
                    log.agent === 'CEO' || log.agent === 'Orchestrator' ? "text-emerald-500" : 
                    log.agent === 'System' ? "text-zinc-500" :
                    "text-omega-gold"
                  )}>
                    {log.agent === 'CEO' ? 'Orchestrator' : log.agent}
                  </span>
                  <span className="text-zinc-400 flex-1 leading-relaxed">{log.action}</span>
                  <div className={cn(
                    "text-[9px] font-mono uppercase px-3 py-1 rounded-full border",
                    log.status === 'success' ? "text-emerald-500 border-emerald-500/20 bg-emerald-500/5" :
                    log.status === 'warning' ? "text-omega-gold border-omega-gold/20 bg-omega-gold/5" :
                    log.status === 'error' ? "text-red-500 border-red-500/20 bg-red-500/5" :
                    "text-emerald-500 border-emerald-500/20 bg-emerald-500/5"
                  )}>
                    {log.status}
                  </div>
                </motion.div>
              )) : (
                <div className="flex flex-col items-center justify-center py-32 text-zinc-600 space-y-4">
                  <Terminal className="w-8 h-8 opacity-20" />
                  <p className="text-xs font-mono uppercase tracking-widest">No activity logs found</p>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="space-y-8">
          <div className="glass-card p-8 relative overflow-hidden border-omega-gold/20">
            <div className="absolute top-0 right-0 p-8 opacity-5 pointer-events-none">
              <BrainCircuit className="w-40 h-40 text-omega-gold" />
            </div>
            <div className="flex items-center gap-4 mb-8">
              <div className="w-12 h-12 bg-omega-gold/10 rounded-2xl flex items-center justify-center border border-omega-gold/20">
                <BrainCircuit className="text-omega-gold w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-display text-white uppercase tracking-tight">System Insights</h3>
                <p className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Growth Optimization Data</p>
              </div>
            </div>
            
            {learningInsights ? (
              <div className="space-y-8 relative z-10">
                <div className="space-y-4">
                  <p className="text-[10px] font-mono text-zinc-600 uppercase tracking-widest">Detected Patterns</p>
                  <div className="flex flex-wrap gap-2">
                    {learningInsights.topPatterns?.map((p: string, i: number) => (
                      <span key={i} className="px-3 py-1.5 bg-omega-blue/10 text-omega-blue text-[9px] font-mono uppercase tracking-widest rounded-lg border border-omega-blue/20">
                        {p}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="space-y-4">
                  <p className="text-[10px] font-mono text-zinc-600 uppercase tracking-widest">Strategic Evolution</p>
                  <div className="p-5 bg-white/5 rounded-2xl border border-white/5 italic text-zinc-400 text-xs leading-relaxed">
                    "{learningInsights.nextLevelStrategy}"
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-16 text-zinc-600 space-y-4">
                <Activity className="w-6 h-6 animate-pulse opacity-20" />
                <p className="text-[10px] font-mono uppercase tracking-widest italic">Analyzing Neural Patterns...</p>
              </div>
            )}
          </div>

          <div className="glass-card p-8 border-omega-emerald/20">
            <div className="flex items-center gap-4 mb-8">
              <div className="w-12 h-12 bg-omega-emerald/10 rounded-2xl flex items-center justify-center border border-omega-emerald/20">
                <Search className="text-omega-emerald w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-display text-white uppercase tracking-tight">Efficiency Engine</h3>
                <p className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Account Analysis</p>
              </div>
            </div>

            <div className="space-y-8">
              <div className="p-6 bg-black/40 border border-white/5 rounded-[2rem] hardware-border">
                <div className="flex justify-between items-center mb-6">
                  <span className="text-[10px] font-mono text-white uppercase tracking-widest">Performance Confidence</span>
                  <div className={cn(
                    "px-3 py-1 rounded-full text-[10px] font-mono border",
                    (currentSwarm?.analyst?.viralProbability || 0) > 70 ? "text-emerald-500 border-emerald-500/20 bg-emerald-500/5" : "text-omega-emerald border-omega-emerald/20 bg-omega-emerald/5"
                  )}>
                    {currentSwarm?.analyst?.viralProbability || 0}% ACCURACY
                  </div>
                </div>
                
                <div className="space-y-6">
                  <div>
                    <div className="flex justify-between text-[9px] text-zinc-500 uppercase font-mono mb-2 tracking-widest">
                      <span>Optimization Rate</span>
                      <span className="text-white">{currentSwarm?.analyst?.viralProbability || 0}%</span>
                    </div>
                    <div className="w-full bg-zinc-900 h-1 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${currentSwarm?.analyst?.viralProbability || 0}%` }}
                        transition={{ duration: 2 }}
                        className="bg-omega-emerald h-full shadow-[0_0_10px_rgba(16,185,129,0.5)]" 
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-white/5 p-4 rounded-2xl border border-white/5">
                      <p className="text-[8px] text-zinc-600 uppercase font-mono mb-1 tracking-widest">Yield Est.</p>
                      <p className="text-sm font-display text-white uppercase">{currentSwarm?.analyst?.ctrEstimate || '0.0%'}</p>
                    </div>
                    <div className="bg-white/5 p-4 rounded-2xl border border-white/5">
                      <p className="text-[8px] text-zinc-600 uppercase font-mono mb-1 tracking-widest">Tone</p>
                      <p className="text-sm font-display text-omega-emerald uppercase truncate">{currentSwarm?.emotion?.tone || 'Neural'}</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white/5 p-6 rounded-[2rem] border border-white/5">
                <p className="text-[10px] font-mono text-zinc-600 uppercase tracking-widest mb-4">Audience Triggers</p>
                <div className="flex flex-wrap gap-2">
                  {(currentSwarm?.emotion?.triggers || ['Wealth', 'Influence', 'Authority']).map((t: string, i: number) => (
                    <span key={i} className="text-[9px] font-mono text-omega-gold bg-omega-gold/10 px-3 py-1.5 rounded-lg border border-omega-gold/20 uppercase tracking-tighter">
                      {t}
                    </span>
                  ))}
                </div>
              </div>

              <button 
                onClick={handleResimulate}
                disabled={isSimulating}
                className="w-full py-5 bg-gradient-to-r from-emerald-500 to-omega-gold hover:opacity-90 disabled:opacity-50 text-black rounded-2xl font-bold transition-all shadow-[0_0_30px_rgba(16,185,129,0.3)] active:scale-95 flex items-center justify-center gap-3 uppercase tracking-widest text-xs group relative overflow-hidden"
              >
                <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-500" />
                {isSimulating ? <Loader2 className="w-5 h-5 animate-spin" /> : <Zap className="w-5 h-5 fill-black/20" />}
                <span className="relative z-10">{isSimulating ? 'Processing...' : 'Run Automation'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
