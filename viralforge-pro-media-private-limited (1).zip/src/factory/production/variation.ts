/**
 * L6 - VARIATION ENGINE (ANTI-REPETITION SYSTEM)
 * Prevents platform detection and user fatigue by rotating styles.
 */

export interface ProductionStyle {
    id: string;
    name: string;
    tone: string;
    pacing: string;
    editingStyle: 'zoom_cuts' | 'jump_cuts' | 'cinematic' | 'vlog';
    voiceStyle: 'energetic' | 'deep' | 'whisper' | 'natural';
    visualTheme: 'high_contrast' | 'vibrant' | 'minimalist' | 'tech';
}

export const STYLE_PROFILES: ProductionStyle[] = [
    {
        id: 'dominator_1',
        name: 'The Aggressor',
        tone: 'confrontational and urgent',
        pacing: 'ultra-fast with zero gaps',
        editingStyle: 'jump_cuts',
        voiceStyle: 'energetic',
        visualTheme: 'high_contrast'
    },
    {
        id: 'dominator_2',
        name: 'The Mentor',
        tone: 'educational and authoritative',
        pacing: 'steady but info-dense',
        editingStyle: 'zoom_cuts',
        voiceStyle: 'natural',
        visualTheme: 'minimalist'
    },
    {
        id: 'dominator_3',
        name: 'The Mystery',
        tone: 'suspenseful and mysterious',
        pacing: 'slow-to-fast build up',
        editingStyle: 'cinematic',
        voiceStyle: 'deep',
        visualTheme: 'vibrant'
    }
];

export function getRandomStyle(): ProductionStyle {
    return STYLE_PROFILES[Math.floor(Math.random() * STYLE_PROFILES.length)];
}
