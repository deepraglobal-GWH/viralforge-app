/**
 * L3 - PRODUCTION ENGINE (FRONTEND ONLY)
 * Video generation via Veo moved to browser context.
 */
import { Script } from "../brain/generator.ts";

export interface VideoProduction {
  videoId: string;
  status: 'rendering' | 'completed' | 'failed';
  path: string;
  thumbnail: string;
  videoUrl?: string;
}

export async function createVideo(script: Script): Promise<VideoProduction | null> {
    throw new Error("ARCHITECTURAL_VIOLATION: Veo Video Generation (Gemini) must be called from Frontend Drone.");
}


