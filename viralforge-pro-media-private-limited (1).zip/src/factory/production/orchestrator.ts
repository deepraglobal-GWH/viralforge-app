import ffmpeg from 'fluent-ffmpeg';
import ffmpegStatic from 'ffmpeg-static';
import path from 'path';
import fs from 'fs';
import { logger } from '../core/stability';
import { ProductionStyle } from './variation';

if (ffmpegStatic) {
    ffmpeg.setFfmpegPath(ffmpegStatic);
}

/**
 * L3 - ADVANCED CONTENT FACTORY (FFMPEG ARCHITECTURE)
 * Vertical 9:16 Video Synthesis with Dynamic Captions & Zoom Cuts
 */
export class VideoFactory {
    
    /**
     * Synthesizes a terminal-grade viral video
     */
    static async synthesize(
        projectId: string, 
        script: any, 
        style: ProductionStyle,
        assets: { videoPath?: string; audioPath?: string; musicPath?: string }
    ): Promise<string> {
        const outputPath = path.join(process.cwd(), 'tmp', `final_${projectId}.mp4`);
        const tmpDir = path.join(process.cwd(), 'tmp');
        
        if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

        return new Promise((resolve, reject) => {
            logger.info(`[FACTORY] Orchestrating ${style.name} production for ${projectId}...`);

            // 1. Build the FFmpeg Command
            let command = ffmpeg();

            // Input: Primary Visual (Stock Video/Generated)
            if (assets.videoPath && fs.existsSync(assets.videoPath)) {
                command = command.input(assets.videoPath).loop(5); // Loop if short
            } else {
                // Fallback: Generate custom canvas/solid if missing
                command = command.input('color=c=black:s=1080x1920:d=60').inputFormat('lavfi');
            }

            // Input: Voiceover
            if (assets.audioPath && fs.existsSync(assets.audioPath)) {
                command = command.input(assets.audioPath);
            }

            // Input: Background Music
            if (assets.musicPath && fs.existsSync(assets.musicPath)) {
                command = command.input(assets.musicPath);
            }

            command
                .complexFilter([
                    // Vertical Format (9:16)
                    {
                        filter: 'scale', options: '1080:1920:force_original_aspect_ratio=increase,crop=1080:1920',
                        inputs: '0:v', outputs: 'v_scaled'
                    },
                    // Dynamic Zoom Cut (Pattern Interrupt every 2-3 sec)
                    {
                        filter: 'zoompan', options: {
                            z: 'pzoom+0.002',
                            d: 1,
                            s: '1080x1920',
                            x: 'iw/2-(iw/zoom/2)',
                            y: 'ih/2-(ih/zoom/2)'
                        },
                        inputs: 'v_scaled', outputs: 'v_zoomed'
                    },
                    // Word-by-Word Subtitles (Simplified simulation here, normally use srt/ass)
                    {
                        filter: 'drawtext', options: {
                            text: script.hook,
                            fontcolor: 'white',
                            fontsize: 64,
                            x: '(w-text_w)/2',
                            y: '(h-text_h)/2 + 200',
                            box: 1,
                            boxcolor: 'black@0.5',
                            boxborderw: 10
                        },
                        inputs: 'v_zoomed', outputs: 'v_captioned'
                    },
                    // BRAND WATERMARK: REFINED ELITE BRANDING
                    {
                        filter: 'drawtext', options: {
                            text: 'DEEPRA | MEDIA', // Upgraded for authority
                            fontcolor: 'white@0.3',  // Slightly more subtle
                            fontsize: 32,            // Sophisticated size
                            x: 'w-text_w-60',        // Balanced padding
                            y: '60',
                            shadowcolor: 'black@0.6',
                            shadowx: 1,
                            shadowy: 1,
                            letter_spacing: 2        // More breathable/premium
                        },
                        inputs: 'v_captioned', outputs: 'v_final'
                    },
                    // Audio Mixing: Voice (1.0) + Music (0.1 dimming)
                    {
                        filter: 'amix', options: { inputs: assets.musicPath ? 2 : 1, duration: 'shortest', weights: '1 0.1' },
                        inputs: assets.audioPath ? ['1:a', '2:a'] : ['0:a'], outputs: 'a_final'
                    }
                ])
                .map('v_final')
                .map('a_final')
                .videoCodec('libx264')
                .audioCodec('aac')
                .outputOptions([
                    '-pix_fmt yuv420p',
                    '-shortest',
                    '-t 59' // Shorts Limit
                ])
                .on('start', (cmd) => logger.info(`[FFMPEG] Started: ${cmd}`))
                .on('progress', (p) => logger.info(`[FFMPEG] ${p.percent}% Complete`))
                .on('error', (err) => {
                    logger.error(`[FFMPEG_FAILURE] Pipeline breached: ${err.message}`);
                    reject(err);
                })
                .on('end', () => {
                    logger.info(`[FACTORY_SUCCESS] Viral asset locked: ${outputPath}`);
                    resolve(outputPath);
                })
                .save(outputPath);
        });
    }
}
