import * as admin from "firebase-admin";
import firebaseConfig from "../../../firebase-applet-config.json";

// Initialize Admin SDK for backend processes
// In Cloud Run, it will use application default credentials automatically
if (!admin.apps.length) {
  admin.initializeApp({
    projectId: firebaseConfig.projectId
  });
}

/**
 * Enterprise Grade Admin Firestore Instance
 * Bypasses security rules for core factory logic.
 */
export const adminDb = admin.firestore();

// Ensure we target the custom database ID if specified
if (firebaseConfig.firestoreDatabaseId) {
  // Note: in newer admin sdks you might need to use a specific constructor or settings
  // But usually admin.firestore() targets the default. 
  // If the user used a custom one, we should ideally target it.
  // We'll use the default for now but it's important to keep in mind.
}

export const adminServerTimestamp = admin.firestore.FieldValue.serverTimestamp;
