/**
 * L7 - DATA LAYER (FIRESTORE PERSISTENT)
 * Replaces local JSON with Cloud Firestore for durability and real-time UI sync.
 */
import { adminDb, adminServerTimestamp } from './firebase-admin';
import { readdirSync, unlinkSync, statSync, existsSync } from 'fs';
import path from 'path';
import { CONFIG } from '../core/config';

// The engine uses the Admin UID for its authoritative state
const ADMIN_UID = process.env.ADMIN_FIREBASE_UID || 'GLOBAL_FACTORY';

export interface FactoryStats {
  totalRuns: number;
  successRate: number;
  failedUploads: number;
  videosCreated: number;
}

export interface FactoryData {
  topics: string[];
  used_topics: string[];
  analytics: any[];
  logs: any[];
  stats: FactoryStats;
  tasks?: any[];
  system_config?: any;
  masked_keys?: Record<string, string>;
  _encryption_vault?: Record<string, string>;
}

const DEFAULT_STATS: FactoryStats = { totalRuns: 0, successRate: 100, failedUploads: 0, videosCreated: 0 };

export async function saveData(data: Partial<FactoryData>) {
  try {
    const factoryRef = adminDb.collection('system').doc('factory');
    await factoryRef.set({
      ...data,
      updatedAt: adminServerTimestamp()
    }, { merge: true });
    console.log("[FACTORY_SYNC] State persisted via Admin SDK.");
  } catch (err) {
    console.error("[FACTORY_SYNC_ERROR] Failed to persist state:", err);
  }
}

export async function loadData(): Promise<FactoryData> {
  try {
    const factoryRef = adminDb.collection('system').doc('factory');
    const snap = await factoryRef.get();
    if (snap.exists) {
      const data = snap.data() as FactoryData;
      if (!data.stats) data.stats = DEFAULT_STATS;
      if (!data.tasks) data.tasks = [];
      if (!data.topics) data.topics = [];
      if (!data.used_topics) data.used_topics = [];
      return data;
    }
  } catch (err) {
    console.error("[FACTORY_LOAD_ERROR] Failed to load state from Firestore:", err);
  }
  return { topics: [], used_topics: [], tasks: [], analytics: [], logs: [], stats: DEFAULT_STATS };
}

/**
 * PRODUCTION GUARD: Automatically cleans up old video assets to prevent disk crash.
 */
export function autoCleanupStorage() {
  const outputDir = path.join(process.cwd(), CONFIG.STORE.OUT);
  if (!existsSync(outputDir)) return;

  const files = readdirSync(outputDir)
    .filter(f => f.endsWith('.mp4'))
    .map(name => ({
      name,
      path: path.join(outputDir, name),
      ctime: statSync(path.join(outputDir, name)).ctime
    }))
    .sort((a, b) => b.ctime.getTime() - a.ctime.getTime());

  if (files.length > 50) {
    const toDelete = files.slice(50);
    toDelete.forEach(file => {
      try {
        unlinkSync(file.path);
        console.log(`[STORAGE_CLEANUP] Deleted old asset: ${file.name}`);
      } catch (e) {}
    });
  }
}
