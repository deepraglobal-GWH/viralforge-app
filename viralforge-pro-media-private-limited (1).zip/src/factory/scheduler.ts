/**
 * L0 - SCHEDULER (COMPANY GRADE)
 * Automatically runs the pipeline in a robust infinite loop
 */
import { runPipeline } from "./pipeline.ts";
import { logger } from "./core/stability.ts";
import { CONFIG } from "./core/config.ts";

let isStopRequested = false;

export async function startScheduler(intervalMs?: number) { 
  isStopRequested = false;
  const cycle = intervalMs || CONFIG.GAP_TIME;
  
  logger.info(`AUTONOMOUS_OPERATOR: Loop engaged. Interval: ${cycle / 60000} minutes.`);
  
  while (!isStopRequested) {
    try {
      logger.info("[HEARTBEAT] Beginning production sequence...");
      await runPipeline();
    } catch (err) {
      logger.error("LOOP_EXCEPTION: Recovery sequence initiated.", err);
    }

    // Dynamic Jitter to avoid pattern detection
    const jitter = Math.random() * 10000;
    const cooldown = cycle + jitter;
    
    logger.info(`[SYSTEM] Cooling down for ${Math.round(cooldown / 1000)}s...`);
    await new Promise((resolve) => setTimeout(resolve, cooldown));
  }
}

export function stopScheduler() {
  isStopRequested = true;
  logger.info("COMPANY_ENGINE: Stop signal received. Finishing current cycle...");
}

