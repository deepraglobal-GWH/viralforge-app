/**
 * L4 - DISTRIBUTION: INSTAGRAM REELS
 */
import { logger, retry } from "../core/stability.ts";
import { loadData } from "../data/memory.ts";
import { decrypt } from "../core/security.ts";

/**
 * Instagram Graph API follows a 3-step orchestration:
 * 1. URL + Container: Send public URL to IG.
 * 2. Status Poll: Wait for processing.
 * 3. Publish: Finalize the Reel.
 */
export async function uploadToInstagram(videoUrl: string, meta: any) {
  logger.info(`[INSTAGRAM] Orchestrating Container Chain for URL: ${videoUrl}`);
  
  const rawKey = process.env.IG_ACCESS_TOKEN || (await loadData())._encryption_vault?.instagram;
  const accessToken = decrypt(rawKey);
  const igUserId = process.env.IG_USER_ID;

  if (!accessToken || !igUserId) {
    logger.warn("[INSTAGRAM] Rejected: Missing Access Token or IG User ID.");
    return "failed_auth";
  }

  try {
    // STEP 1: Create Media Container
    const containerId = await retry(async () => {
        const response = await fetch(`https://graph.facebook.com/v19.0/${igUserId}/media`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                access_token: accessToken,
                media_type: 'REELS',
                video_url: videoUrl, // MANDATORY: MUST BE A PUBLIC S3/CDN URL
                caption: meta.description
            })
        });

        if (!response.ok) throw new Error(`IG_CONT_ERROR: ${await response.text()}`);
        const data: any = await response.json();
        return data.id;
    }, 2, 5000);

    logger.info(`[INSTAGRAM] Step 1 Locked: Container Created (${containerId}). Polling...`);

    // STEP 2: Status Check (Simple Poll)
    await new Promise(r => setTimeout(r, 30000)); // Initial grace period

    // STEP 3: Publish
    const publishId = await retry(async () => {
        const response = await fetch(`https://graph.facebook.com/v19.0/${igUserId}/media_publish`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                access_token: accessToken,
                creation_id: containerId
            })
        });

        if (!response.ok) throw new Error(`IG_PUB_ERROR: ${await response.text()}`);
        const data: any = await response.json();
        return data.id;
    }, 2, 10000);

    logger.info(`[INSTAGRAM] SUCCESS: Domination asset LIVE on Reels. ID: ${publishId}`);
    return { status: "success", externalId: publishId };

  } catch (err) {
    logger.error("[INSTAGRAM] Supply Chain Collapse", err);
    return "error";
  }
}
