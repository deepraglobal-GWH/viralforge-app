/**
 * L4 - DISTRIBUTION ENGINE
 * Multi-channel upload simulation
 */
import fs from "fs";
import path from "path";
import { logger, timeout, retry } from "../core/stability.ts";
import { VideoProduction } from "../production/creator.ts";
import { uploadToYouTube } from "./youtube.ts";
import { uploadToInstagram } from "./instagram.ts";
import { uploadToFacebook } from "./facebook.ts";
import { uploadToTikTok } from "./tiktok.ts";
import { CONFIG } from "../core/config.ts";

export async function uploadAll(video: VideoProduction, script: any) {
  logger.info(`L4 DISTRIBUTION: Initiating swarm for ${video.path}`);
  
  const meta = {
    title: script.topic,
    description: `${script.hook}\n\n${script.body}`,
    tags: [script.topic, 'viral', 'ai']
  };

  // Pre-flight validation: Ensure video exists
  if (video.path && !fs.existsSync(video.path)) {
    logger.error(`SWARM_STOP: Asset missing at ${video.path}`);
    return { error: "Asset missing" };
  }

  // Swarm execution logic with Human-like Sequential Delay
  const finalStatus: any = {};
  
  // 1. YouTube (Direct Multipart API)
  if (CONFIG.FEATURES.YOUTUBE) {
    logger.info("[YOUTUBE_SWARM] Launching direct binary deployment...");
    finalStatus.youtube = await timeout(uploadToYouTube(video.path!, meta), 60000, "YouTube Upload Hang");
  }

  await new Promise(r => setTimeout(r, 5000));

  // 2. Facebook (Direct Video API)
  if (CONFIG.FEATURES.FACEBOOK) {
    logger.info("[FACEBOOK_SWARM] Launching direct upload swarm...");
    finalStatus.facebook = await timeout(uploadToFacebook(video.path!, meta), 60000, "Facebook Upload Hang");
  }

  await new Promise(r => setTimeout(r, 5000));

  // 3. Instagram (URL -> Container -> Publish Orchestration)
  if (CONFIG.FEATURES.INSTAGRAM) {
    logger.info("[INSTAGRAM_SWARM] Launching 3-step container orchestration...");
    // Mock URL for simulation: In production, upload to S3/Cloud Storage first.
    const publicUrl = `https://cdn.viralforge.biz/videos/${path.basename(video.path!)}`;
    finalStatus.instagram = await timeout(uploadToInstagram(publicUrl, meta), 180000, "Instagram Orchestration Hang");
  }

  // 4. TikTok (Simulation)
  if (CONFIG.FEATURES.TIKTOK) {
    logger.info("[TIKTOK_SWARM] Launching TikTok simulation...");
    finalStatus.tiktok = await timeout(uploadToTikTok(video.path!, meta), 60000, "TikTok Upload Hang");
  }

  return finalStatus;
}
