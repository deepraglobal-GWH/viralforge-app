/**
 * L4 - DISTRIBUTION: FACEBOOK REELS
 */
import { logger, retry } from "../core/stability.ts";
import { loadData } from "../data/memory.ts";
import { decrypt } from "../core/security.ts";
import fs from "fs";

/**
 * Facebook Graph API involves direct binary upload to a page's video edge.
 */
export async function uploadToFacebook(videoPath: string, meta: any) {
  logger.info(`[FACEBOOK] Initializing Direct Integration for ${videoPath}`);
  
  const rawKey = process.env.FB_ACCESS_TOKEN || (await loadData())._encryption_vault?.facebook;
  const accessToken = decrypt(rawKey);
  const pageId = process.env.FB_PAGE_ID;

  if (!accessToken || !pageId) {
    logger.warn("[FACEBOOK] Rejected: Missing Access Token or Page ID.");
    return "failed_auth";
  }

  try {
    return await retry(async () => {
        // Facebook Video API handles direct binary POST
        // Note: For large videos, resumable upload is preferred, but for Reels (<60s), direct works.
        const formData = new FormData();
        formData.append('access_token', accessToken);
        formData.append('description', meta.description);
        formData.append('source', new Blob([fs.readFileSync(videoPath)], { type: 'video/mp4' }));

        const response = await fetch(`https://graph.facebook.com/v19.0/${pageId}/videos`, {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            const error = await response.text();
            throw new Error(`FB_API_ERROR: ${error}`);
        }

        const data: any = await response.json();
        logger.info(`[FACEBOOK] SUCCESS: Reel Published. ID: ${data.id}`);
        return { status: "success", externalId: data.id };
    }, 2, 5000);
  } catch (err) {
    logger.error("[FACEBOOK] Global Handshake Failure", err);
    return "error";
  }
}
