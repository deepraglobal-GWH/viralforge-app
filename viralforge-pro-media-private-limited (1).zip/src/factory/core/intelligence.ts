import { adminDb, adminServerTimestamp } from "../data/firebase-admin";
import { GoogleGenerativeAI } from "@google/generative-ai";
import { logger } from "./stability";
import { loadData, saveData } from "../data/memory";

import { BRANDS, BrandProfile } from "./brands";

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || '');
const ADMIN_UID = process.env.ADMIN_FIREBASE_UID || 'GLOBAL_FACTORY';

/**
 * L9 - INTELLIGENCE ENGINE (THE CEO BRAIN)
 * Autonomous Learning, Planning, and Strategic Evolution across 33 Brands.
 */
export class IntelligenceEngine {
    
    /**
     * AUTO-LEARN: Analyzes system history and external performance
     */
    static async learnFromPerformance() {
        logger.info("[INTELLIGENCE] Starting Multi-Channel Neural Audit...");
        try {
            // Fetch performance for all brands to identify cross-niche success
            const snapshot = await adminDb.collection('analytics')
                .orderBy('views', 'desc')
                .limit(30)
                .get();
            
            const performanceData = snapshot.docs.map(d => d.data());

            const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });
            const analysisPrompt = `Analyze performance for our 33 brands: ${JSON.stringify(performanceData)}.
            Identify:
            1. Which niches (e.g., Finance, Tech, Psychology) are growing fastest.
            2. The common hook pattern work across multiple brands.
            3. Recommended strategy shift for the next production cycle.
            Return JSON with 'topNiches', 'universalHooks', and 'nextShift'.`;

            const result = await model.generateContent(analysisPrompt);
            const learnedInsights = JSON.parse(result.response.text().replace(/```json|```/g, '').trim());

            const insightRef = adminDb.collection('users').doc(ADMIN_UID).collection('config').doc('self_learning');
            await insightRef.set({
                ...learnedInsights,
                totalAssets: 99,
                brandCount: 33,
                updatedAt: adminServerTimestamp()
            }, { merge: true });

            logger.info("[INTELLIGENCE] Global Audit Complete.");
            return learnedInsights;
        } catch (err) {
            logger.error("[INTELLIGENCE_FAILURE] Neural Audit crashed.", err);
            return null;
        }
    }

    /**
     * AUTO-AUDIT: Scrapes and synthesizes global trend data (YouTube, Trends, Competitors)
     */
    static async auditGlobalTrends() {
        logger.info("[INTELLIGENCE] Auditing Global Trend Signals...");
        try {
            // Simulation of external scrapers (mocking data from YT Trends, Google Trends)
            const trendSignals = [
                { niche: 'Finance', topic: 'The Great Wealth Reset 2026', velocity: 94 },
                { niche: 'Tech', topic: 'Gemini 4.0 Neural Leak', velocity: 88 },
                { niche: 'Psychology', topic: 'Why people fear autonomous AIs', velocity: 76 },
                { niche: 'Self-Improvement', topic: 'Zero-Input Productivity', velocity: 82 }
            ];

            const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });
            const prompt = `Synthesize these trend signals: ${JSON.stringify(trendSignals)}.
            Cross-reference with our 33 brands niches.
            Identify the top 50 underserved viral sub-topics for a 99-asset factory output.
            Assign each a 'priority_score' (1-100) based on 'Predictive Virality'.
            Return JSON: { predictions: Array<{topic, niche, priority_score, hook_type}> }`;

            const result = await model.generateContent(prompt);
            const synthesized = JSON.parse(result.response.text().replace(/```json|```/g, '').trim());

            await adminDb.collection('system').doc('trend_audit').set({
                ...synthesized,
                updatedAt: adminServerTimestamp()
            });

            return synthesized.predictions;
        } catch (err) {
            logger.error("[INTELLIGENCE_FAILURE] Trend Audit failed.", err);
            return [];
        }
    }

    /**
     * AUTO-PLANNING: Generates the roadmap for the 33-brand empire
     */
    static async generateStrategicPlan() {
        logger.info("[INTELLIGENCE] Synthesizing Global Media Roadmap...");
        try {
            const memory = await loadData();
            const rawPredictions = await this.auditGlobalTrends();
            
            // Pick high priority brands for this cycle
            const cycleBrands = BRANDS.sort(() => 0.5 - Math.random()).slice(0, 10);

            const model = genAI.getGenerativeModel({ 
                model: "gemini-2.0-flash",
                systemInstruction: "You are the AI Strategy CEO of ViralForge Pro Media Private Limited. Your goal is viral domination."
            });

            const planPrompt = `Using these predictions: ${JSON.stringify(rawPredictions)}.
            Assign specific high-impact topics to these 10 brands: ${JSON.stringify(cycleBrands)}.
            Generate 5 topics per brand (50 total tasks).
            Incorporate:
            - Shock factors
            - Emotional triggers
            - Monetization potential
            Return JSON: { brandTasks: Array<{brandId, topic, priority, cta_strategy}>, roadmap: Array, projections: string }`;

            const result = await model.generateContent(planPrompt);
            const plan = JSON.parse(result.response.text().replace(/```json|```/g, '').trim());

            // 3. Update CEO Strategy
            const strategyRef = adminDb.collection('users').doc(ADMIN_UID).collection('config').doc('ceo_strategy');
            await strategyRef.set({
                roadmap: plan.roadmap,
                projections: plan.projections,
                networkSize: 99,
                cycleBrands: cycleBrands.map(b => b.name),
                taskCount: plan.brandTasks.length,
                updatedAt: adminServerTimestamp()
            }, { merge: true });

            // 4. Update Factory Topic Queue (filtered by priority)
            const newTasks = plan.brandTasks.map((bt: any) => ({
                topic: bt.topic,
                brandId: bt.brandId,
                priority: bt.priority,
                cta: bt.cta_strategy,
                brand: BRANDS.find(b => b.id === bt.brandId)
            })).sort((a: any, b: any) => b.priority - a.priority);
            
            const existingTopics = memory.tasks || [];
            await saveData({ tasks: [...existingTopics, ...newTasks].slice(-200) });

            logger.info(`[INTELLIGENCE] Global Plan Deployed. 50+ High-Priority Tasks Queued.`);
        } catch (err) {
            logger.error("[INTELLIGENCE_FAILURE] Strategic Planning failed.", err);
        }
    }

    /**
     * FULL SYSTEM AUTO-SYNC
     */
    static async executeAutonomousCycle() {
        await this.learnFromPerformance();
        await this.generateStrategicPlan();
    }
}
