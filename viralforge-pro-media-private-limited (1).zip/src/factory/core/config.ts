import fs from "fs";

const parseBool = (val?: string) => val === "true";

// Execution Tuning (Strict NaN Guard with Production Defaults)
const safeNum = (val: any, fallback: number) => {
  const n = Number(val);
  return isNaN(n) ? fallback : n;
};

export const CONFIG = {
  NAME: "VIRAL CLOUD FACTORY",
  VERSION: "5.0.0-SIMPLE",
  AUTO_UPLOAD: parseBool(process.env.AUTO_UPLOAD || "false"),
  CHECK_SCORE: safeNum(process.env.CHECK_SCORE, 85), 

  MODE: process.env.MODE || "production",
  LOG_LEVEL: process.env.LOG_LEVEL || "info",

    // Execution Settings
    GAP_TIME: safeNum(process.env.GAP_TIME, 300000), 
    RETRY_LIMIT: safeNum(process.env.RETRY_LIMIT, 3),
    POST_DELAY: safeNum(process.env.POST_DELAY, 30000), 

    // Storage Paths
    STORE: {
        OUT: "videos",
        DATA: "data",
        MEMORY: "data/memory.json"
    },

  // Feature Flags
  FEATURES: {
    YOUTUBE: parseBool(process.env.ENABLE_YOUTUBE),
    INSTAGRAM: parseBool(process.env.ENABLE_INSTAGRAM),
    FACEBOOK: parseBool(process.env.ENABLE_FACEBOOK), // New
    TIKTOK: parseBool(process.env.ENABLE_TIKTOK)
  }
};

// CRITICAL: Production Directory Guard
Object.entries(CONFIG.STORE).forEach(([key, p]) => {
  // If it's a file path (like memory.json), get the directory part
  const dir = p.includes(".") ? p.substring(0, p.lastIndexOf("/")) : p;
  if (dir && !fs.existsSync(dir)) {
    console.log(`[BOOT] Creating required production directory: ${dir}`);
    fs.mkdirSync(dir, { recursive: true });
  }
});

console.log(`[SYSTEM] v${CONFIG.VERSION} Initialized in ${CONFIG.MODE} mode.`);
console.log(`[FEATURES] YT: ${CONFIG.FEATURES.YOUTUBE} | FB: ${CONFIG.FEATURES.FACEBOOK} | IG: ${CONFIG.FEATURES.INSTAGRAM} | TT: ${CONFIG.FEATURES.TIKTOK}`);
