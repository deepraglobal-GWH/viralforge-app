/**
 * L10 - BRAND ARCHITECTURE
 * Definition of the 33 Pillar Brands for the Multi-Platform Content Factory.
 * Total Assets: 99 (33 Brands x 3 Platforms)
 */

export interface BrandProfile {
  id: string;
  name: string;
  niche: string;
  description: string;
  platforms: ('youtube' | 'instagram' | 'facebook')[];
  audienceTrigger: string;
}

export const BRANDS: BrandProfile[] = [
  { id: 'movie_explainer', name: 'Mini Movie Explainer Hindi', niche: 'Entertainment', description: 'Movie explain, story breakdown', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Curiosity' },
  { id: 'viral_stories', name: 'Viral Stories India', niche: 'Story', description: 'Emotional, crime, love stories', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Emotion' },
  { id: 'relatable_comedy', name: 'Relatable India Comedy', niche: 'Comedy', description: 'Daily life comedy, memes', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Humor' },
  { id: 'ai_love_songs', name: 'AI Love Songs', niche: 'Creative Music', description: 'AI romantic songs, custom songs', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Romance' },
  { id: 'animal_facts', name: 'Animal Facts Shock', niche: 'Animal Facts', description: 'Animal facts, dangerous info', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Shock' },
  { id: 'cricket_inside', name: 'Cricket Inside Stories', niche: 'Sports', description: 'Cricket news, stories', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Fandom' },
  { id: 'budget_travel', name: 'Budget Travel India', niche: 'Travel', description: 'Cheap travel, hidden places', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Aspiration' },
  { id: 'gaming_pro', name: 'Noob to Pro Gaming', niche: 'Gaming', description: 'Gameplay, tips, funny clips', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Skill' },
  { id: 'hustle_vlog', name: 'Daily Hustle Vlog', niche: 'Personal Brand', description: 'Daily life, grind journey', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Motivation' },
  { id: 'news_fast', name: 'Explain News Fast', niche: 'News', description: '60 sec news explain', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Efficiency' },
  { id: 'smart_skills', name: 'Smart Skills Hindi', niche: 'Lifestyle', description: 'Life hacks, grooming', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Intelligence' },
  { id: 'study_hacks', name: 'Study Hacks Pro', niche: 'Education', description: 'Study tips, memory tricks', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Success' },
  { id: 'ai_future', name: 'AI Future Tech', niche: 'Tech', description: 'AI tools, tech updates', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Future' },
  { id: 'real_humanity', name: 'Real Humanity Stories', niche: 'Humanity', description: 'Helping, emotional content', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Empathy' },
  { id: 'car_truth', name: 'Car Truth India', niche: 'Auto', description: 'Car reviews, comparison', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Authority' },
  { id: 'kids_fun', name: 'Kids Learning & Fun Hindi', niche: 'Kids', description: 'ABC, rhymes, learning', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Joy' },
  { id: 'quick_recipe', name: 'Quick Recipe India', niche: 'Food', description: 'Easy recipes, cooking', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Hunger' },
  { id: 'fit_body', name: 'Fit Body Hindi', niche: 'Health', description: 'Fitness, workout, diet', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Well-being' },
  { id: 'glow_style', name: 'Glow & Style Hindi', niche: 'Beauty', description: 'Fashion, skincare', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Beauty' },
  { id: 'make_money', name: 'Make Money Online Hindi', niche: 'Money', description: 'Online earning, AI income', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Greed' },
  { id: 'dark_psychology', name: 'Dark Psychology Hindi', niche: 'Psychology', description: 'Mind tricks, behavior', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Power' },
  { id: 'mobile_tips', name: 'Mobile Tips & Tricks', niche: 'Mobile', description: 'Smartphone hacks', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Utility' },
  { id: 'history_mystery', name: 'History & Mystery India', niche: 'History', description: 'Historical secrets', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Mystery' },
  { id: 'business_stories', name: 'Business & Startup Stories', niche: 'Business', description: 'Case studies', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Strategy' },
  { id: 'self_growth', name: 'Motivation & Self Growth Hindi', niche: 'Motivation', description: 'Mindset, discipline', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Focus' },
  { id: 'art_hub', name: 'Art & Creativity Hub', niche: 'Creativity', description: 'Drawing, DIY', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Art' },
  { id: 'book_summaries', name: 'Book Summaries Hindi', niche: 'Books', description: 'Book explain', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Wisdom' },
  { id: 'home_ideas', name: 'Home & Interior Ideas', niche: 'Home', description: 'Room setup, decor', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Comfort' },
  { id: 'legal_awareness', name: 'Legal & Awareness India', niche: 'Legal', description: 'Laws, rights', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Security' },
  { id: 'freelancing_hub', name: 'Freelancing & Skills Hub', niche: 'Freelancing', description: 'Fiverr, skills', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Freedom' },
  { id: 'podcast_hindi', name: 'Podcast / Interview Hindi', niche: 'Podcast', description: 'Interviews, talk', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Dialogue' },
  { id: 'finance_hindi', name: 'Finance / Investment Hindi', niche: 'Finance', description: 'Stock, SIP', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Wealth' },
  { id: 'quiz_iq', name: 'Quiz / Brain Games', niche: 'Quiz', description: 'Puzzle, IQ test', platforms: ['youtube', 'instagram', 'facebook'], audienceTrigger: 'Challenge' }
];

export const PLATFORMS = ['YouTube', 'Instagram', 'Facebook'];
