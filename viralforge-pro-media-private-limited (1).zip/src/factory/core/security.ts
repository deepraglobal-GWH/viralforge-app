import crypto from "crypto";

// PRODUCTION_LEVEL_ENCRYPTION_LAYER
const ALGORITHM = 'aes-256-cbc';
const SECRET_KEY = process.env.SYSTEM_ENCRYPTION_KEY || 'ais-production-default-secure-32ch'; // 32 chars
const IV_LENGTH = 16;

/**
 * Encrypts a piece of sensitive data (API Key/Token)
 */
export function encrypt(text: string): string {
  if (!text) return "";
  const iv = crypto.randomBytes(IV_LENGTH);
  const cipher = crypto.createCipheriv(ALGORITHM, Buffer.from(SECRET_KEY), iv);
  let encrypted = cipher.update(text);
  encrypted = Buffer.concat([encrypted, cipher.final()]);
  return iv.toString('hex') + ':' + encrypted.toString('hex');
}

/**
 * Decrypts a vault entry
 */
export function decrypt(text: string): string {
  if (!text) return "";
  // If it doesn't look like an encrypted payload, assume it's a plain env key
  if (!text.includes(':')) return text;
  
  const textParts = text.split(':');
  const ivPart = textParts.shift();
  if (!ivPart) return "";
  const iv = Buffer.from(ivPart, 'hex');
  const encryptedText = Buffer.from(textParts.join(':'), 'hex');
  const decipher = crypto.createDecipheriv(ALGORITHM, Buffer.from(SECRET_KEY), iv);
  let decrypted = decipher.update(encryptedText);
  decrypted = Buffer.concat([decrypted, decipher.final()]);
  return decrypted.toString();
}

/**
 * Masks a key for UI presentation (****1234)
 */
export function maskKey(key: string): string {
  if (!key) return "";
  if (key.length < 8) return "****";
  return "****" + key.slice(-4);
}
