/**
 * L6 - CORE STABILITY Layer
 * Self-healing and logging logic
 */

import { loadData, saveData } from "../data/memory.ts";

export const logger = {
  info: async (msg: string, ...args: any[]) => {
    const formatted = `[INFO] [${new Date().toISOString()}] ${msg}`;
    console.log(formatted, ...args);
    await pushLog(formatted);
  },
  error: async (msg: string, ...args: any[]) => {
    const formatted = `[CRITICAL_ERROR] [${new Date().toISOString()}] ${msg}`;
    console.error(formatted, ...args);
    await pushLog(formatted);
  },
  warn: async (msg: string, ...args: any[]) => {
    const formatted = `[WARN] [${new Date().toISOString()}] ${msg}`;
    console.warn(formatted, ...args);
    await pushLog(formatted);
  },
};

async function pushLog(entry: string) {
  try {
    const memory = await loadData();
    const logs = [...(memory.logs || []), entry].slice(-50);
    // Note: In heavy load this might cause contention, but for this use case it ensures persistence
    await saveData({ logs });
  } catch (err) {}
}

export async function timeout<T>(promise: Promise<T>, ms: number, message: string): Promise<T> {
  const t = new Promise<never>((_, reject) =>
    setTimeout(() => reject(new Error(`TIMEOUT: ${message} (Exceeded ${ms}ms)`)), ms)
  );
  return Promise.race([promise, t]);
}

export async function retry<T>(
  fn: () => Promise<T>,
  retries = 3,
  delay = 2000
): Promise<T | null> {
  const attempt = async (remaining: number): Promise<T | null> => {
    try {
      return await fn();
    } catch (err) {
      if (remaining <= 0) {
        logger.error(`OPERATION_BREACH: Max retries exceeded. Manual intervention may be required.`);
        return null;
      }
      logger.warn(`STABILITY_LAYER: Retrying in ${delay * (4 - remaining)}ms... (${remaining} left)`);
      await new Promise((resolve) => setTimeout(resolve, delay * (4 - remaining)));
      return attempt(remaining - 1);
    }
  };
  return attempt(retries);
}
