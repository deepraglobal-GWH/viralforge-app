import { auth, db } from '../lib/firebase';
import { addDoc, collection, serverTimestamp } from 'firebase/firestore';

export interface Notification {
  id?: string;
  type: 'info' | 'success' | 'warning' | 'error';
  message: string;
  timestamp: any;
  videoId?: string;
  read: boolean;
}

class NotificationService {
  /**
   * Sends a notification to the dashboard.
   */
  async notify(message: string, type: 'info' | 'success' | 'warning' | 'error' = 'info', videoId?: string) {
    if (!auth.currentUser) return;
    
    try {
      await addDoc(collection(db, 'users', auth.currentUser.uid, 'notifications'), {
        message,
        type,
        videoId: videoId || null,
        timestamp: serverTimestamp(),
        read: false
      });
      
      console.log(`[Notification] ${type.toUpperCase()}: ${message}`);
      
      // WhatsApp notification via backend would be triggered here
      this.triggerExternalAlerts(message, type);
    } catch (e) {
      console.error("[Notification] Error saving notification:", e);
    }
  }

  private async triggerExternalAlerts(message: string, type: string) {
    try {
      // Trigger backend WhatsApp alert if configured
      await fetch('/api/notifications/external', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message, type })
      });
    } catch (e) {
      // Fail silently for external alerts
    }
  }

  /**
   * Notification Center - Browser Push Fallback
   */
  async pushLocal(title: string, body: string) {
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification(title, { body });
    }
  }
}

export const notificationService = new NotificationService();
