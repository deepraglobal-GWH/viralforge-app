import axios from 'axios';

const API_KEY = process.env.VITE_EXCHANGERATE_API_KEY;
const BASE_URL = `https://v6.exchangerate-api.com/v6/${API_KEY}/latest`;

export interface ExchangeRates {
  [key: string]: number;
}

export class CurrencyService {
  private ratesCache: { [base: string]: { rates: ExchangeRates; timestamp: number } } = {};
  private CACHE_DURATION = 3600000; // 1 hour

  async getRates(base: string = 'USD'): Promise<ExchangeRates> {
    const now = Date.now();
    if (this.ratesCache[base] && (now - this.ratesCache[base].timestamp < this.CACHE_DURATION)) {
      return this.ratesCache[base].rates;
    }

    try {
      if (!API_KEY) {
        console.warn("VITE_EXCHANGERATE_API_KEY is missing. Using mock rates.");
        return this.getMockRates(base);
      }

      const response = await axios.get(`${BASE_URL}/${base}`);
      if (response.data && response.data.conversion_rates) {
        this.ratesCache[base] = {
          rates: response.data.conversion_rates,
          timestamp: now
        };
        return response.data.conversion_rates;
      }
      throw new Error("Invalid API response");
    } catch (error) {
      console.error("Currency Conversion Error:", error);
      return this.getMockRates(base);
    }
  }

  private getMockRates(base: string): ExchangeRates {
    // Basic mock rates for fallback
    const mock: ExchangeRates = {
      USD: 1,
      EUR: 0.92,
      GBP: 0.79,
      INR: 83.3,
      JPY: 151.5,
      CAD: 1.35,
      AUD: 1.52
    };
    
    if (base !== 'USD' && mock[base]) {
      const baseRate = mock[base];
      const convertedMock: ExchangeRates = {};
      for (const key in mock) {
        convertedMock[key] = mock[key] / baseRate;
      }
      return convertedMock;
    }
    
    return mock;
  }

  formatCurrency(amount: number, currency: string): string {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency,
    }).format(amount);
  }

  convert(amount: number, fromRate: number, toRate: number): number {
    return (amount / fromRate) * toRate;
  }
}

export const currencyService = new CurrencyService();
