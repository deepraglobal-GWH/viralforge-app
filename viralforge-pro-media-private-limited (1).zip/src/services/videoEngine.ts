export interface RenderConfig {
  projectId: string;
  topic: string;
  script: string;
  resolution: '1080p' | '4k';
  fps: 30 | 60;
}

export class VideoEngine {
  /**
   * Coordinates the video rendering process by calling the backend pipeline.
   */
  async renderVideo(config: RenderConfig, onProgress?: (progress: number) => void) {
    console.log("[VideoEngine] Starting real render for project:", config.projectId);
    
    // Continuous progress simulation while backed processes
    let progress = 0;
    const interval = setInterval(() => {
      progress += Math.random() * 5;
      if (progress > 95) progress = 95;
      if (onProgress) onProgress(progress);
    }, 1000);

    try {
      const response = await fetch('/api/pipeline/render', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          projectId: config.projectId,
          topic: config.topic,
          script: config.script
        })
      });

      clearInterval(interval);
      if (onProgress) onProgress(100);

      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Rendering failed');

      return {
        success: true,
        videoUrl: result.previewUrl,
        duration: 59.5
      };
    } catch (error) {
      clearInterval(interval);
      console.error("[VideoEngine] Render Error:", error);
      throw error;
    }
  }

  /**
   * Generates a thumbnail using the backend Stability AI proxy.
   */
  async generateThumbnail(prompt: string) {
    const response = await fetch('/api/thumbnail/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt })
    });
    return response.json();
  }
}

export const videoEngine = new VideoEngine();
