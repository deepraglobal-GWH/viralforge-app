import { collection, addDoc, serverTimestamp, query, orderBy, limit, getDocs } from 'firebase/firestore';
import { db, auth } from '../lib/firebase';

/**
 * BRIDGE SERVICE
 * Connects Legacy UI components to the new Factory Production Engine.
 */
export const orchestrator = {
  async startFullAutoPipeline(topic: string) {
    if (!auth.currentUser) return;
    console.log(`[BRIDGE] Triggering production for topic: ${topic}`);
    
    try {
      // Trigger the real backend pipeline
      await fetch('/api/pipeline/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic, force: true })
      });
      
      await addDoc(collection(db, 'users', auth.currentUser.uid, 'logs'), {
        agent: 'Orchestrator',
        action: `Launched Viral Production Swarm for "${topic}" across 33-brand network`,
        status: 'success',
        timestamp: serverTimestamp()
      });
    } catch (error) {
       console.error("[BRIDGE] Pipeline Trigger Failed:", error);
    }
  },

  async generateCEOStrategy(niche: string) {
    if (!auth.currentUser) return;
    console.log(`[BRIDGE] Calculating Strategy for ${niche}`);
    
    await addDoc(collection(db, 'users', auth.currentUser.uid, 'logs'), {
      agent: 'CEO',
      action: `Recalculated Growth Matrix for ${niche}`,
      status: 'success',
      timestamp: serverTimestamp()
    });
  },

  startContinuousEngine(topic: string) {
    console.log("[BRIDGE] Continuous engine started internally via Factory Scheduler.");
    fetch('/api/scheduler/start', { method: 'POST' }).catch(console.error);
  },

  stopContinuousEngine() {
    console.log("[BRIDGE] Continuous engine stop requested.");
    fetch('/api/scheduler/stop', { method: 'POST' }).catch(console.error);
  },

  getQueue() {
    return [];
  }
};
