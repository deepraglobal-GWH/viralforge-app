export interface UploadMetadata {
  title: string;
  description: string;
  tags: string[];
  privacyStatus: 'public' | 'private' | 'unlisted';
}

export class UploadEngine {
  /**
   * Proxies the upload request to the Express backend.
   */
  async uploadToYouTube(tokens: any, videoData: UploadMetadata, projectId: string) {
    try {
      const response = await fetch('/api/youtube/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tokens, videoData, projectId })
      });

      const result = await response.json();
      if (!result.success || !result.videoId) {
        console.error("❌ Upload failed: Missing videoId or success=false", result);
        return { success: false, error: result.error || "Upload failed" };
      }
      
      return result;
    } catch (error) {
      console.error("[UploadEngine] YouTube Error:", error);
      throw error;
    }
  }

  async uploadToTikTok(tokens: any, videoData: UploadMetadata) {
    try {
      const response = await fetch('/api/tiktok/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tokens, videoData })
      });
      return response.json();
    } catch (error) {
      console.error("[UploadEngine] TikTok Error:", error);
      throw error;
    }
  }

  async uploadToInstagram(accessToken: any, videoData: UploadMetadata) {
    try {
      const response = await fetch('/api/instagram/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ accessToken, videoData })
      });
      return response.json();
    } catch (error) {
      console.error("[UploadEngine] Instagram Error:", error);
      throw error;
    }
  }

  async uploadToFacebook(accessToken: any, videoData: UploadMetadata) {
    try {
      const response = await fetch('/api/facebook/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ accessToken, videoData })
      });
      return response.json();
    } catch (error) {
      console.error("[UploadEngine] Facebook Error:", error);
      throw error;
    }
  }

  /**
   * Fetches real-time channel statistics.
   */
  async getChannelStats(tokens: any) {
    const response = await fetch('/api/youtube/stats', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tokens })
    });
    return response.json();
  }
}

export const uploadEngine = new UploadEngine();
