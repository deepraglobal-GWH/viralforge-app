import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Play, Pause, Download, Volume2, Settings2, Loader2, Mic, FileText, Sparkles } from 'lucide-react';
import { db, auth } from '../lib/firebase';
import { collection, query, orderBy, onSnapshot, limit } from 'firebase/firestore';
import { cn } from '@/src/lib/utils';

const voices = [
  { id: '21m00Tcm4TlvDq8ikWAM', name: 'Rachel (Professional)', gender: 'Female' },
  { id: 'AZnzlk1XhkUQCfSKzi9p', name: 'Domi (Narrator)', gender: 'Male' },
  { id: 'EXAVITQu4vr4xnSDxMaL', name: 'Bella (Energetic)', gender: 'Female' },
  { id: 'GBv7mTt0atIp3Br8iCZE', name: 'Thomas (Deep)', gender: 'Male' },
];

export function VoiceGenerator() {
  const [projects, setProjects] = useState<any[]>([]);
  const [selectedProject, setSelectedProject] = useState<any>(null);
  const [text, setText] = useState('');
  const [selectedVoice, setSelectedVoice] = useState(voices[0].id);
  const [loading, setLoading] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [audio, setAudio] = useState<HTMLAudioElement | null>(null);

  useEffect(() => {
    if (!auth.currentUser) return;
    const q = query(
      collection(db, 'users', auth.currentUser.uid, 'projects'),
      orderBy('createdAt', 'desc'),
      limit(5)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as any[];
      setProjects(data);
      if (data.length > 0 && !selectedProject) {
        setSelectedProject(data[0]);
        setText(data[0].script || '');
      }
    });

    return () => unsubscribe();
  }, []);

  const generateVoice = async () => {
    if (!text) return;
    setLoading(true);
    try {
      const response = await fetch('/api/voice/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, voiceId: selectedVoice }),
      });
      
      if (!response.ok) throw new Error('Failed to generate voice');
      
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      setAudioUrl(url);
      const newAudio = new Audio(url);
      newAudio.onended = () => setIsPlaying(false);
      setAudio(newAudio);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const togglePlay = () => {
    if (!audio) return;
    if (isPlaying) {
      audio.pause();
    } else {
      audio.play();
    }
    setIsPlaying(!isPlaying);
  };

  return (
    <div className="space-y-8 relative z-10">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white flex items-center gap-3">
            <Mic className="text-blue-500 w-8 h-8" />
            Voice Generator
          </h2>
          <p className="text-zinc-400 mt-1">Convert your script into professional AI narration with ElevenLabs.</p>
        </div>
        <div className="flex items-center gap-4">
          <select 
            onChange={(e) => {
              const p = projects.find(p => p.id === e.target.value);
              setSelectedProject(p);
              setText(p?.script || '');
            }}
            className="bg-zinc-900 border border-zinc-800 text-white px-4 py-2 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-600/50"
          >
            {projects.map(p => (
              <option key={p.id} value={p.id}>{p.title}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2 text-zinc-400">
                <FileText className="w-4 h-4" />
                <span className="text-sm font-medium">Script Content</span>
              </div>
              <button 
                onClick={() => setText(selectedProject?.script || '')}
                className="text-xs text-red-500 hover:text-red-400 font-bold flex items-center gap-1"
              >
                <Sparkles className="w-3 h-3" />
                Reset to Original
              </button>
            </div>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Paste the section of script you want to narrate..."
              className="w-full h-[350px] bg-zinc-800/50 border border-zinc-700 rounded-2xl p-6 text-white focus:outline-none focus:ring-2 focus:ring-red-600/50 transition-all resize-none mb-6 font-sans leading-relaxed"
            />
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <button
                  onClick={generateVoice}
                  disabled={loading || !text}
                  className="bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white px-10 py-4 rounded-2xl font-bold flex items-center gap-2 transition-all shadow-lg shadow-red-600/20 active:scale-95"
                >
                  {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Mic className="w-5 h-5" />}
                  {loading ? 'Generating...' : 'Generate Narration'}
                </button>
                {audioUrl && (
                  <button 
                    onClick={togglePlay}
                    className="w-14 h-14 bg-zinc-800 text-white rounded-2xl flex items-center justify-center hover:bg-zinc-700 transition-all shadow-xl"
                  >
                    {isPlaying ? <Pause className="w-6 h-6 fill-current" /> : <Play className="w-6 h-6 fill-current" />}
                  </button>
                )}
              </div>
              {audioUrl && (
                <a 
                  href={audioUrl} 
                  download="narration.mp3"
                  className="flex items-center gap-2 text-zinc-400 hover:text-white transition-all font-bold"
                >
                  <Download className="w-5 h-5" />
                  Download MP3
                </a>
              )}
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6">
            <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
              <Volume2 className="w-5 h-5 text-blue-500" />
              Select Voice
            </h3>
            <div className="space-y-3">
              {voices.map((voice) => (
                <button
                  key={voice.id}
                  onClick={() => setSelectedVoice(voice.id)}
                  className={cn(
                    "w-full flex items-center justify-between p-4 rounded-2xl border transition-all group",
                    selectedVoice === voice.id 
                      ? "bg-blue-600/10 border-blue-600/50 text-white" 
                      : "bg-zinc-800/50 border-zinc-800 text-zinc-400 hover:border-zinc-700"
                  )}
                >
                  <div className="text-left">
                    <p className="font-bold group-hover:text-white transition-colors">{voice.name}</p>
                    <p className="text-[10px] uppercase tracking-widest opacity-50 font-bold">{voice.gender}</p>
                  </div>
                  {selectedVoice === voice.id ? (
                    <div className="w-3 h-3 bg-blue-600 rounded-full shadow-lg shadow-blue-600/50" />
                  ) : (
                    <div className="w-3 h-3 bg-zinc-700 rounded-full" />
                  )}
                </button>
              ))}
            </div>
          </div>

          <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6">
            <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
              <Settings2 className="w-5 h-5 text-zinc-400" />
              Voice Settings
            </h3>
            <div className="space-y-6">
              <div>
                <div className="flex justify-between text-xs font-bold uppercase tracking-widest mb-3">
                  <span className="text-zinc-500">Stability</span>
                  <span className="text-white">50%</span>
                </div>
                <input type="range" className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-blue-600" />
              </div>
              <div>
                <div className="flex justify-between text-xs font-bold uppercase tracking-widest mb-3">
                  <span className="text-zinc-500">Clarity</span>
                  <span className="text-white">75%</span>
                </div>
                <input type="range" className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-blue-600" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
