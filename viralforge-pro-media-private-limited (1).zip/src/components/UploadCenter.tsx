import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Youtube, 
  Globe, 
  Lock, 
  Calendar, 
  Tag, 
  AlignLeft,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Sparkles,
  ArrowRight,
  ShieldCheck
} from 'lucide-react';
import { auth, db } from '../lib/firebase';
import { doc, setDoc, collection, query, orderBy, onSnapshot, limit, updateDoc, serverTimestamp } from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '../services/error-handler';
import { cn } from '../lib/utils';

export function UploadCenter() {
  const [projects, setProjects] = useState<any[]>([]);
  const [selectedProject, setSelectedProject] = useState<any>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [loading, setLoading] = useState(false);
  const [publishing, setPublishing] = useState(false);
  const [isPublished, setIsPublished] = useState(false);
  const [youtubeTokens, setYoutubeTokens] = useState<any>(null);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [tags, setTags] = useState('');

  useEffect(() => {
    if (!auth.currentUser) return;
    
    const q = query(
      collection(db, 'users', auth.currentUser.uid, 'projects'),
      orderBy('createdAt', 'desc'),
      limit(10)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as any[];
      setProjects(data);
      if (data.length > 0 && !selectedProject) {
        const p = data[0];
        setSelectedProject(p);
        setTitle(p.metadata?.title || p.title || '');
        setDescription(p.metadata?.description || '');
        setTags(p.metadata?.tags?.join(', ') || '');
        setIsPublished(p.status === 'published');
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, `users/${auth.currentUser?.uid}/projects`);
    });

    // Check YouTube Connection
    const unsubscribeUser = onSnapshot(doc(db, 'users', auth.currentUser.uid), (doc) => {
      if (doc.exists() && doc.data().youtubeTokens) {
        setIsConnected(true);
        setYoutubeTokens(doc.data().youtubeTokens);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `users/${auth.currentUser?.uid}`);
    });

    return () => {
      unsubscribe();
      unsubscribeUser();
    };
  }, []);

  useEffect(() => {
    const handleMessage = async (event: MessageEvent) => {
      if (event.data?.type === 'YOUTUBE_AUTH_SUCCESS') {
        const { tokens } = event.data;
        if (auth.currentUser) {
          try {
            await setDoc(doc(db, 'users', auth.currentUser.uid), {
              youtubeTokens: tokens,
              updatedAt: serverTimestamp()
            }, { merge: true });
            setIsConnected(true);
            setYoutubeTokens(tokens);
          } catch (error) {
            handleFirestoreError(error, OperationType.WRITE, `users/${auth.currentUser.uid}`);
          }
        }
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  const connectYouTube = async () => {
    setLoading(true);
    try {
      const API_BASE = window.location.origin;
      const response = await fetch(`${API_BASE}/api/auth/youtube/url`);
      const { url } = await response.json();
      window.open(url, 'youtube_auth', 'width=600,height=700');
    } catch (error) {
      console.error('Auth Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handlePublish = async () => {
    if (!selectedProject || !youtubeTokens || !auth.currentUser) return;
    setPublishing(true);
    try {
      const API_BASE = window.location.origin;
      const response = await fetch(`${API_BASE}/api/youtube/upload`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          projectId: selectedProject.id,
          tokens: youtubeTokens,
          videoData: {
            title,
            description,
            tags: tags.split(',').map(t => t.trim()),
            privacyStatus: 'public'
          }
        })
      });

      const result = await response.json();
      
      if (result.success) {
        try {
          await updateDoc(doc(db, 'users', auth.currentUser.uid, 'projects', selectedProject.id), {
            status: 'published',
            publishedAt: serverTimestamp(),
            finalMetadata: { title, description, tags: tags.split(',').map(t => t.trim()) },
            youtubeChannel: result.channel
          });
          setIsPublished(true);
        } catch (error) {
          handleFirestoreError(error, OperationType.UPDATE, `users/${auth.currentUser.uid}/projects/${selectedProject.id}`);
        }
      } else {
        throw new Error(result.error || 'Upload failed');
      }
    } catch (error) {
      console.error('Publish Error:', error);
    } finally {
      setPublishing(false);
    }
  };

  return (
    <div className="space-y-10 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <div className="flex items-center gap-3 mb-3">
             <div className="p-2.5 bg-accent/10 rounded-xl">
               <Youtube className="text-accent w-6 h-6" />
             </div>
             <h2 className="text-3xl font-extrabold text-white tracking-tighter uppercase">Publishing Node</h2>
          </div>
          <p className="text-zinc-500 font-bold text-[10px] uppercase tracking-[0.3em]">Managed and Optimized by DeePra Intelligence</p>
        </div>
        <div className="flex flex-col sm:flex-row items-center gap-4">
          <select 
            onChange={(e) => {
              const p = projects.find(p => p.id === e.target.value);
              setSelectedProject(p);
              setTitle(p?.metadata?.title || p?.title || '');
              setDescription(p?.metadata?.description || '');
              setTags(p?.metadata?.tags?.join(', ') || '');
              setIsPublished(p?.status === 'published');
            }}
            className="w-full sm:w-auto bg-zinc-900 border border-white/5 text-white px-5 py-3 rounded-xl text-xs font-bold uppercase tracking-widest focus:outline-none focus:ring-2 focus:ring-accent/50 appearance-none cursor-pointer"
          >
            {projects.map(p => (
              <option key={p.id} value={p.id}>{p.title}</option>
            ))}
          </select>
          {!isConnected ? (
            <button
              onClick={connectYouTube}
              disabled={loading}
              className="w-full sm:w-auto bg-white text-black px-6 py-3 rounded-xl font-extrabold uppercase text-[11px] tracking-widest flex items-center justify-center gap-2.5 hover:bg-zinc-200 transition-all shadow-xl shadow-white/5 active:scale-95"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Youtube className="w-4 h-4" />}
              Connect Platform
            </button>
          ) : (
            <div className="w-full sm:w-auto flex items-center justify-center gap-2.5 text-accent bg-accent/5 px-6 py-3 rounded-xl border border-accent/20">
              <CheckCircle2 className="w-4 h-4" />
              <span className="font-extrabold uppercase text-[11px] tracking-widest">YouTube Active</span>
            </div>
          )}
        </div>
      </div>

      <AnimatePresence>
        {isPublished && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-accent/10 border border-accent/20 p-8 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-6"
          >
            <div className="flex items-center gap-5">
              <div className="w-14 h-14 bg-accent/20 rounded-2xl flex items-center justify-center shadow-lg shadow-accent/20">
                <CheckCircle2 className="text-accent w-7 h-7" />
              </div>
              <div className="text-center md:text-left">
                <h3 className="text-white font-extrabold text-xl uppercase tracking-tight">Deployment Successful</h3>
                <p className="text-zinc-500 font-bold text-[10px] uppercase tracking-[0.2em] mt-1">Source is now live on Global Distribution Network</p>
              </div>
            </div>
            <button className="w-full md:w-auto bg-white text-black px-8 py-3.5 rounded-xl font-extrabold uppercase text-[11px] tracking-widest transition-all flex items-center justify-center gap-3 hover:bg-zinc-200 active:scale-95 shadow-xl shadow-white/5">
              View on Platform
              <ArrowRight className="w-4 h-4" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <div className="saas-card p-8 space-y-8">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label className="text-[10px] font-extrabold text-zinc-500 uppercase tracking-widest">Archive Identity (Title)</label>
                <div className="flex items-center gap-1.5 px-2 py-0.5 bg-accent/10 border border-accent/20 rounded text-[9px] font-bold text-accent uppercase tracking-widest">
                  <Sparkles className="w-3 h-3" /> AI Optimized
                </div>
              </div>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Enter compelling archive title..."
                className="w-full bg-zinc-950 border border-white/5 rounded-xl px-6 py-4 text-white font-bold text-lg focus:outline-none focus:ring-2 focus:ring-accent/50 transition-all placeholder:text-zinc-800"
              />
            </div>

            <div className="space-y-4">
              <label className="text-[10px] font-extrabold text-zinc-500 uppercase tracking-widest flex items-center gap-2">
                <AlignLeft className="w-3.5 h-3.5" />
                Context Payload (Description)
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe the content for SEO engines..."
                className="w-full h-56 bg-zinc-950 border border-white/5 rounded-xl px-6 py-4 text-white focus:outline-none focus:ring-2 focus:ring-accent/50 transition-all resize-none leading-relaxed custom-scrollbar placeholder:text-zinc-800"
              />
            </div>

            <div className="space-y-4">
              <label className="text-[10px] font-extrabold text-zinc-500 uppercase tracking-widest flex items-center gap-2">
                <Tag className="w-3.5 h-3.5" />
                Indexing Tags
              </label>
              <input
                type="text"
                value={tags}
                onChange={(e) => setTags(e.target.value)}
                placeholder="tag1, tag2, tag3..."
                className="w-full bg-zinc-950 border border-white/5 rounded-xl px-6 py-4 text-white font-bold text-sm focus:outline-none focus:ring-2 focus:ring-accent/50 transition-all placeholder:text-zinc-800"
              />
            </div>
          </div>
        </div>

        <div className="space-y-8">
          <div className="saas-card p-8">
            <h3 className="text-sm font-extrabold text-white uppercase tracking-widest mb-8">Node Distribution</h3>
            <div className="space-y-8">
              <div className="grid grid-cols-3 gap-3">
                <button className="flex flex-col items-center gap-3 p-4 bg-accent/10 border border-accent/50 text-accent rounded-xl transition-all shadow-lg shadow-accent/5">
                  <Globe className="w-5 h-5" />
                  <span className="text-[9px] font-bold uppercase tracking-widest">Public</span>
                </button>
                <button className="flex flex-col items-center gap-3 p-4 bg-zinc-950 border border-white/5 text-zinc-600 rounded-xl hover:text-zinc-400 hover:border-white/10 transition-all">
                  <Lock className="w-5 h-5" />
                  <span className="text-[9px] font-bold uppercase tracking-widest">Private</span>
                </button>
                <button className="flex flex-col items-center gap-3 p-4 bg-zinc-950 border border-white/5 text-zinc-600 rounded-xl hover:text-zinc-400 hover:border-white/10 transition-all">
                  <Calendar className="w-5 h-5" />
                  <span className="text-[9px] font-bold uppercase tracking-widest">Sched</span>
                </button>
              </div>

              <div className="pt-4">
                <button 
                  onClick={handlePublish}
                  disabled={!isConnected || publishing || isPublished}
                  className="w-full py-5 bg-accent hover:bg-accent/90 disabled:opacity-30 disabled:grayscale text-white rounded-xl font-extrabold text-lg shadow-[0_20px_40px_rgba(34,197,94,0.2)] transition-all active:scale-95 flex items-center justify-center gap-3 border border-accent/20"
                >
                  {publishing ? <Loader2 className="w-6 h-6 animate-spin" /> : <Sparkles className="w-6 h-6" />}
                  <span className="uppercase tracking-widest">
                    {publishing ? 'Deploying...' : isPublished ? 'Deployed' : 'Initiate Publish'}
                  </span>
                </button>
                <p className="text-center text-[9px] font-bold text-zinc-700 uppercase tracking-widest mt-6">Secure encrypted transmission protocol</p>
              </div>
            </div>
          </div>

          <div className="saas-card p-8">
            <div className="flex items-center gap-3 mb-8">
              <ShieldCheck className="w-5 h-5 text-emerald-500" />
              <h3 className="text-sm font-extrabold text-white uppercase tracking-widest">Audit Protocols</h3>
            </div>
            <div className="space-y-6">
              {[
                { label: "Platform Compliance", status: "pass" },
                { label: "Revenue Eligibility", status: "pass" },
                { label: "Viral Index Score", status: "pass", val: "94%" },
                { label: "SEO Integrity", status: "pass" },
              ].map((check, i) => (
                <div key={i} className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-zinc-600 uppercase tracking-wide">{check.label}</span>
                  <div className="flex items-center gap-3">
                    {check.val && <span className="text-white font-mono font-bold text-xs">{check.val}</span>}
                    <div className={cn(
                      "text-[9px] font-extrabold uppercase px-2 py-0.5 rounded border tracking-widest",
                      check.status === 'pass' ? "text-accent bg-accent/5 border-accent/20" : "text-amber-500 bg-amber-500/5 border-amber-500/20"
                    )}>
                      {check.status}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
