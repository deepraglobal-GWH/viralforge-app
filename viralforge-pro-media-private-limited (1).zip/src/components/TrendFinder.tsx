import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Search, 
  TrendingUp, 
  Zap, 
  BarChart2, 
  Loader2, 
  CheckCircle,
  Radar,
  Globe,
  Radio,
  Activity,
  AlertCircle
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { db, auth } from '../lib/firebase';
import { collection, setDoc, doc, serverTimestamp } from 'firebase/firestore';
import { cn } from '@/src/lib/utils';
import * as d3 from 'd3';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

const PredictiveRadar = () => {
    const svgRef = useRef<SVGSVGElement>(null);
    
    useEffect(() => {
      if (!svgRef.current) return;
      const svg = d3.select(svgRef.current);
      svg.selectAll("*").remove();

      const width = 400;
      const height = 400;
      const radius = Math.min(width, height) / 2 - 20;

      const g = svg.append("g")
        .attr("transform", `translate(${width / 2}, ${height / 2})`);

      // Radar circles
      [0.2, 0.4, 0.6, 0.8, 1].forEach(d => {
        g.append("circle")
          .attr("r", radius * d)
          .attr("fill", "none")
          .attr("stroke", "white")
          .attr("stroke-opacity", 0.05)
          .attr("stroke-dasharray", "4,4");
      });

      // Axis
      for (let i = 0; i < 8; i++) {
        const angle = (i * Math.PI) / 4;
        g.append("line")
          .attr("x1", 0)
          .attr("y1", 0)
          .attr("x2", radius * Math.cos(angle))
          .attr("y2", radius * Math.sin(angle))
          .attr("stroke", "white")
          .attr("stroke-opacity", 0.03);
      }

      // Scanner sweep
      const sweep = g.append("path")
        .attr("fill", "url(#scanner-gradient)")
        .attr("d", d3.arc<any>()
          .innerRadius(0)
          .outerRadius(radius)
          .startAngle(0)
          .endAngle(Math.PI / 3)({} as any));

      const gradient = svg.append("defs")
        .append("conicGradient")
        .attr("id", "scanner-gradient")
        .attr("cx", "50%")
        .attr("cy", "50%");

      // We'll use a simpler rotation animation with framer-motion since SVG conic gradients are tricky in some engines
      // Let's use a standard sweep line
      const sweepLine = g.append("line")
        .attr("x1", 0)
        .attr("y1", 0)
        .attr("x2", radius)
        .attr("y2", 0)
        .attr("stroke", "#3b82f6")
        .attr("stroke-width", 2)
        .attr("stroke-linecap", "round");

      const animate = () => {
        sweepLine.transition()
          .duration(4000)
          .ease(d3.easeLinear)
          .attrTween("transform", () => {
            return d3.interpolateString("rotate(0)", "rotate(360)");
          })
          .on("end", animate);
      };
      animate();

      // Random Blips
      const blips = Array.from({ length: 15 }, () => ({
        r: Math.random() * radius,
        angle: Math.random() * Math.PI * 2,
        size: Math.random() * 4 + 2
      }));

      g.selectAll(".blip")
        .data(blips)
        .enter()
        .append("circle")
        .attr("class", "blip")
        .attr("cx", d => d.r * Math.cos(d.angle))
        .attr("cy", d => d.r * Math.sin(d.angle))
        .attr("r", d => d.size)
        .attr("fill", "#3b82f6")
        .attr("opacity", 0)
        .transition()
        .duration(1000)
        .delay((_, i) => i * 300)
        .attr("opacity", 0.6)
        .on("end", function repeat() {
            d3.select(this)
              .transition()
              .duration(2000)
              .attr("opacity", 0.1)
              .transition()
              .duration(2000)
              .attr("opacity", 0.6)
              .on("end", repeat);
        });

    }, []);

    return (
      <div className="relative w-full max-w-[400px] mx-auto opacity-40 hover:opacity-80 transition-opacity duration-700">
        <svg ref={svgRef} viewBox="0 0 400 400" className="w-full h-full" />
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="text-center">
            <span className="text-[10px] font-mono text-omega-blue animate-pulse block">SCANNING</span>
            <span className="text-[8px] font-mono text-zinc-600 block">GLOBAL SIGNAL</span>
          </div>
        </div>
      </div>
    );
};

export function TrendFinder() {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState<string | null>(null);
  const [trends, setTrends] = useState<any[]>([]);

  const findTrends = async () => {
    if (!query) return;
    setLoading(true);
    try {
      const response = await ai.models.generateContent({
        model: "gemini-2.0-flash",
        contents: `Find high-CPM trending YouTube topics related to "${query}" for 2026. 
        For each topic, provide: topic name, search volume (High/Medium/Low), difficulty (1-100), and viral probability (1-100). 
        Target niches: Tech, Wealth, AI, and Automation.
        Return as JSON array.`,
        config: { responseMimeType: "application/json" }
      });
      
      const data = JSON.parse(response.text || '[]');
      setTrends(data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const createProject = async (trend: any) => {
    if (!auth.currentUser) return;
    setSaving(trend.topic);
    try {
      const projectsRef = collection(db, 'users', auth.currentUser.uid, 'projects');
      const newProjectRef = doc(projectsRef);
      
      await setDoc(newProjectRef, {
        id: newProjectRef.id,
        title: trend.topic,
        topic: trend.topic,
        status: 'idea',
        viralScore: trend.viralProbability,
        createdAt: serverTimestamp(),
        userId: auth.currentUser.uid
      });
      setTimeout(() => setSaving(null), 2000);
    } catch (error) {
      console.error("Save Error:", error);
      setSaving(null);
    }
  };

  return (
    <div className="space-y-12 relative z-10 pb-20">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8">
        <div>
          <div className="flex items-center gap-3 mb-4">
            <div className="px-2 py-1 bg-omega-blue/10 border border-omega-blue/20 rounded text-[10px] font-mono text-omega-blue uppercase tracking-widest">Radar Active</div>
            <div className="px-2 py-1 bg-omega-gold/10 border border-omega-gold/20 rounded text-[10px] font-mono text-omega-gold uppercase tracking-widest">Global Ingestion</div>
          </div>
          <h2 className="text-5xl font-display text-white uppercase tracking-tighter">Trend Finder</h2>
          <p className="text-zinc-500 font-mono text-xs uppercase tracking-[0.2em] mt-2">Discovering Viral Opportunities via Real-time AI Analysis</p>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-12 mb-20">
        <div className="lg:w-2/3 space-y-8">
            <div className="flex flex-col md:flex-row gap-6">
                <div className="relative flex-1 group">
                <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-zinc-500 w-6 h-6 group-focus-within:text-omega-blue transition-colors" />
                <input
                    type="text"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Enter niche or keyword (e.g., Tech, Cooking, AI)..."
                    className="w-full bg-zinc-900/50 border border-white/5 rounded-2xl py-6 pl-16 pr-6 text-white focus:outline-none focus:ring-2 focus:ring-omega-blue/50 transition-all hardware-border font-mono uppercase tracking-widest text-sm"
                />
                </div>
                <button
                onClick={findTrends}
                disabled={loading}
                className="bg-omega-blue hover:bg-blue-700 disabled:opacity-50 text-white px-12 py-6 rounded-2xl font-bold flex items-center justify-center gap-3 transition-all active:scale-95 shadow-2xl shadow-omega-blue/20 uppercase tracking-widest text-xs"
                >
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Zap className="w-5 h-5 fill-white/20" />}
                Analyze Trends
                </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="glass-card p-6 border-white/5 bg-white/[0.02]">
                    <div className="flex items-center gap-3 mb-6">
                        <Activity className="w-4 h-4 text-emerald-500" />
                        <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Signal Strength</span>
                    </div>
                    <div className="flex items-baseline gap-4">
                        <span className="text-4xl font-display text-white uppercase tracking-tight">High</span>
                        <span className="text-[10px] font-mono text-emerald-500">+12% Latency Boost</span>
                    </div>
                </div>
                <div className="glass-card p-6 border-white/5 bg-white/[0.02]">
                    <div className="flex items-center gap-3 mb-6">
                        <Radio className="w-4 h-4 text-omega-blue" />
                        <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Ingestion Sources</span>
                    </div>
                    <div className="flex items-baseline gap-4">
                        <span className="text-4xl font-display text-white uppercase tracking-tight">142</span>
                        <span className="text-[10px] font-mono text-omega-blue">Global Satellites</span>
                    </div>
                </div>
            </div>
        </div>

        <div className="lg:w-1/3 glass-card p-8 border-white/5 flex flex-col items-center justify-center relative overflow-hidden bg-white/[0.02]">
            <div className="absolute inset-0 bg-gradient-to-t from-blue-500/5 to-transparent pointer-events-none" />
            <PredictiveRadar />
            <p className="mt-6 text-[10px] font-mono text-zinc-500 uppercase tracking-[0.3em] text-center">Predictive Signal Analysis Active</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
        {trends.map((trend, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.1 }}
            className="glass-card p-8 group hover:border-omega-blue/40 transition-all relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity pointer-events-none">
              <TrendingUp className="w-32 h-32 text-omega-blue" />
            </div>

            <div className="flex items-start justify-between mb-8">
              <h3 className="text-xl font-display text-white uppercase tracking-tight group-hover:text-omega-blue transition-colors max-w-[80%]">{trend.topic}</h3>
              <div className="w-12 h-12 bg-omega-blue/10 rounded-xl flex items-center justify-center border border-omega-blue/20">
                <TrendingUp className="w-6 h-6 text-omega-blue" />
              </div>
            </div>
            
            <div className="space-y-8">
              <div className="space-y-4">
                <div className="flex justify-between items-end">
                  <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Viral Probability</span>
                  <span className="text-emerald-500 font-mono text-sm">{trend.viralProbability}%</span>
                </div>
                <div className="w-full bg-zinc-900 h-1 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${trend.viralProbability}%` }}
                    transition={{ duration: 1.5 }}
                    className="bg-emerald-500 h-full shadow-[0_0_10px_rgba(16,185,129,0.5)]" 
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white/5 p-4 rounded-2xl border border-white/5">
                  <span className="text-zinc-600 text-[9px] font-mono uppercase tracking-widest block mb-1">Volume</span>
                  <p className="text-white font-display uppercase text-sm">{trend.searchVolume}</p>
                </div>
                <div className="bg-white/5 p-4 rounded-2xl border border-white/5">
                  <span className="text-zinc-600 text-[9px] font-mono uppercase tracking-widest block mb-1">Difficulty</span>
                  <p className="text-white font-display uppercase text-sm">{trend.difficulty}/100</p>
                </div>
              </div>
            </div>

            <button 
              onClick={() => createProject(trend)}
              disabled={saving === trend.topic}
              className={cn(
                "w-full mt-10 py-5 rounded-2xl font-bold uppercase tracking-widest text-[10px] transition-all flex items-center justify-center gap-3 hardware-border",
                saving === trend.topic 
                  ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20" 
                  : "bg-zinc-900 hover:bg-omega-blue hover:text-white text-zinc-500"
              )}
            >
              {saving === trend.topic ? (
                <>
                  <CheckCircle className="w-4 h-4" />
                  Saved to Dashboard
                </>
              ) : (
                'Initialize Project'
              )}
            </button>
          </motion.div>
        ))}
      </div>

      {trends.length === 0 && !loading && (
        <div className="flex flex-col items-center justify-center py-40 glass-card border-dashed border-white/5">
          <BarChart2 className="w-20 h-20 text-zinc-800 mb-6 animate-pulse" />
          <h3 className="text-2xl font-display text-zinc-600 uppercase tracking-tight">No Trends Analyzed</h3>
          <p className="text-zinc-700 font-mono text-xs uppercase tracking-widest mt-2">Enter a keyword above to initiate scanning</p>
        </div>
      )}
    </div>
  );
}
