import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Play, 
  Film, 
  Plus, 
  Scissors, 
  Type, 
  Music, 
  Layers,
  ChevronRight,
  Maximize2,
  Loader2,
  Sparkles,
  CheckCircle2
} from 'lucide-react';
import { db, auth } from '../lib/firebase';
import { collection, query, orderBy, onSnapshot, limit, doc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { videoEngine } from '../services/videoEngine';

export function VideoBuilder() {
  const [projects, setProjects] = useState<any[]>([]);
  const [selectedProject, setSelectedProject] = useState<any>(null);
  const [isRendering, setIsRendering] = useState(false);
  const [renderProgress, setRenderProgress] = useState(0);
  const [isComplete, setIsComplete] = useState(false);

  useEffect(() => {
    if (!auth.currentUser) return;
    const q = query(
      collection(db, 'users', auth.currentUser.uid, 'projects'),
      orderBy('createdAt', 'desc'),
      limit(5)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setProjects(data);
      if (data.length > 0 && !selectedProject) {
        setSelectedProject(data[0]);
      }
    });

    return () => unsubscribe();
  }, []);

  const handleRender = async () => {
    if (!selectedProject || !auth.currentUser) return;
    setIsRendering(true);
    setRenderProgress(0);
    setIsComplete(false);
    
    try {
      const result = await videoEngine.renderVideo({
        projectId: selectedProject.id,
        topic: selectedProject.topic || selectedProject.title,
        script: selectedProject.script || "Sample AI generated script for " + (selectedProject.topic || selectedProject.title),
        resolution: '1080p',
        fps: 30
      }, (progress) => {
        setRenderProgress(Math.floor(progress));
      });

      if (result.success) {
        // Update project in Firestore
        const projectRef = doc(db, 'users', auth.currentUser.uid, 'projects', selectedProject.id);
        await updateDoc(projectRef, {
          status: 'pending_approval',
          previewUrl: result.videoUrl,
          renderCompletedAt: serverTimestamp()
        });
        setIsComplete(true);
      }
    } catch (error) {
      console.error("Render Failed:", error);
    } finally {
      setIsRendering(false);
    }
  };

  const scenes = selectedProject?.storyboard || [
    { title: 'Intro Hook', duration: '0:15', description: 'Fast-paced cuts showing the main topic.' },
    { title: 'The Problem', duration: '0:45', description: 'Emotional B-roll highlighting the pain point.' },
    { title: 'The Solution', duration: '1:30', description: 'Step-by-step walkthrough with clear visuals.' },
  ];

  return (
    <div className="space-y-8 relative z-10">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white flex items-center gap-3">
            <Film className="text-blue-500 w-8 h-8" />
            Video Builder
          </h2>
          <p className="text-zinc-400 mt-1">AI-powered scene orchestration and automated assembly.</p>
        </div>
        <div className="flex items-center gap-4">
          <select 
            onChange={(e) => setSelectedProject(projects.find(p => p.id === e.target.value))}
            className="bg-zinc-900 border border-zinc-800 text-white px-4 py-2 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-600/50"
          >
            {projects.map(p => (
              <option key={p.id} value={p.id}>{p.title}</option>
            ))}
          </select>
          <button 
            onClick={handleRender}
            disabled={isRendering || !selectedProject}
            className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white px-8 py-3 rounded-xl font-bold flex items-center gap-2 transition-all active:scale-95 shadow-lg shadow-blue-600/20"
          >
            {isRendering ? <Loader2 className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />}
            {isComplete ? 'Re-Render Video' : 'Render Masterpiece'}
          </button>
        </div>
      </div>

      {isRendering && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-zinc-900 border border-blue-600/30 p-6 rounded-3xl"
        >
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center gap-3">
              <Loader2 className="w-5 h-5 text-blue-500 animate-spin" />
              <span className="text-white font-bold">AI Assembly in Progress...</span>
            </div>
            <span className="text-blue-500 font-mono font-bold">{renderProgress}%</span>
          </div>
          <div className="w-full bg-zinc-800 h-3 rounded-full overflow-hidden">
            <motion.div 
              className="bg-blue-600 h-full"
              style={{ width: `${renderProgress}%` }}
            />
          </div>
          <p className="text-zinc-500 text-xs mt-4 font-mono">
            {renderProgress < 30 && '> Analyzing script beats...'}
            {renderProgress >= 30 && renderProgress < 60 && '> Matching B-roll assets...'}
            {renderProgress >= 60 && renderProgress < 90 && '> Applying viral transitions...'}
            {renderProgress >= 90 && '> Finalizing color grading...'}
          </p>
        </motion.div>
      )}

      {isComplete && (
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-emerald-500/10 border border-emerald-500/20 p-6 rounded-3xl flex items-center justify-between"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-emerald-500 rounded-2xl flex items-center justify-center">
              <CheckCircle2 className="text-white w-6 h-6" />
            </div>
            <div>
              <h3 className="text-white font-bold text-lg">Rendering Complete!</h3>
              <p className="text-zinc-400 text-sm">Your video is ready for the Upload Center.</p>
            </div>
          </div>
          <button className="bg-emerald-500 hover:bg-emerald-600 text-white px-6 py-3 rounded-xl font-bold transition-all">
            Preview Final Cut
          </button>
        </motion.div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-3 space-y-6">
          <div className="aspect-video bg-zinc-900 border border-zinc-800 rounded-3xl relative overflow-hidden group">
            <img 
              src={`https://picsum.photos/seed/${selectedProject?.id || 'preview'}/1280/720`} 
              alt="Preview" 
              className="w-full h-full object-cover opacity-50"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 flex items-center justify-center">
              <button className="w-20 h-20 bg-blue-600 rounded-full flex items-center justify-center shadow-2xl shadow-blue-600/40 hover:scale-110 transition-all">
                <Play className="w-8 h-8 text-white fill-current" />
              </button>
            </div>
            <div className="absolute bottom-6 right-6">
              <button className="p-3 bg-black/50 backdrop-blur-md rounded-xl text-white hover:bg-black/70 transition-all">
                <Maximize2 className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Layers className="w-5 h-5 text-blue-500" />
                AI Timeline
              </h3>
              <div className="flex gap-2">
                <button className="p-2 bg-zinc-800 text-zinc-400 hover:text-white rounded-lg transition-all">
                  <Scissors className="w-4 h-4" />
                </button>
                <button className="p-2 bg-zinc-800 text-zinc-400 hover:text-white rounded-lg transition-all">
                  <Type className="w-4 h-4" />
                </button>
                <button className="p-2 bg-zinc-800 text-zinc-400 hover:text-white rounded-lg transition-all">
                  <Music className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
              {scenes.map((scene: any, i: number) => (
                <div key={i} className="flex-shrink-0 w-64 space-y-2 group">
                  <div className="aspect-video rounded-xl overflow-hidden border-2 border-transparent group-hover:border-blue-600/50 transition-all relative">
                    <img src={`https://picsum.photos/seed/${i}${selectedProject?.id}/320/180`} alt={scene.title} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    <div className="absolute bottom-2 right-2 bg-black/70 px-2 py-1 rounded text-[10px] font-bold text-white">
                      {scene.duration}
                    </div>
                  </div>
                  <div className="flex items-center justify-between px-1">
                    <span className="text-sm font-medium text-white truncate">{scene.title}</span>
                    <span className="text-xs text-zinc-500">Scene {i + 1}</span>
                  </div>
                </div>
              ))}
              <button className="flex-shrink-0 w-64 aspect-video rounded-xl border-2 border-dashed border-zinc-800 flex flex-col items-center justify-center text-zinc-600 hover:text-zinc-400 hover:border-zinc-700 transition-all gap-2">
                <Plus className="w-8 h-8" />
                <span className="text-sm font-bold">Add Scene</span>
              </button>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6">
            <h3 className="text-lg font-bold text-white mb-4">Channel Synthesis</h3>
            <div className="space-y-4">
              <div className="p-4 bg-zinc-800/50 rounded-xl border border-zinc-800">
                <span className="text-[10px] font-bold text-blue-500 uppercase tracking-widest block mb-1">Target Channel</span>
                <p className="text-white font-bold text-sm tracking-tight">{selectedProject?.brandName || 'ViralForge Global'}</p>
                <p className="text-zinc-500 text-[10px] uppercase font-mono mt-1 tracking-widest">{selectedProject?.metadata?.niche || 'General Viral'}</p>
              </div>
              
              <div className="p-4 bg-zinc-800/50 rounded-xl border border-zinc-800">
                <span className="text-[10px] font-bold text-emerald-500 uppercase tracking-widest block mb-1">Viral Trigger</span>
                <p className="text-white font-bold text-sm tracking-tight">{selectedProject?.metadata?.thumbnailText || 'High Retention'}</p>
              </div>
            </div>

            <div className="h-px bg-zinc-800/50 my-6" />

            <h3 className="text-lg font-bold text-white mb-4">Scene Instructions</h3>
            <div className="space-y-4 max-h-[500px] overflow-y-auto pr-2 px-1">
              {scenes.map((scene: any, i: number) => (
                <div key={i} className="p-4 bg-zinc-800/50 rounded-xl border border-zinc-800 hover:border-blue-600/30 transition-all cursor-pointer group">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-bold text-blue-500 uppercase tracking-widest">Scene {i + 1}</span>
                    <span className="text-zinc-500 text-[10px]">{scene.duration}</span>
                  </div>
                  <h4 className="text-white font-bold text-sm mb-1 group-hover:text-blue-400 transition-colors">{scene.title}</h4>
                  <p className="text-zinc-500 text-xs leading-relaxed">{scene.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
