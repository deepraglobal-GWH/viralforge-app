import React from 'react';
import { 
  LayoutDashboard, 
  Settings,
  LogOut,
  User as UserIcon,
  ShieldAlert,
  Zap,
  Briefcase,
  Coins
} from 'lucide-react';
import { cn } from '../lib/utils';
import { User } from 'firebase/auth';
import { auth } from '../lib/firebase';
import { signOut } from 'firebase/auth';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  user: User | null;
  onActivateMoneyMode: () => void;
}

const menuItems = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'brands', label: 'Brand Matrix', icon: Briefcase },
  { id: 'monetization', label: 'Earnings', icon: Coins },
  { id: 'settings', label: 'Settings', icon: Settings },
  { id: 'warroom', label: 'Activity Logs', icon: ShieldAlert },
];

export function Sidebar({ activeTab, setActiveTab, user }: SidebarProps) {
  const handleLogout = async () => {
    await signOut(auth);
  };

  return (
    <div className="w-64 bg-primary border-r border-white/5 flex flex-col h-screen sticky top-0 z-20 shrink-0 shadow-2xl">
      <div className="p-8 flex flex-col h-full uppercase tracking-tighter">
        <div className="flex items-center gap-4 mb-12 px-2">
          <div className="w-10 h-10 bg-accent rounded-xl flex items-center justify-center shadow-lg shadow-accent/20">
            <Zap className="text-white w-6 h-6 fill-white" />
          </div>
          <h1 className="text-xl font-extrabold text-white tracking-widest">
            ViralForge
          </h1>
        </div>

        <nav className="flex-1 space-y-2">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={cn(
                "w-full flex items-center gap-4 px-5 py-4 rounded-xl transition-all duration-200 group relative",
                activeTab === item.id 
                  ? "bg-accent/10 text-accent border border-accent/20" 
                  : "text-zinc-500 hover:text-zinc-300 hover:bg-white/5 border border-transparent"
              )}
            >
              <item.icon className={cn(
                "w-4 h-4 transition-colors",
                activeTab === item.id ? "text-accent" : "text-zinc-600 group-hover:text-zinc-400"
              )} />
              <span className="font-sans text-[11px] font-bold tracking-[0.1em]">{item.label}</span>
              {activeTab === item.id && (
                <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-accent rounded-r-full shadow-[0_0_10px_rgba(34,197,94,0.5)]" />
              )}
            </button>
          ))}
        </nav>

        <div className="mt-auto pt-8 border-t border-white/5 space-y-6">
          {user && (
            <div className="flex items-center gap-4 px-2">
              <div className="relative">
                 {user.photoURL ? (
                    <img src={user.photoURL} alt="Profile" className="w-10 h-10 rounded-full border-2 border-white/5 shadow-inner" referrerPolicy="no-referrer" />
                  ) : (
                    <div className="w-10 h-10 bg-zinc-900 rounded-full flex items-center justify-center border-2 border-white/5 shadow-inner">
                      <UserIcon className="w-5 h-5 text-zinc-600" />
                    </div>
                  )}
                  <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-accent border-2 border-primary rounded-full shadow-sm" />
              </div>
              <div className="min-w-0">
                <p className="text-xs font-bold text-white truncate mb-0.5">{user.displayName || 'Authorized User'}</p>
                <p className="text-[10px] font-bold text-zinc-600 uppercase tracking-widest">System Admin</p>
              </div>
            </div>
          )}
          
          <button 
            onClick={handleLogout}
            className="w-full flex items-center gap-4 px-5 py-3.5 rounded-xl text-zinc-500 hover:text-error hover:bg-error/5 transition-all group border border-transparent hover:border-error/20"
          >
            <LogOut className="w-4 h-4" />
            <span className="font-sans text-[11px] font-bold tracking-[0.1em]">Logout</span>
          </button>
        </div>
      </div>
    </div>
  );
}
