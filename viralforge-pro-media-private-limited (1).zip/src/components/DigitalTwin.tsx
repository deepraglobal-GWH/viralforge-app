import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Fingerprint, 
  Cpu, 
  Brain, 
  Zap, 
  ShieldCheck, 
  RefreshCw,
  UserCheck,
  Dna,
  Share2
} from 'lucide-react';
import { cn } from '@/src/lib/utils';

export function DigitalTwin() {
  const [isCloning, setIsCloning] = useState(false);
  const [syncProgress, setSyncProgress] = useState(94);

  return (
    <div className="space-y-12 relative z-10 pb-20">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8">
        <div>
          <div className="flex items-center gap-3 mb-4">
            <div className="px-2 py-1 bg-omega-blue/10 border border-omega-blue/20 rounded text-[10px] font-mono text-omega-blue uppercase tracking-widest">System Sync v2.4</div>
            <div className="px-2 py-1 bg-omega-gold/10 border border-omega-gold/20 rounded text-[10px] font-mono text-omega-gold uppercase tracking-widest">Identity Secured</div>
          </div>
          <h2 className="text-5xl font-display text-white uppercase tracking-tighter">AI Twin System</h2>
          <p className="text-zinc-500 font-mono text-xs uppercase tracking-[0.2em] mt-2">Creative Identity Replication & Logic Matching</p>
        </div>
        
        <div className="flex items-center gap-6">
          <div className="bg-zinc-900/50 border border-white/5 px-6 py-4 rounded-2xl flex items-center gap-5 hardware-border">
            <div className="flex flex-col items-end">
              <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Sync Status</span>
              <span className="text-omega-blue font-mono font-bold text-lg tracking-tighter">OPTIMIZED</span>
            </div>
            <div className="w-12 h-12 bg-omega-blue/10 rounded-xl flex items-center justify-center border border-omega-blue/20">
              <UserCheck className="text-omega-blue w-6 h-6" />
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        <div className="lg:col-span-2 space-y-8">
          <div className="glass-card p-10 relative overflow-hidden border-omega-blue/20">
            <div className="absolute top-0 right-0 p-12 opacity-5 pointer-events-none">
              <Dna className="w-80 h-80 text-omega-blue animate-pulse" />
            </div>
            
            <div className="relative z-10">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-12 h-12 bg-omega-blue/10 rounded-2xl flex items-center justify-center border border-omega-blue/20">
                  <Fingerprint className="text-omega-blue w-6 h-6" />
                </div>
                <h3 className="text-3xl font-display text-white uppercase tracking-tight">Identity Processing Sync</h3>
              </div>
              
              <p className="text-zinc-500 mb-12 max-w-xl font-light leading-relaxed">
                Your AI Twin autonomously synthesizes your creative style by analyzing historical scripts, visual preferences, and decision-making patterns to replicate your unique <span className="text-omega-blue font-mono uppercase tracking-widest text-[10px] ml-1">Creative DNA</span>.
              </p>
              
              <div className="space-y-10">
                {[
                  { label: 'Tone & Voice Matching', value: 98, color: 'bg-omega-blue' },
                  { label: 'Creative Decision Logic', value: 92, color: 'bg-omega-gold' },
                  { label: 'Visual Style Consistency', value: 95, color: 'bg-omega-blue' },
                ].map((item, i) => (
                  <div key={i} className="space-y-4">
                    <div className="flex justify-between items-end">
                      <span className="text-[10px] font-mono text-zinc-400 uppercase tracking-widest">{item.label}</span>
                      <span className="text-white font-mono text-sm">{item.value}%</span>
                    </div>
                    <div className="w-full bg-zinc-900 h-1 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${item.value}%` }}
                        transition={{ duration: 1.5, delay: i * 0.2 }}
                        className={cn("h-full shadow-[0_0_10px_rgba(0,102,255,0.3)]", item.color)} 
                      />
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-12 flex flex-wrap gap-6">
                <button 
                  onClick={() => setIsCloning(true)}
                  className="bg-omega-blue hover:bg-blue-700 text-white px-10 py-5 rounded-2xl font-bold transition-all flex items-center gap-3 shadow-2xl shadow-omega-blue/20 active:scale-95 uppercase tracking-widest text-xs"
                >
                  {isCloning ? <RefreshCw className="w-5 h-5 animate-spin" /> : <Cpu className="w-5 h-5 fill-white/20" />}
                  Update AI Model
                </button>
                <button className="bg-zinc-900 hover:bg-zinc-800 text-zinc-400 px-10 py-5 rounded-2xl font-bold transition-all flex items-center gap-3 hardware-border uppercase tracking-widest text-xs">
                  <Share2 className="w-5 h-5" />
                  Export Identity
                </button>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="glass-card p-8 group hover:border-omega-blue/40 transition-all">
              <div className="w-14 h-14 bg-omega-blue/10 rounded-2xl flex items-center justify-center mb-6 border border-omega-blue/20 group-hover:bg-omega-blue group-hover:text-white transition-all">
                <Brain className="text-omega-blue w-7 h-7 group-hover:text-white" />
              </div>
              <h4 className="text-xl font-display text-white uppercase tracking-tight mb-3">Autonomous Mode</h4>
              <p className="text-zinc-500 text-sm leading-relaxed font-light mb-6">Allow your Twin to make creative decisions without manual approval based on your learned preferences.</p>
              <div className="flex items-center gap-3">
                <div className="w-12 h-6 bg-emerald-500/20 rounded-full relative border border-emerald-500/30">
                  <div className="absolute right-1 top-1 w-3.5 h-3.5 bg-emerald-500 rounded-full shadow-[0_0_8px_rgba(16,185,129,0.8)]" />
                </div>
                <span className="text-[10px] font-mono text-emerald-500 uppercase tracking-widest">Active</span>
              </div>
            </div>
            
            <div className="glass-card p-8 group hover:border-omega-gold/40 transition-all">
              <div className="w-14 h-14 bg-omega-gold/10 rounded-2xl flex items-center justify-center mb-6 border border-omega-gold/20 group-hover:bg-omega-gold group-hover:text-white transition-all">
                <ShieldCheck className="text-omega-gold w-7 h-7 group-hover:text-white" />
              </div>
              <h4 className="text-xl font-display text-white uppercase tracking-tight mb-3">Governance Guard</h4>
              <p className="text-zinc-500 text-sm leading-relaxed font-light mb-6">Strict policy enforcement to ensure your Twin never violates platform guidelines or brand safety.</p>
              <div className="flex items-center gap-3">
                <div className="w-12 h-6 bg-zinc-800 rounded-full relative border border-white/5">
                  <div className="absolute left-1 top-1 w-3.5 h-3.5 bg-zinc-600 rounded-full" />
                </div>
                <span className="text-[10px] font-mono text-zinc-600 uppercase tracking-widest">Standby</span>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-8">
          <div className="glass-card p-8 border-omega-blue/20">
            <div className="flex items-center gap-4 mb-8">
              <div className="w-12 h-12 bg-omega-blue/10 rounded-2xl flex items-center justify-center border border-omega-blue/20">
                <Zap className="text-omega-blue w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-display text-white uppercase tracking-tight">Pattern Learning</h3>
                <p className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Real-time Ingestion</p>
              </div>
            </div>
            
            <div className="space-y-4">
              {[
                { event: 'New Script Approved', impact: '+1.2% Logic Sync', color: 'text-omega-blue' },
                { event: 'Thumbnail A/B Test Result', impact: '+0.8% Visual Sync', color: 'text-omega-gold' },
                { event: 'Retention Data Ingested', impact: '+2.5% Strategy Sync', color: 'text-omega-blue' },
                { event: 'Manual Edit Detected', impact: 'Updating Nuances...', color: 'text-zinc-500' },
              ].map((log, i) => (
                <motion.div 
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.1 }}
                  key={i} 
                  className="flex items-start gap-4 p-4 bg-white/5 rounded-2xl border border-white/5 hover:border-white/10 transition-all group"
                >
                  <div className={cn("w-1.5 h-1.5 rounded-full mt-2 shrink-0 animate-pulse", log.color.replace('text', 'bg'))} />
                  <div>
                    <p className="text-white text-xs font-bold uppercase tracking-tight">{log.event}</p>
                    <p className={cn("text-[10px] font-mono uppercase tracking-widest mt-1", log.color)}>{log.impact}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          <div className="bg-gradient-to-br from-omega-gold/10 via-omega-black to-omega-black border border-omega-gold/20 rounded-[2.5rem] p-8 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 opacity-5 pointer-events-none">
              <Zap className="w-40 h-40 text-omega-gold animate-pulse" />
            </div>
            
            <h3 className="text-2xl font-display text-white uppercase tracking-tight mb-4 relative z-10">Advanced Execution</h3>
            <p className="text-zinc-500 text-xs leading-relaxed mb-8 font-light relative z-10">
              The advanced execution layer allows your AI Twin to operate at high speed, managing multiple channels simultaneously with perfect identity consistency.
            </p>
            
            <div className="p-6 bg-black/40 rounded-[2rem] border border-white/5 relative z-10 hardware-border">
              <div className="flex justify-between text-[10px] font-mono text-zinc-500 uppercase mb-3 tracking-widest">
                <span>Parallel Channels</span>
                <span className="text-white">12 / 50</span>
              </div>
              <div className="w-full bg-zinc-900 h-1 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: '24%' }}
                  transition={{ duration: 2 }}
                  className="bg-omega-gold h-full shadow-[0_0_10px_rgba(255,170,0,0.5)]" 
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
