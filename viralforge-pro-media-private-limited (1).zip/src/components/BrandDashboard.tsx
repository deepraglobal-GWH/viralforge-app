import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Briefcase, 
  Youtube, 
  Instagram, 
  Facebook, 
  Activity, 
  Globe, 
  Search,
  Filter,
  BarChart2,
  LayoutGrid
} from 'lucide-react';
import { cn } from '../lib/utils';
import { db, auth } from '../lib/firebase';
import { collection, query, where, getDocs, onSnapshot } from 'firebase/firestore';
import { BRANDS } from '../factory/core/brands';

export function BrandDashboard() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedNiche, setSelectedNiche] = useState('All');
  const [projectStats, setProjectStats] = useState<Record<string, any>>({});

  useEffect(() => {
    if (!auth.currentUser) return;

    const q = query(
      collection(db, 'users', auth.currentUser.uid, 'projects')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const stats: Record<string, any> = {};
      snapshot.docs.forEach(doc => {
        const data = doc.data();
        const brandId = data.brandId;
        if (brandId) {
          if (!stats[brandId]) stats[brandId] = { total: 0, completed: 0, pending: 0 };
          stats[brandId].total++;
          if (data.status === 'completed') stats[brandId].completed++;
          else stats[brandId].pending++;
        }
      });
      setProjectStats(stats);
    });

    return () => unsubscribe();
  }, []);

  const niches = ['All', ...Array.from(new Set(BRANDS.map(b => b.niche)))];
  const filteredBrands = BRANDS.filter(brand => {
    const matchesSearch = brand.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          brand.niche.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesNiche = selectedNiche === 'All' || brand.niche === selectedNiche;
    return matchesSearch && matchesNiche;
  });

  return (
    <div className="space-y-12 relative z-10 pb-20">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8">
        <div>
          <div className="flex items-center gap-3 mb-4">
            <div className="px-2 py-1 bg-omega-blue/10 border border-omega-blue/20 rounded text-[10px] font-mono text-omega-blue uppercase tracking-widest">Enterprise Network</div>
            <div className="px-2 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded text-[10px] font-mono text-emerald-500 uppercase tracking-widest">99 Assets Live</div>
          </div>
          <h2 className="text-5xl font-display text-white uppercase tracking-tighter">Brand Matrix</h2>
          <p className="text-zinc-500 font-mono text-xs uppercase tracking-[0.2em] mt-2">Managing 33 Multi-Platform Digital Brands</p>
        </div>

        <div className="flex items-center gap-4 bg-zinc-900/50 border border-white/5 p-2 rounded-2xl hardware-border">
            <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                <input 
                    type="text" 
                    placeholder="Search Brands..." 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="bg-black/40 border border-white/5 pl-11 pr-4 py-3 rounded-xl text-xs text-white focus:outline-none focus:border-omega-blue/50 w-64 font-mono"
                />
            </div>
            <select 
                value={selectedNiche}
                onChange={(e) => setSelectedNiche(e.target.value)}
                className="bg-black/40 border border-white/5 px-4 py-3 rounded-xl text-[10px] text-zinc-400 uppercase tracking-widest focus:outline-none focus:border-omega-blue/50 font-mono"
            >
                {niches.map(n => <option key={n} value={n}>{n}</option>)}
            </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredBrands.map((brand, i) => (
          <motion.div 
            key={brand.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.02 }}
            className="glass-card group hover:border-omega-blue/30 transition-all p-6 relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 p-6 opacity-5 group-hover:opacity-10 transition-opacity pointer-events-none">
              <BarChart2 className="w-24 h-24" />
            </div>

            <div className="flex items-start justify-between mb-6">
              <div className="w-12 h-12 bg-white/5 rounded-xl flex items-center justify-center border border-white/10 group-hover:bg-omega-blue/20 group-hover:border-omega-blue/30 transition-all">
                <Briefcase className="w-6 h-6 text-zinc-400 group-hover:text-omega-blue" />
              </div>
              <div className="flex gap-2">
                <Youtube className={cn("w-4 h-4", projectStats[brand.id]?.total ? "text-red-500" : "text-zinc-700")} />
                <Instagram className={cn("w-4 h-4", projectStats[brand.id]?.total ? "text-pink-500" : "text-zinc-700")} />
                <Facebook className={cn("w-4 h-4", projectStats[brand.id]?.total ? "text-blue-500" : "text-zinc-700")} />
              </div>
            </div>

            <h3 className="text-lg font-display text-white uppercase tracking-tight mb-1 group-hover:text-omega-blue transition-colors truncate">
              {brand.name}
            </h3>
            <p className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest mb-4">
              {brand.niche}
            </p>

            <div className="space-y-4 relative z-10">
              <div className="flex justify-between items-center text-[10px] font-mono uppercase tracking-widest">
                <span className="text-zinc-500">Production</span>
                <span className="text-white">{projectStats[brand.id]?.total || 0} Assets</span>
              </div>
              <div className="w-full bg-white/5 h-1 rounded-full overflow-hidden">
                <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${projectStats[brand.id]?.total ? (projectStats[brand.id].completed / projectStats[brand.id].total) * 100 : 0}%` }}
                    className="bg-emerald-500 h-full"
                />
              </div>
              <div className="flex justify-between items-center">
                 <span className="text-[9px] font-mono text-emerald-500 uppercase tracking-tighter">
                    {projectStats[brand.id]?.completed || 0} LIVE
                 </span>
                 <span className="text-[9px] font-mono text-omega-gold uppercase tracking-tighter">
                    {projectStats[brand.id]?.pending || 0} PROCESSING
                 </span>
              </div>
            </div>

            <div className="mt-6 pt-6 border-t border-white/5 flex items-center justify-between">
                <span className="text-[9px] font-mono text-zinc-600 uppercase tracking-widest">Identity: Consistent</span>
                <div className="flex -space-x-2">
                    {[1,2,3].map(j => (
                        <div key={j} className="w-5 h-5 rounded-full border border-black bg-zinc-800 flex items-center justify-center text-[8px] text-zinc-500 font-mono">
                           {brand.name[0]}
                        </div>
                    ))}
                </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
