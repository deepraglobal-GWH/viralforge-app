import React from 'react';
import { motion } from 'framer-motion';
import { 
  Bot, 
  UserCheck, 
  Search, 
  FileText, 
  Mic2, 
  ImageIcon, 
  Upload, 
  Settings2,
  Zap,
  Cpu,
  ShieldCheck,
  Infinity as InfinityIcon
} from 'lucide-react';
import { cn } from '@/src/lib/utils';

const agents = [
  {
    id: 'ceo',
    name: 'Video Orchestrator',
    role: 'Central Controller',
    description: 'Autonomous decision maker. Manages video lifecycle and sets daily production schedules.',
    icon: Bot,
    status: 'active',
    power: 98,
    tasks: ['Sequence Planning', 'Asset Coordination', 'Production Logic']
  },
  {
    id: 'researcher',
    name: 'Trend Researcher',
    role: 'Market Analyst',
    description: 'Scans YouTube, Google Trends, and Social Media for viral opportunities.',
    icon: Search,
    status: 'active',
    power: 92,
    tasks: ['Trend Discovery', 'Keyword Analysis', 'Competitor Intel']
  },
  {
    id: 'writer',
    name: 'Content Writer',
    role: 'Script Architect',
    description: 'Generates high-retention scripts using advanced NLP models.',
    icon: FileText,
    status: 'active',
    power: 95,
    tasks: ['Hook Optimization', 'Script Generation', 'CTA Placement']
  },
  {
    id: 'voice',
    name: 'Voice System',
    role: 'Audio Engineer',
    description: 'Manages ElevenLabs integration and emotional tone of narration.',
    icon: Mic2,
    status: 'idle',
    power: 88,
    tasks: ['TTS Generation', 'Tone Modulation', 'Audio Mastering']
  },
  {
    id: 'visuals',
    name: 'Creative Visuals',
    role: 'Creative Director',
    description: 'Generates thumbnails and scene assets using stability models.',
    icon: ImageIcon,
    status: 'active',
    power: 90,
    tasks: ['Thumbnail Generation', 'Asset Creation', 'Visual Branding']
  },
  {
    id: 'uploader',
    name: 'Asset Distributer',
    role: 'Release Manager',
    description: 'Handles YouTube API uploads and metadata optimization.',
    icon: Upload,
    status: 'idle',
    power: 85,
    tasks: ['Metadata Sync', 'Publishing', 'Policy Check']
  }
];

export function AIAgents() {
  return (
    <div className="space-y-12 relative z-10 pb-20">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8">
        <div>
          <div className="flex items-center gap-3 mb-4">
            <div className="px-2 py-1 bg-omega-infinity/10 border border-omega-infinity/20 rounded text-[10px] font-mono text-omega-infinity uppercase tracking-widest">Automation Hub v2.0</div>
            <div className="px-2 py-1 bg-omega-gold/10 border border-omega-gold/20 rounded text-[10px] font-mono text-omega-gold uppercase tracking-widest">System Online</div>
          </div>
          <h2 className="text-5xl font-display text-white uppercase tracking-tighter">System Automation</h2>
          <p className="text-zinc-500 font-mono text-xs uppercase tracking-[0.2em] mt-2">Managing Specialized Content Production Services</p>
        </div>
        
        <button className="bg-zinc-900 hover:bg-zinc-800 text-white px-8 py-4 rounded-2xl font-bold flex items-center gap-3 border border-zinc-800 transition-all hardware-border group">
          <Settings2 className="w-5 h-5 text-zinc-600 group-hover:text-omega-infinity transition-colors" />
          <span className="text-sm uppercase tracking-widest font-mono">Configuration Settings</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
        {agents.map((agent, i) => (
          <motion.div
            key={agent.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="glass-card p-10 group hover:border-omega-infinity/40 transition-all relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity pointer-events-none">
              <agent.icon className="w-32 h-32 text-omega-infinity" />
            </div>

            <div className="flex items-start justify-between mb-10">
              <div className="flex items-center gap-6">
                <div className={cn(
                  "w-16 h-16 rounded-[1.5rem] flex items-center justify-center shadow-2xl transition-all duration-500",
                  agent.status === 'active' ? "bg-omega-infinity shadow-omega-infinity/30" : "bg-zinc-800"
                )}>
                  <agent.icon className="text-white w-8 h-8 fill-white/10" />
                </div>
                <div>
                  <h3 className="text-2xl font-display text-white uppercase tracking-tight">{agent.name}</h3>
                  <p className="text-omega-infinity font-mono text-[10px] uppercase tracking-[0.2em] mt-1">{agent.role}</p>
                </div>
              </div>
              <div className={cn(
                "px-3 py-1.5 rounded-lg text-[9px] font-mono uppercase tracking-widest border",
                agent.status === 'active' ? "text-emerald-500 border-emerald-500/20 bg-emerald-500/5" : "text-zinc-600 border-zinc-800 bg-zinc-800/50"
              )}>
                {agent.status}
              </div>
            </div>

            <p className="text-zinc-500 text-sm leading-relaxed mb-10 font-light italic">
              "{agent.description}"
            </p>

            <div className="space-y-8">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono text-zinc-600 uppercase tracking-widest">Operational Efficiency</span>
                  <span className="text-white text-xs font-mono">{agent.power}%</span>
                </div>
                <div className="w-full bg-zinc-900 h-1 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${agent.power}%` }}
                    transition={{ duration: 1.5, delay: 0.5 }}
                    className="bg-omega-infinity h-full shadow-[0_0_15px_rgba(124,58,237,0.5)]" 
                  />
                </div>
              </div>
            </div>

            <div className="mt-10 pt-10 border-t border-white/5">
              <h4 className="text-[10px] font-mono text-zinc-600 uppercase tracking-widest mb-6">Execution Directives</h4>
              <div className="flex flex-wrap gap-3">
                {agent.tasks.map((task, j) => (
                  <span key={j} className="text-[9px] font-mono bg-white/5 text-zinc-400 px-4 py-2 rounded-xl border border-white/5 uppercase tracking-tighter">
                    {task}
                  </span>
                ))}
              </div>
            </div>

            <button className="w-full mt-10 py-5 bg-zinc-900 hover:bg-omega-infinity hover:text-white text-zinc-400 rounded-[1.5rem] text-xs font-bold uppercase tracking-widest transition-all flex items-center justify-center gap-3 hardware-border group/btn">
              <Zap className="w-4 h-4 text-omega-gold fill-omega-gold/20 group-hover/btn:text-white" />
              Configure System
            </button>
          </motion.div>
        ))}
      </div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-gradient-to-br from-omega-infinity/10 via-omega-black to-omega-black border border-omega-infinity/20 p-12 rounded-[3rem] flex flex-col lg:flex-row items-center justify-between gap-12 relative overflow-hidden"
      >
        <div className="absolute top-0 left-0 p-12 opacity-5 pointer-events-none">
          <InfinityIcon className="w-64 h-64 text-omega-infinity animate-pulse" />
        </div>

        <div className="flex items-center gap-10 relative z-10">
          <div className="w-24 h-24 bg-omega-infinity rounded-[2.5rem] flex items-center justify-center shadow-2xl shadow-omega-infinity/40">
            <Cpu className="text-white w-12 h-12 animate-pulse" />
          </div>
          <div>
            <h3 className="text-4xl font-display text-white uppercase tracking-tight">System Core Engine</h3>
            <p className="text-zinc-500 font-mono text-sm uppercase tracking-widest mt-1">High-Performance Scale Protocol Active</p>
          </div>
        </div>

        <div className="flex items-center gap-10 relative z-10">
          <div className="text-right">
            <span className="text-[10px] font-mono text-omega-infinity uppercase tracking-widest mb-1 block">Security Level</span>
            <div className="flex items-center gap-3 text-white font-mono text-sm uppercase tracking-tighter">
              <ShieldCheck className="w-5 h-5 text-emerald-500" />
              SYSTEM PROTECTED
            </div>
          </div>
          <button className="bg-white text-black px-12 py-6 rounded-[2rem] font-bold text-xl hover:bg-zinc-200 transition-all shadow-2xl shadow-white/10 uppercase tracking-widest">
            Manage System
          </button>
        </div>
      </motion.div>
    </div>
  );
}
