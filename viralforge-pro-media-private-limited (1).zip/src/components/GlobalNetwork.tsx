import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Network, 
  Globe, 
  Share2, 
  Zap, 
  MessageSquare, 
  Repeat, 
  ArrowUpRight,
  ShieldCheck,
  Cpu
} from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { db, auth } from '../lib/firebase';
import { collection, query, orderBy, onSnapshot, limit } from 'firebase/firestore';

export function GlobalNetwork() {
  const [projects, setProjects] = useState<any[]>([]);
  const [selectedProject, setSelectedProject] = useState<any>(null);

  useEffect(() => {
    if (!auth.currentUser) return;
    const q = query(
      collection(db, 'users', auth.currentUser.uid, 'projects'),
      orderBy('createdAt', 'desc'),
      limit(5)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as any[];
      setProjects(data);
      if (data.length > 0 && !selectedProject) {
        setSelectedProject(data[0]);
      }
    });

    return () => unsubscribe();
  }, []);

  const distribution = selectedProject?.distribution || {
    TikTok: { hook: 'Wait for the end...', caption: 'This is going viral! #fyp' },
    Instagram: { hook: 'POV: You found the secret...', caption: 'New video out now! 🚀' },
    X: { hook: 'The truth about...', caption: 'Thread on why this matters. 🧵' }
  };

  return (
    <div className="space-y-8 relative z-10">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white flex items-center gap-3">
            <Network className="text-blue-500 w-8 h-8" />
            Global Distribution Network
          </h2>
          <p className="text-zinc-400 mt-1">Multi-platform domination and autonomous content distribution.</p>
        </div>
        <div className="flex items-center gap-4">
          <select 
            onChange={(e) => setSelectedProject(projects.find(p => p.id === e.target.value))}
            className="bg-zinc-900 border border-zinc-800 text-white px-4 py-2 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-600/50"
          >
            {projects.map(p => (
              <option key={p.id} value={p.id}>{p.title}</option>
            ))}
          </select>
          <div className="bg-blue-500/10 border border-blue-500/20 px-4 py-2 rounded-xl">
            <span className="text-[10px] font-bold text-blue-500 uppercase tracking-widest">Network Status</span>
            <p className="text-white font-bold">SYNCHRONIZED</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-zinc-900 border border-zinc-800 rounded-3xl p-8 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-5">
            <Globe className="w-64 h-64 text-blue-500" />
          </div>
          
          <div className="relative z-10">
            <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
              <Share2 className="text-blue-500 w-5 h-5" />
              Platform Integration
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                { name: 'TikTok', status: 'Active', reach: '840K', color: 'bg-zinc-800', plan: distribution.TikTok },
                { name: 'Instagram', status: 'Active', reach: '620K', color: 'bg-gradient-to-tr from-blue-500 to-indigo-600', plan: distribution.Instagram },
                { name: 'X (Twitter)', status: 'Active', reach: '310K', color: 'bg-zinc-950', plan: distribution.X },
                { name: 'YouTube Shorts', status: 'Active', reach: '1.2M', color: 'bg-red-600', plan: { hook: 'Viral Hook', caption: 'Watch now!' } },
              ].map((platform, i) => (
                <div key={i} className="p-6 bg-zinc-800/30 rounded-2xl border border-zinc-800/50 flex flex-col gap-4 group hover:border-blue-500/30 transition-all">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center shadow-lg", platform.color)}>
                        <Zap className="text-white w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="text-white font-bold text-sm">{platform.name}</h4>
                        <p className="text-zinc-500 text-[10px] uppercase font-bold tracking-widest">{platform.status}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-white font-mono font-bold">{platform.reach}</p>
                    </div>
                  </div>
                  
                  {platform.plan && (
                    <div className="space-y-2 pt-2 border-t border-zinc-800/50">
                      <p className="text-[10px] font-bold text-purple-500 uppercase">AI Optimized Hook</p>
                      <p className="text-white text-xs italic">"{platform.plan.hook}"</p>
                    </div>
                  )}
                </div>
              ))}
            </div>

            <div className="mt-10 p-6 bg-purple-500/5 border border-purple-500/10 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-purple-600 rounded-xl flex items-center justify-center">
                  <Repeat className="text-white w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-white font-bold">Autonomous Repurposing</h4>
                  <p className="text-zinc-500 text-sm">Long-form videos are automatically cut into viral shorts/reels.</p>
                </div>
              </div>
              <button className="bg-white text-black px-6 py-3 rounded-xl font-bold hover:bg-zinc-200 transition-all">
                Configure Rules
              </button>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6">
            <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
              <MessageSquare className="text-purple-500 w-5 h-5" />
              Community Engagement
            </h3>
            <div className="space-y-4">
              <div className="p-4 bg-zinc-800/30 rounded-2xl border border-zinc-800/50">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs font-bold text-zinc-500 uppercase">AI Comment Reply</span>
                  <span className="text-emerald-500 text-[10px] font-bold">98% SUCCESS</span>
                </div>
                <p className="text-white text-sm font-bold">1,242 Replies Sent</p>
                <p className="text-zinc-500 text-[10px] mt-1">Last 24 hours across all platforms.</p>
              </div>
              <div className="p-4 bg-zinc-800/30 rounded-2xl border border-zinc-800/50">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs font-bold text-zinc-500 uppercase">Sentiment Analysis</span>
                  <span className="text-blue-500 text-[10px] font-bold">POSITIVE</span>
                </div>
                <div className="w-full bg-zinc-800 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-emerald-500 h-full w-[85%]" />
                </div>
              </div>
            </div>
          </div>

          <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6">
            <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
              <Cpu className="text-purple-500 w-5 h-5" />
              Network Load
            </h3>
            <div className="space-y-4">
              {[
                { label: 'Upload Queue', value: '0 Items', status: 'clear' },
                { label: 'Repurposing', value: '4 Tasks', status: 'active' },
                { label: 'Sync Latency', value: '42ms', status: 'optimal' },
              ].map((item, i) => (
                <div key={i} className="flex items-center justify-between text-sm">
                  <span className="text-zinc-500">{item.label}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-white font-mono">{item.value}</span>
                    <div className={cn(
                      "w-1.5 h-1.5 rounded-full",
                      item.status === 'optimal' || item.status === 'clear' ? "bg-emerald-500" : "bg-blue-500"
                    )} />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <button className="w-full py-4 bg-purple-600 hover:bg-purple-700 text-white rounded-2xl font-bold transition-all shadow-lg shadow-purple-600/20 flex items-center justify-center gap-2 active:scale-95">
            Expand Network
            <ArrowUpRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
