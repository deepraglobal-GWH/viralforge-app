import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Target, 
  TrendingUp, 
  BarChart2, 
  Globe, 
  Zap, 
  Compass,
  LineChart,
  PieChart,
  ArrowUpRight,
  Loader2,
  Sparkles
} from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { db, auth } from '../lib/firebase';
import { doc, onSnapshot } from 'firebase/firestore';
import { orchestrator } from '../services/bridge';

export function StrategyAI() {
  const [strategy, setStrategy] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!auth.currentUser) return;
    const unsubscribe = onSnapshot(doc(db, 'users', auth.currentUser.uid, 'config', 'ceo_strategy'), (doc) => {
      if (doc.exists()) {
        setStrategy(doc.data());
      }
    });
    return () => unsubscribe();
  }, []);

  const handleGenerateStrategy = async () => {
    setLoading(true);
    try {
      await orchestrator.generateCEOStrategy('AI Technology & Business Automation');
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const roadmap = strategy?.roadmap || [
    { title: 'Month 1-3: Market Saturation', status: 'completed', description: 'Deploy target niche channels. Reach audience milestones using rapid content production.' },
    { title: 'Month 4-6: Reach Expansion', status: 'active', description: 'Auto-localization in key languages. Reach regional markets (India, Brazil, USA) simultaneously.' },
    { title: 'Month 7-9: Revenue Optimization', status: 'pending', description: 'Scale monthly revenue via automated partnerships and affiliate funnels.' },
    { title: 'Month 10-12: Global Scaling Strategy', status: 'pending', description: 'High-level scaling. Portfolio acquisition and market valuation growth.' },
  ];

  const insights = strategy?.insights || [
    { title: 'Pivot to Long-form', description: 'Shorts reach is peaking. Strategy AI suggests 12-15min deep dives for higher RPM.' },
    { title: 'Brand Collaboration', description: 'High affinity detected with "NVIDIA". Outreach recommended for Q3.' },
    { title: 'Competitor Gap', description: 'No one is covering "AI Ethics" in Hindi. Massive opportunity for expansion.' },
  ];

  return (
    <div className="space-y-12 relative z-10 pb-20">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8">
        <div>
          <div className="flex items-center gap-3 mb-4">
            <div className="px-2 py-1 bg-omega-blue/10 border border-omega-blue/20 rounded text-[10px] font-mono text-omega-blue uppercase tracking-widest">Growth Link v4.0</div>
            <div className="px-2 py-1 bg-omega-gold/10 border border-omega-gold/20 rounded text-[10px] font-mono text-omega-gold uppercase tracking-widest">Steady Growth</div>
          </div>
          <h2 className="text-5xl font-display text-white uppercase tracking-tighter">Strategy Planner</h2>
          <p className="text-zinc-500 font-mono text-xs uppercase tracking-[0.2em] mt-2">Long-term business growth and platform planning</p>
        </div>
        
        <div className="flex flex-wrap items-center gap-6">
          <button 
            onClick={handleGenerateStrategy}
            disabled={loading}
            className="bg-omega-blue hover:bg-blue-700 disabled:opacity-50 text-white px-10 py-5 rounded-2xl font-bold flex items-center gap-3 transition-all active:scale-95 shadow-2xl shadow-omega-blue/20 uppercase tracking-widest text-xs"
          >
            {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5 fill-white/20" />}
            {strategy ? 'Recalculate Strategy' : 'Generate Growth Strategy'}
          </button>
          
          <div className="bg-zinc-900/50 border border-white/5 px-6 py-4 rounded-2xl flex flex-col items-end hardware-border">
            <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest mb-1">Strategy Mode</span>
            <p className="text-white font-display text-lg tracking-tight uppercase">Aggressive Growth</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        <div className="lg:col-span-2 space-y-8">
          <div className="glass-card p-10 relative overflow-hidden border-omega-blue/20">
            <div className="absolute top-0 right-0 p-12 opacity-5 pointer-events-none">
              <Compass className="w-64 h-64 text-omega-blue animate-pulse" />
            </div>
            
            <h3 className="text-2xl font-display text-white mb-10 flex items-center gap-4 uppercase tracking-tight">
              <Compass className="text-omega-blue w-6 h-6" />
              Growth Roadmap
            </h3>
            
            <div className="relative space-y-12 before:absolute before:left-[15px] before:top-2 before:bottom-2 before:w-[1px] before:bg-white/5">
              {roadmap.map((step: any, i: number) => (
                <div key={i} className="relative pl-12 group">
                  <div className={cn(
                    "absolute left-0 top-1 w-8 h-8 rounded-xl border-2 border-omega-black flex items-center justify-center transition-all duration-500",
                    step.status === 'completed' ? "bg-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.5)]" : 
                    step.status === 'active' ? "bg-omega-blue animate-pulse shadow-[0_0_15px_rgba(0,102,255,0.5)]" : "bg-zinc-900 border-white/5"
                  )}>
                    {step.status === 'completed' && <Zap className="w-3 h-3 text-white fill-white" />}
                  </div>
                  <h4 className={cn(
                    "text-xl font-display uppercase tracking-tight transition-colors",
                    step.status === 'completed' ? "text-emerald-500" : 
                    step.status === 'active' ? "text-white" : "text-zinc-600"
                  )}>{step.title}</h4>
                  <p className="text-zinc-500 text-sm mt-2 font-light leading-relaxed max-w-2xl">{step.description}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="glass-card p-8 group hover:border-omega-blue/40 transition-all">
              <div className="flex justify-between items-start mb-8">
                <div className="w-14 h-14 bg-omega-blue/10 rounded-2xl flex items-center justify-center border border-omega-blue/20 group-hover:bg-omega-blue group-hover:text-white transition-all">
                  <TrendingUp className="text-omega-blue w-7 h-7 group-hover:text-white" />
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest block mb-1">Target Share</span>
                  <span className="text-omega-blue font-display text-xl uppercase tracking-tighter">{strategy?.marketShare || '85'}%</span>
                </div>
              </div>
              <h4 className="text-xl font-display text-white uppercase tracking-tight mb-2">Market Share</h4>
              <p className="text-zinc-500 text-xs mb-8 font-mono uppercase tracking-widest">Influence in "{strategy?.niche || 'AI Tech'}" category</p>
              
              <div className="h-32 flex items-end gap-2">
                {[40, 60, 45, 70, 85, 65, 90].map((h, i) => (
                  <div key={i} className="flex-1 bg-white/5 rounded-t-lg relative group/bar overflow-hidden">
                    <motion.div 
                      initial={{ height: 0 }}
                      animate={{ height: `${h}%` }}
                      transition={{ duration: 1, delay: i * 0.1 }}
                      className="absolute bottom-0 left-0 right-0 bg-omega-blue/40 group-hover/bar:bg-omega-blue transition-all" 
                    />
                  </div>
                ))}
              </div>
            </div>
            
            <div className="glass-card p-8 group hover:border-omega-gold/40 transition-all">
              <div className="flex justify-between items-start mb-8">
                <div className="w-14 h-14 bg-omega-gold/10 rounded-2xl flex items-center justify-center border border-omega-gold/20 group-hover:bg-omega-gold group-hover:text-white transition-all">
                  <Globe className="text-omega-gold w-7 h-7 group-hover:text-white" />
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest block mb-1">Reach</span>
                  <span className="text-omega-gold font-display text-xl uppercase tracking-tighter">GLOBAL</span>
                </div>
              </div>
              <h4 className="text-xl font-display text-white uppercase tracking-tight mb-2">Global Impact</h4>
              <p className="text-zinc-500 text-xs mb-8 font-mono uppercase tracking-widest">Audience distribution by region</p>
              
              <div className="space-y-5">
                {[
                  { label: 'North America', val: 45, color: 'bg-omega-blue' },
                  { label: 'Europe', val: 30, color: 'bg-omega-gold' },
                  { label: 'Asia', val: 25, color: 'bg-omega-blue' },
                ].map((item, i) => (
                  <div key={i} className="space-y-2">
                    <div className="flex justify-between text-[10px] font-mono text-zinc-500 uppercase tracking-widest">
                      <span>{item.label}</span>
                      <span className="text-white">{item.val}%</span>
                    </div>
                    <div className="w-full bg-white/5 h-1 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${item.val}%` }}
                        transition={{ duration: 1, delay: i * 0.2 }}
                        className={cn("h-full", item.color)} 
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-8">
          <div className="glass-card p-8 border-omega-blue/20">
            <div className="flex items-center gap-4 mb-8">
              <div className="w-12 h-12 bg-omega-blue/10 rounded-2xl flex items-center justify-center border border-omega-blue/20">
                <Zap className="text-omega-blue w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-display text-white uppercase tracking-tight">Strategic Insights</h3>
                <p className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">AI-Generated Intel</p>
              </div>
            </div>
            
            <div className="space-y-5">
              {insights.map((insight: any, i: number) => (
                <motion.div 
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.1 }}
                  key={i} 
                  className="p-6 bg-white/5 rounded-2xl border border-white/5 hover:border-omega-blue/30 transition-all cursor-pointer group"
                >
                  <h4 className="text-white font-display uppercase tracking-tight text-sm group-hover:text-omega-blue transition-colors">{insight.title}</h4>
                  <p className="text-zinc-500 text-xs mt-2 leading-relaxed font-light">{insight.description}</p>
                </motion.div>
              ))}
            </div>
          </div>

          <div className="bg-gradient-to-br from-omega-blue/10 via-omega-black to-omega-black border border-omega-blue/20 rounded-[2.5rem] p-10 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 opacity-5 pointer-events-none">
              <LineChart className="w-40 h-40 text-omega-blue animate-pulse" />
            </div>
            
            <div className="flex items-center gap-4 mb-8 relative z-10">
              <div className="w-12 h-12 bg-omega-blue rounded-2xl flex items-center justify-center shadow-2xl shadow-omega-blue/40">
                <LineChart className="text-white w-6 h-6" />
              </div>
              <h3 className="text-xl font-display text-white uppercase tracking-tight">Revenue Projection</h3>
            </div>
            
            <p className="text-5xl font-display text-white mb-2 relative z-10 tracking-tighter">{strategy?.projections || '$142,500'}</p>
            <p className="text-zinc-500 text-[10px] font-mono uppercase tracking-widest mb-10 relative z-10">Est. Monthly Revenue by Phase 4</p>
            
            <button className="w-full py-5 bg-white text-black hover:bg-zinc-200 rounded-2xl font-bold transition-all flex items-center justify-center gap-3 uppercase tracking-widest text-xs relative z-10 shadow-2xl shadow-white/5">
              Execute Strategy
              <ArrowUpRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
