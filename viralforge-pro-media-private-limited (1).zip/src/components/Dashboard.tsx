import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { differenceInSeconds } from 'date-fns';
import { 
  Clock,
  Video,
  PlayCircle,
  Loader2,
  Youtube,
  Instagram,
  Facebook,
  CheckCheck,
  ShieldCheck,
  AlertCircle,
  Zap
} from 'lucide-react';
import { db } from '../lib/firebase';
import { collection, query, orderBy, onSnapshot, limit, doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { cn } from '../lib/utils';
import { User } from 'firebase/auth';
import { handleFirestoreError, OperationType } from '../services/error-handler';

const ADMIN_UID = 'GLOBAL_FACTORY';

export function Dashboard({ setActiveTab, user }: { setActiveTab: (tab: string) => void, user: User }) {
  const [projects, setProjects] = useState<any[]>([]);
  const [logs, setLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [strategy, setStrategy] = useState<any>(null);

  useEffect(() => {
    if (!user) return;

    // Fetch Strategy
    const unsubscribeStrategy = onSnapshot(doc(db, 'users', ADMIN_UID, 'config', 'ceo_strategy'), (doc) => {
      if (doc.exists()) setStrategy(doc.data());
    });

    // Fetch all recent projects for stats and lists
    const q = query(
      collection(db, 'users', user.uid, 'projects'),
      orderBy('createdAt', 'desc'),
      limit(100)
    );

    const unsubscribeProjects = onSnapshot(q, (snapshot) => {
      const projectsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setProjects(projectsData);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, `users/${user.uid}/projects`);
      setLoading(false);
    });

    // Fetch Logs
    const logQ = query(
      collection(db, 'users', user.uid, 'logs'),
      orderBy('timestamp', 'desc'),
      limit(20)
    );

    const unsubscribeLogs = onSnapshot(logQ, (snapshot) => {
      const logsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setLogs(logsData);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, `users/${user.uid}/logs`);
    });

    return () => {
      unsubscribeProjects();
      unsubscribeLogs();
      unsubscribeStrategy();
    };
  }, [user]);

  const stats = {
    total: projects.length,
    pending: projects.filter(p => p.status === 'pending_approval').length,
    uploaded: projects.filter(p => p.status === 'uploaded').length,
    failed: projects.filter(p => p.status === 'failed').length
  };

  const pendingVideos = projects.filter(p => p.status === 'pending_approval');
  const queueVideos = projects.filter(p => ['processing', 'pending', 'uploading'].includes(p.status));
  const failedVideos = projects.filter(p => p.status === 'failed');
  const successfulVideos = projects.filter(p => p.status === 'uploaded');

  const handleAction = async (projectId: string, action: 'approve' | 'reject') => {
    try {
      await setDoc(doc(db, 'users', user.uid, 'projects', projectId), {
        status: action === 'approve' ? 'approved' : 'rejected',
        updatedAt: serverTimestamp()
      }, { merge: true });
    } catch (error) {
      console.error(`Error ${action}ing video:`, error);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-96 text-zinc-500 font-sans">
        <Loader2 className="w-8 h-8 animate-spin mb-4 text-accent" />
        <p className="text-sm font-medium uppercase tracking-widest">Loading system data...</p>
      </div>
    );
  }

  return (
    <div className="space-y-12 pb-20 px-4 md:px-0 max-w-7xl mx-auto font-sans bg-[#020202]">
      {/* 🚀 DOMINATION HEADER */}
      <section className="pt-8 border-b border-white/5 pb-12">
        <div className="flex flex-col md:flex-row items-end justify-between gap-6">
          <div className="space-y-2">
            <h1 className="text-[6vw] md:text-8xl font-black text-white leading-[0.85] tracking-tighter uppercase italic">
              AI CONTENT <br />
              <span className="text-accent">DOMINATION</span>
            </h1>
            <p className="text-xs font-mono text-zinc-500 uppercase tracking-[0.3em] font-bold">
              ViralForge Pro Media Private Limited • Network v2.5.4
            </p>
          </div>
          <div className="flex flex-col items-end gap-2">
            <div className="flex items-center gap-2 px-4 py-2 bg-accent/10 border border-accent/20 rounded-full">
              <div className="w-1.5 h-1.5 rounded-full bg-accent animate-ping" />
              <span className="text-[10px] font-black text-accent uppercase tracking-widest">99 ASSET SWARM ACTIVE</span>
            </div>
            <p className="text-[10px] font-mono text-zinc-700 uppercase">LATENCY: 42ms • UPTIME: 99.98%</p>
          </div>
        </div>
      </section>

      {/* 📊 CORE METRICS GRID */}
      <section className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-px bg-white/5 border border-white/5 rounded-2xl overflow-hidden shadow-2xl">
        {[
          { label: 'Total Output', value: stats.total, icon: Video, color: 'text-white' },
          { label: 'Network Reach', value: '33 BRANDS', icon: ShieldCheck, color: 'text-omega-blue' },
          { label: 'Live Swarm', value: stats.uploaded, icon: Zap, color: 'text-accent' },
          { label: 'Revenue Velocity', value: `$${(stats.uploaded * 12.4).toFixed(2)}`, icon: CheckCheck, color: 'text-emerald-500' },
          { label: 'Success Rate', value: `${stats.total > 0 ? Math.round((stats.uploaded / stats.total) * 100) : 100}%`, icon: AlertCircle, color: 'text-zinc-400' }
        ].map((stat, i) => (
          <div key={i} className="bg-zinc-950 p-8 flex flex-col justify-between group hover:bg-zinc-900/50 transition-all cursor-default">
            <div className="flex items-center justify-between mb-8 opacity-40 group-hover:opacity-100 transition-opacity">
               <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest leading-none">{stat.label}</span>
               <stat.icon className={cn("w-4 h-4", stat.color)} />
            </div>
            <div className="space-y-1">
              <p className={cn("text-3xl font-black tracking-tight font-mono", stat.color)}>{stat.value}</p>
              <div className="h-0.5 w-full bg-zinc-900 overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: '100%' }}
                  transition={{ duration: 2, delay: i * 0.1 }}
                  className={cn("h-full", stat.color.replace('text', 'bg'))} 
                />
              </div>
            </div>
          </div>
        ))}
      </section>

      {/* 🧠 CEO COMMAND CENTER */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-8 h-full">
        <div className="lg:col-span-8 bg-zinc-950 border border-white/5 rounded-2xl p-10 flex flex-col justify-between relative overflow-hidden group">
           <div className="absolute -right-20 -bottom-20 opacity-[0.02] group-hover:opacity-[0.05] transition-opacity pointer-events-none">
              <Zap className="w-80 h-80 text-white" />
           </div>
           
           <div className="space-y-10 relative z-10">
              <div className="flex items-center gap-4">
                 <div className="w-8 h-12 bg-white flex flex-col">
                    <div className="h-1/3 bg-accent w-full" />
                 </div>
                 <h3 className="text-2xl font-black text-white uppercase italic tracking-tighter">Strategic Intelligence Roadmap</h3>
              </div>

              {strategy ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                   <div className="space-y-4">
                      <p className="font-serif italic text-sm text-zinc-500 border-b border-zinc-900 pb-2">Active Cycle Directives</p>
                      <div className="flex flex-wrap gap-2">
                         {strategy.cycleBrands?.map((b: string) => (
                           <span key={b} className="px-3 py-1.5 bg-zinc-900 border border-white/5 rounded text-[10px] font-bold text-white uppercase tracking-wider">{b}</span>
                         ))}
                      </div>
                   </div>
                   <div className="space-y-4">
                      <p className="font-serif italic text-sm text-zinc-500 border-b border-zinc-900 pb-2">Predictive Growth & Projections</p>
                      <p className="text-sm font-medium text-zinc-300 leading-relaxed font-mono">
                         "{strategy.projections || 'Analyzing trend velocity for next cycle...'}"
                      </p>
                   </div>
                </div>
              ) : (
                <div className="animate-pulse space-y-4">
                   <div className="h-4 bg-zinc-900 rounded w-1/4" />
                   <div className="h-20 bg-zinc-900 rounded-xl" />
                </div>
              )}
           </div>
        </div>

        <div className="lg:col-span-4 bg-zinc-950 border border-white/5 rounded-2xl p-10 flex flex-col justify-between gap-10">
           <div className="space-y-6">
              <div className="flex items-center justify-between border-b border-zinc-900 pb-4">
                 <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Neural Stability</span>
                 <span className="w-2 h-2 rounded-full bg-accent animate-pulse" />
              </div>
              <div className="space-y-4">
                 {[
                   { label: 'Factory Cortex', val: '98%', status: 'Nominal' },
                   { label: 'Trend Auditor', val: 'Active', status: 'Scanning' },
                   { label: 'Variation Engine', val: 'Cycle-3', status: 'Optimal' }
                 ].map(node => (
                   <div key={node.label} className="flex items-center justify-between group">
                      <span className="text-xs font-bold text-zinc-400 uppercase font-mono tracking-tight group-hover:text-white transition-colors">{node.label}</span>
                      <span className="text-[9px] font-black font-mono text-accent uppercase">{node.val}</span>
                   </div>
                 ))}
              </div>
           </div>
           <button 
             onClick={() => setActiveTab('warroom')}
             className="w-full py-4 bg-white text-black font-black text-xs uppercase tracking-[0.2em] transform transition-transform hover:-translate-y-1 active:scale-95 flex items-center justify-center gap-2"
           >
             Enter War Room <Zap className="w-3 h-3 fill-current" />
           </button>
        </div>
      </section>

      {/* 📋 PRODUCTION DATA GRID */}
      <section className="bg-zinc-950 border border-white/5 rounded-2xl overflow-hidden shadow-2xl">
        <div className="p-10 border-b border-zinc-900 flex items-center justify-between">
           <h3 className="text-xs font-black text-white uppercase tracking-[0.3em]">Viral Production Terminal</h3>
           <div className="flex items-center gap-8 text-[10px] font-bold font-mono text-zinc-600">
              <div className="flex items-center gap-2">
                 <div className="w-2 h-2 rounded-full bg-blue-500" />
                 <span>RENDERING: {queueVideos.filter(v => v.status === 'processing').length}</span>
              </div>
              <div className="flex items-center gap-2">
                 <div className="w-2 h-2 rounded-full bg-accent" />
                 <span>UPLOADED: {stats.uploaded}</span>
              </div>
           </div>
        </div>
        
        <div className="overflow-x-auto">
           <table className="w-full text-left font-mono">
              <thead>
                <tr className="bg-zinc-900/50">
                  <th className="px-10 py-6 text-[10px] text-zinc-500 uppercase italic">01. Asset Name</th>
                  <th className="px-10 py-6 text-[10px] text-zinc-500 uppercase italic">02. Priority</th>
                  <th className="px-10 py-6 text-[10px] text-zinc-500 uppercase italic">03. Style</th>
                  <th className="px-10 py-6 text-[10px] text-zinc-500 uppercase italic">04. Platform</th>
                  <th className="px-10 py-6 text-[10px] text-zinc-500 uppercase italic">05. Status</th>
                  <th className="px-10 py-6 text-[10px] text-zinc-500 uppercase italic text-right">06. Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-900">
                {[...queueVideos, ...pendingVideos, ...successfulVideos, ...failedVideos].slice(0, 15).map((v) => (
                  <tr key={v.id} className="hover:bg-zinc-900 transition-colors cursor-pointer group">
                    <td className="px-10 py-6">
                       <span className="text-xs font-bold text-white uppercase tracking-tight block truncate max-w-[200px]">{v.topic || v.title || 'ARCHIVE_ASSET'}</span>
                    </td>
                    <td className="px-10 py-6">
                       <div className="flex items-center gap-2">
                          <div className={cn("h-1 w-12 bg-zinc-800 rounded-full overflow-hidden")}>
                             <div className="h-full bg-white transition-all" style={{ width: `${v.priority || 50}%` }} />
                          </div>
                          <span className="text-[10px] text-zinc-500">{v.priority || 50}</span>
                       </div>
                    </td>
                    <td className="px-10 py-6">
                       <span className="text-[10px] text-zinc-400 font-bold uppercase">{v.style || 'DEFAULT'}</span>
                    </td>
                    <td className="px-10 py-6">
                       <div className="flex items-center gap-3">
                          {v.platform === 'youtube' && <Youtube className="w-4 h-4 text-accent" />}
                          {v.platform === 'instagram' && <Instagram className="w-4 h-4 text-purple-500" />}
                          {v.platform === 'facebook' && <Facebook className="w-4 h-4 text-blue-500" />}
                          {!v.platform && <Zap className="w-3 h-3 text-zinc-700" />}
                          <span className="text-[10px] text-zinc-500 uppercase">{v.platform || 'System'}</span>
                       </div>
                    </td>
                    <td className="px-10 py-6">
                       <div className="flex items-center gap-2">
                          <div className={cn("w-1.5 h-1.5 rounded-full animate-pulse", 
                             v.status === 'completed' || v.status === 'uploaded' ? "bg-accent" : 
                             v.status === 'failed' ? "bg-error" : 
                             v.status === 'pending' || v.status === 'pending_approval' ? "bg-amber-500" : "bg-blue-500"
                          )} />
                          <span className={cn("text-[9px] font-black uppercase",
                             v.status === 'completed' || v.status === 'uploaded' ? "text-accent" : "text-zinc-500"
                          )}>{v.status}</span>
                       </div>
                    </td>
                    <td className="px-10 py-6 text-right">
                       {v.status === 'pending_approval' ? (
                         <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                            <button onClick={() => handleAction(v.id, 'approve')} className="p-1 px-3 bg-accent text-white rounded text-[9px] font-black uppercase">Approve</button>
                            <button onClick={() => handleAction(v.id, 'reject')} className="p-1 px-3 border border-zinc-800 text-zinc-500 rounded text-[9px] font-black uppercase">Kill</button>
                         </div>
                       ) : (
                         <span className="text-[10px] text-zinc-800">NO_ACTION</span>
                       )}
                    </td>
                  </tr>
                ))}
              </tbody>
           </table>
        </div>
      </section>

      {/* 📜 SYSTEM SIGNAL LOGS */}
      <section className="bg-zinc-950 border border-white/5 rounded-2xl p-10 font-mono shadow-inner shadow-black">
         <div className="flex items-center justify-between mb-8">
            <h3 className="text-xs font-black text-white uppercase tracking-[0.3em] flex items-center gap-2">
               <span className="w-1 h-3 bg-accent" /> System Heartbeat
            </h3>
            <div className="text-[9px] text-zinc-700 uppercase tracking-widest font-bold">Encrypted Node Access • Admin Only</div>
         </div>
         <div className="space-y-3 max-h-[300px] overflow-y-auto custom-scrollbar pr-6">
            {logs.map((log) => (
              <div key={log.id} className="flex gap-8 text-[11px] group border-l border-zinc-900 pl-6 py-1 hover:border-accent transition-colors">
                 <span className="text-zinc-800 tabular-nums font-bold shrink-0">{log.timestamp?.toDate ? log.timestamp.toDate().toLocaleTimeString() : 'SIGNAL'}</span>
                 <div className="flex-1 space-x-4">
                    <span className="text-zinc-500 font-bold uppercase tracking-tighter">[{log.agent || 'SYSTEM'}]</span>
                    <span className="text-zinc-400 group-hover:text-white transition-colors">{" >> "}{log.message || log.action}</span>
                 </div>
              </div>
            ))}
         </div>
      </section>

      {/* 💳 SaaS FOOTER */}
      <footer className="pt-20 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-10 opacity-30 hover:opacity-100 transition-opacity">
         <p className="text-[10px] font-black uppercase tracking-[0.4em] text-white">ViralForge Pro Domination Engine</p>
         <div className="flex items-center gap-12 text-[9px] font-bold text-zinc-500 uppercase tracking-widest">
            <span className="cursor-crosshair hover:text-white">API_LAYER</span>
            <span className="cursor-crosshair hover:text-white">NET_NEURAL</span>
            <span className="cursor-crosshair hover:text-white">AUTH_ENCRYPT</span>
         </div>
         <p className="text-[9px] font-mono text-zinc-700">© 2026 DEEPRA • ALL RIGHTS RESERVED • ENTERPRISE GRADE</p>
      </footer>
    </div>
  );
}

function CountdownTimer({ targetDate }: { targetDate: Date }) {
  const [timeLeft, setTimeLeft] = useState(0);

  useEffect(() => {
    if (!targetDate) return;

    const calculate = () => {
      const diff = Math.max(0, differenceInSeconds(new Date(targetDate), new Date()));
      setTimeLeft(diff);
    };

    calculate();
    const interval = setInterval(calculate, 1000);
    return () => clearInterval(interval);
  }, [targetDate]);

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;

  return (
    <span className={cn(
      "text-[10px] font-bold font-mono tracking-wider",
      timeLeft < 300 ? "text-error animate-pulse" : "text-amber-500"
    )}>
      {minutes}:{seconds.toString().padStart(2, '0')} REAMAINING
    </span>
  );
}

const ArrowRight = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
  </svg>
);
