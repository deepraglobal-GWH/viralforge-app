import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Image as ImageIcon, 
  Wand2, 
  Download, 
  RefreshCw, 
  Type, 
  Palette,
  Layout,
  Loader2
} from 'lucide-react';

export function ThumbnailLab() {
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [thumbnails, setThumbnails] = useState<string[]>([
    'https://picsum.photos/seed/thumb1/1280/720',
    'https://picsum.photos/seed/thumb2/1280/720',
  ]);

  const generateThumbnail = async () => {
    if (!prompt) return;
    setLoading(true);
    try {
      const response = await fetch('/api/thumbnail/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt }),
      });
      
      if (!response.ok) throw new Error('Failed to generate thumbnail');
      
      const data = await response.json();
      setThumbnails([data.image, ...thumbnails]);
    } catch (error) {
      console.error(error);
      // Fallback for demo if API key is missing
      setThumbnails([`https://picsum.photos/seed/${Math.random()}/1280/720`, ...thumbnails]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-white">Thumbnail Lab</h2>
        <p className="text-zinc-400 mt-1">Design high-CTR thumbnails that stop the scroll.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6">
            <div className="flex gap-4 mb-8">
              <div className="relative flex-1">
                <ImageIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500 w-5 h-5" />
                <input
                  type="text"
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="Describe your thumbnail idea..."
                  className="w-full bg-zinc-800 border border-zinc-700 rounded-xl py-4 pl-12 pr-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50 transition-all"
                />
              </div>
              <button
                onClick={generateThumbnail}
                disabled={loading}
                className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white px-8 py-4 rounded-xl font-bold flex items-center gap-2 transition-all"
              >
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Wand2 className="w-5 h-5" />}
                Generate
              </button>
            </div>

            <div className="space-y-6">
              <div className="aspect-video bg-zinc-800 rounded-2xl overflow-hidden border-2 border-blue-600 relative group">
                <img src={thumbnails[0]} alt="Main Preview" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-all flex items-center justify-center gap-4">
                  <button className="p-4 bg-white text-black rounded-full hover:scale-110 transition-all">
                    <Download className="w-6 h-6" />
                  </button>
                  <button className="p-4 bg-white text-black rounded-full hover:scale-110 transition-all">
                    <RefreshCw className="w-6 h-6" />
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-4 gap-4">
                {thumbnails.slice(1).map((thumb, i) => (
                  <div key={i} className="aspect-video rounded-xl overflow-hidden border border-zinc-800 hover:border-zinc-600 transition-all cursor-pointer">
                    <img src={thumb} alt="Variation" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6">
            <h3 className="text-lg font-bold text-white mb-6">Editor Tools</h3>
            <div className="space-y-4">
              <button className="w-full flex items-center gap-3 p-4 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl transition-all">
                <Type className="w-5 h-5 text-blue-400" />
                <span className="font-medium">Add Text Overlay</span>
              </button>
              <button className="w-full flex items-center gap-3 p-4 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl transition-all">
                <Palette className="w-5 h-5 text-purple-400" />
                <span className="font-medium">Color Correction</span>
              </button>
              <button className="w-full flex items-center gap-3 p-4 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl transition-all">
                <Layout className="w-5 h-5 text-emerald-400" />
                <span className="font-medium">Change Layout</span>
              </button>
            </div>
          </div>

          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6">
            <h3 className="text-lg font-bold text-white mb-4">CTR Analysis</h3>
            <div className="space-y-4">
              <div className="p-4 bg-zinc-800/50 rounded-xl border border-zinc-800">
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-zinc-400">Predicted CTR</span>
                  <span className="text-blue-500 font-bold">8.4%</span>
                </div>
                <div className="w-full bg-zinc-800 h-2 rounded-full overflow-hidden">
                  <div className="bg-blue-500 h-full w-[84%]" />
                </div>
              </div>
              <p className="text-xs text-zinc-500 leading-relaxed">
                AI Suggestion: "Increase the contrast of the text and use a more expressive face for better performance."
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
