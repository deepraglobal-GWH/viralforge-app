import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  DollarSign, 
  TrendingUp, 
  Calendar, 
  Clock, 
  Youtube, 
  Instagram, 
  Facebook, 
  Plus, 
  Loader2, 
  AlertCircle,
  MoreVertical,
  ChevronRight,
  Video
} from 'lucide-react';
import { db, auth } from '../lib/firebase';
import { 
  collection, 
  query, 
  orderBy, 
  onSnapshot, 
  addDoc, 
  serverTimestamp, 
  doc, 
  updateDoc 
} from 'firebase/firestore';
import { cn } from '../lib/utils';
import { handleFirestoreError, OperationType } from '../services/error-handler';
import { format, isToday, isThisMonth } from 'date-fns';

interface Earning {
  id: string;
  amount: number;
  platform: 'youtube' | 'instagram' | 'facebook' | 'other';
  date: any;
  projectId?: string;
  views?: number;
  type: 'ad_revenue' | 'affiliate' | 'manual' | 'sponsor';
  status: 'realized' | 'pending';
}

interface Project {
  id: string;
  title: string;
  platform: string;
  views: number;
  earnings: number;
  status: string;
}

export function Earnings() {
  const [earnings, setEarnings] = useState<Earning[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Form State
  const [formData, setFormData] = useState({
    amount: '',
    platform: 'youtube',
    type: 'manual',
    status: 'realized',
    projectId: '',
    views: ''
  });

  useEffect(() => {
    if (!auth.currentUser) return;

    const userId = auth.currentUser.uid;

    // Listen to Earnings
    const earningsQ = query(
      collection(db, 'users', userId, 'earnings'),
      orderBy('date', 'desc')
    );

    const unsubscribeEarnings = onSnapshot(earningsQ, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Earning[];
      setEarnings(data);
      setLoading(prevState => (projects.length > 0 ? false : prevState));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, `users/${userId}/earnings`);
    });

    // Listen to Projects (for performance table)
    const projectsQ = query(
      collection(db, 'users', userId, 'projects'),
      orderBy('createdAt', 'desc')
    );

    const unsubscribeProjects = onSnapshot(projectsQ, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Project[];
      setProjects(data);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, `users/${userId}/projects`);
    });

    return () => {
      unsubscribeEarnings();
      unsubscribeProjects();
    };
  }, []);

  const stats = {
    total: earnings.reduce((acc, curr) => acc + (curr.status === 'realized' ? curr.amount : 0), 0),
    today: earnings.reduce((acc, curr) => {
      const date = curr.date?.toDate ? curr.date.toDate() : new Date(curr.date);
      return acc + (isToday(date) && curr.status === 'realized' ? curr.amount : 0);
    }, 0),
    month: earnings.reduce((acc, curr) => {
      const date = curr.date?.toDate ? curr.date.toDate() : new Date(curr.date);
      return acc + (isThisMonth(date) && curr.status === 'realized' ? curr.amount : 0);
    }, 0),
    pending: earnings.reduce((acc, curr) => acc + (curr.status === 'pending' ? curr.amount : 0), 0),
  };

  const platformStats = ['youtube', 'instagram', 'facebook'].map(p => ({
    name: p,
    amount: earnings.filter(e => e.platform === p && e.status === 'realized').reduce((acc, curr) => acc + curr.amount, 0),
    count: projects.filter(pr => pr.platform?.toLowerCase() === p).length,
    performance: 'stable' // Placeholder for logic
  }));

  const handleAddEarning = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) return;
    setIsSubmitting(true);

    try {
      const earningData = {
        amount: parseFloat(formData.amount),
        platform: formData.platform,
        type: formData.type,
        status: formData.status,
        projectId: formData.projectId || null,
        views: formData.views ? parseInt(formData.views) : null,
        date: serverTimestamp(),
        createdAt: serverTimestamp()
      };

      await addDoc(collection(db, 'users', auth.currentUser.uid, 'earnings'), earningData);
      
      // If linked to a project, update project totals
      if (formData.projectId) {
        const project = projects.find(p => p.id === formData.projectId);
        if (project) {
          await updateDoc(doc(db, 'users', auth.currentUser.uid, 'projects', formData.projectId), {
            earnings: (project.earnings || 0) + parseFloat(formData.amount),
            views: (project.views || 0) + (formData.views ? parseInt(formData.views) : 0),
            updatedAt: serverTimestamp()
          });
        }
      }

      setShowAddModal(false);
      setFormData({ amount: '', platform: 'youtube', type: 'manual', status: 'realized', projectId: '', views: '' });
    } catch (error) {
      console.error("Error adding earning:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-96 text-zinc-500 font-sans">
        <Loader2 className="w-8 h-8 animate-spin mb-4 text-accent" />
        <p className="text-sm font-medium uppercase tracking-widest">Compiling revenue data...</p>
      </div>
    );
  }

  return (
    <div className="space-y-12 pb-20 max-w-7xl mx-auto px-4 md:px-0">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h2 className="text-3xl font-extrabold text-white tracking-tighter uppercase mb-2">Revenue Dashboard</h2>
          <p className="text-zinc-500 font-bold text-[10px] uppercase tracking-[0.3em]">Audited Real-Time Financial Signals</p>
        </div>
        <button 
          onClick={() => setShowAddModal(true)}
          className="bg-accent text-white px-6 py-3 rounded-xl font-extrabold uppercase text-[11px] tracking-widest flex items-center justify-center gap-2.5 hover:bg-accent/90 shadow-xl shadow-accent/20 transition-all active:scale-95"
        >
          <Plus className="w-4 h-4" />
          Log Manual Revenue
        </button>
      </div>

      {/* 1. TOP SUMMARY CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Total Earnings', value: stats.total, icon: DollarSign, color: 'text-accent' },
          { label: 'Today’s Yield', value: stats.today, icon: TrendingUp, color: 'text-white' },
          { label: 'This Month', value: stats.month, icon: Calendar, color: 'text-white' },
          { label: 'Pending Payouts', value: stats.pending, icon: Clock, color: 'text-amber-500' }
        ].map((stat, i) => (
          <div key={i} className="saas-card p-8 flex flex-col justify-between group hover:border-accent/20 transition-all">
            <div className="flex items-center justify-between mb-4">
              <p className="text-[10px] font-extrabold text-zinc-500 uppercase tracking-widest">{stat.label}</p>
              <div className={cn("p-2 rounded-lg bg-zinc-800/50", stat.color.includes('accent') ? "text-accent" : "text-zinc-500")}>
                <stat.icon className="w-4 h-4" />
              </div>
            </div>
            <p className={cn("text-3xl font-extrabold tracking-tight", stat.color)}>
              ${stat.value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
          </div>
        ))}
      </div>

      {/* 2. PLATFORM BREAKDOWN */}
      <section>
        <div className="flex items-center justify-between mb-8">
          <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Platform Distribution</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {platformStats.map((platform) => (
            <div key={platform.name} className="saas-card p-8 relative overflow-hidden group">
               <div className="absolute -right-4 -top-4 opacity-[0.03] group-hover:opacity-[0.05] transition-opacity">
                  {platform.name === 'youtube' && <Youtube className="w-32 h-32" />}
                  {platform.name === 'instagram' && <Instagram className="w-32 h-32" />}
                  {platform.name === 'facebook' && <Facebook className="w-32 h-32" />}
               </div>
               
               <div className="flex items-center gap-3 mb-6 relative">
                  <div className={cn(
                    "p-2.5 rounded-xl",
                    platform.name === 'youtube' ? "bg-red-500/10 text-red-500" :
                    platform.name === 'instagram' ? "bg-purple-500/10 text-purple-500" : "bg-blue-500/10 text-blue-500"
                  )}>
                    {platform.name === 'youtube' && <Youtube className="w-5 h-5" />}
                    {platform.name === 'instagram' && <Instagram className="w-5 h-5" />}
                    {platform.name === 'facebook' && <Facebook className="w-5 h-5" />}
                  </div>
                  <span className="text-sm font-extrabold text-white uppercase tracking-widest">{platform.name}</span>
               </div>

               <div className="space-y-4 relative">
                  <div>
                    <p className="text-[10px] font-bold text-zinc-600 uppercase tracking-widest mb-1">Total Revenue</p>
                    <p className="text-2xl font-extrabold text-white">${platform.amount.toLocaleString()}</p>
                  </div>
                  
                  <div className="flex items-center justify-between pt-4 border-t border-white/5">
                    <div>
                      <p className="text-[9px] font-bold text-zinc-600 uppercase tracking-widest">Content Units</p>
                      <p className="text-sm font-bold text-white">{platform.count} Videos</p>
                    </div>
                    <div className="text-right">
                      <p className="text-[9px] font-bold text-zinc-600 uppercase tracking-widest">Momentum</p>
                      <span className="text-[10px] font-extrabold text-accent uppercase tracking-widest inline-flex items-center gap-1">
                        <TrendingUp className="w-3 h-3" /> Optimal
                      </span>
                    </div>
                  </div>
               </div>
            </div>
          ))}
        </div>
      </section>

      {/* 3. VIDEO PERFORMANCE TABLE */}
      <section>
        <div className="flex items-center justify-between mb-8">
          <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Video Performance</h3>
          <span className="text-[10px] font-bold text-zinc-600 uppercase tracking-widest px-3 py-1 bg-zinc-900 border border-white/5 rounded-full">
            Top Performing Assets
          </span>
        </div>
        <div className="saas-card overflow-hidden">
          {projects.length > 0 ? (
            <div className="overflow-x-auto custom-scrollbar">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-white/[0.03]">
                    <th className="px-8 py-5 text-[10px] font-extrabold text-zinc-500 uppercase tracking-widest">Video Title</th>
                    <th className="px-8 py-5 text-[10px] font-extrabold text-zinc-500 uppercase tracking-widest">Platform</th>
                    <th className="px-8 py-5 text-[10px] font-extrabold text-zinc-500 uppercase tracking-widest text-right">Views</th>
                    <th className="px-8 py-5 text-[10px] font-extrabold text-zinc-500 uppercase tracking-widest text-right">Est. Earnings</th>
                    <th className="px-8 py-5 text-[10px] font-extrabold text-zinc-500 uppercase tracking-widest text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/[0.02]">
                  {projects.filter(p => !['idea', 'rejected'].includes(p.status)).map((project) => (
                    <tr key={project.id} className="clean-table-row group">
                      <td className="px-8 py-6">
                        <span className="text-xs font-bold text-white uppercase tracking-wider truncate max-w-[300px] block">
                          {project.title}
                        </span>
                      </td>
                      <td className="px-8 py-6">
                        <div className="flex items-center gap-2.5">
                          {project.platform === 'youtube' && <Youtube className="w-4 h-4 text-red-500" />}
                          {project.platform === 'instagram' && <Instagram className="w-4 h-4 text-purple-500" />}
                          {project.platform === 'facebook' && <Facebook className="w-4 h-4 text-blue-500" />}
                          <span className="text-[10px] font-bold text-zinc-600 uppercase tracking-widest">{project.platform || 'General'}</span>
                        </div>
                      </td>
                      <td className="px-8 py-6 text-right font-mono text-xs text-white">
                        {(project.views || 0).toLocaleString()}
                      </td>
                      <td className="px-8 py-6 text-right font-mono text-xs text-accent font-bold">
                        ${(project.earnings || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </td>
                      <td className="px-8 py-6 text-right">
                        <span className={cn(
                          "px-2 px-1 text-[9px] font-extrabold rounded uppercase tracking-wider",
                          project.status === 'published' ? "bg-accent/10 text-accent border border-accent/20" : "bg-zinc-800 text-zinc-500"
                        )}>
                          {project.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="p-24 text-center flex flex-col items-center">
              <AlertCircle className="w-12 h-12 text-zinc-800 mb-4" />
              <p className="text-xs font-bold text-zinc-600 uppercase tracking-[0.2em]">No earnings data available yet</p>
              <p className="text-[10px] text-zinc-700 uppercase tracking-widest mt-2 font-bold italic">Process videos and log earnings to see momentum</p>
            </div>
          )}
        </div>
      </section>

      {/* Manual Input Modal */}
      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div 
               initial={{ opacity: 0 }}
               animate={{ opacity: 1 }}
               exit={{ opacity: 0 }}
               onClick={() => setShowAddModal(false)}
               className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div 
               initial={{ opacity: 0, scale: 0.95, y: 20 }}
               animate={{ opacity: 1, scale: 1, y: 0 }}
               exit={{ opacity: 0, scale: 0.95, y: 20 }}
               className="relative w-full max-w-lg saas-card p-8 bg-zinc-900 shadow-2xl overflow-hidden"
            >
              <div className="absolute top-0 right-0 p-12 opacity-5 pointer-events-none">
                <DollarSign className="w-64 h-64 text-accent" />
              </div>
              
              <div className="flex items-center justify-between mb-8 relative">
                <div className="flex items-center gap-3">
                   <div className="p-2 bg-accent/10 rounded-lg">
                      <DollarSign className="w-5 h-5 text-accent" />
                   </div>
                   <h3 className="text-lg font-extrabold text-white uppercase tracking-tight">Log Entry</h3>
                </div>
                <button onClick={() => setShowAddModal(false)} className="text-zinc-500 hover:text-white transition-colors">
                   <Plus className="w-6 h-6 rotate-45" />
                </button>
              </div>

              <form onSubmit={handleAddEarning} className="space-y-6 relative">
                 <div className="grid grid-cols-2 gap-6">
                    <div className="space-y-2">
                       <label className="text-[10px] font-extrabold text-zinc-500 uppercase tracking-widest ml-1">Amount (USD)</label>
                       <input 
                        type="number" 
                        step="0.01"
                        required
                        value={formData.amount}
                        onChange={e => setFormData({...formData, amount: e.target.value})}
                        className="w-full bg-zinc-950 border border-white/5 rounded-xl px-4 py-3 text-white font-bold focus:outline-none focus:ring-2 focus:ring-accent/50 transition-all font-mono"
                        placeholder="0.00"
                       />
                    </div>
                    <div className="space-y-2">
                       <label className="text-[10px] font-extrabold text-zinc-500 uppercase tracking-widest ml-1">Context (Type)</label>
                       <select 
                        value={formData.type}
                        onChange={e => setFormData({...formData, type: e.target.value as any})}
                        className="w-full bg-zinc-950 border border-white/5 rounded-xl px-4 py-3 text-white font-bold text-xs uppercase tracking-widest focus:outline-none focus:ring-2 focus:ring-accent/50 appearance-none cursor-pointer"
                       >
                          <option value="ad_revenue">Ad Revenue</option>
                          <option value="affiliate">Affiliate</option>
                          <option value="manual">Manual Entry</option>
                          <option value="sponsor">Sponsorship</option>
                       </select>
                    </div>
                 </div>

                 <div className="grid grid-cols-2 gap-6">
                    <div className="space-y-2">
                       <label className="text-[10px] font-extrabold text-zinc-500 uppercase tracking-widest ml-1">Platform</label>
                       <select 
                        value={formData.platform}
                        onChange={e => setFormData({...formData, platform: e.target.value as any})}
                        className="w-full bg-zinc-950 border border-white/5 rounded-xl px-4 py-3 text-white font-bold text-xs uppercase tracking-widest focus:outline-none focus:ring-2 focus:ring-accent/50 appearance-none cursor-pointer"
                       >
                          <option value="youtube">YouTube</option>
                          <option value="instagram">Instagram</option>
                          <option value="facebook">Facebook</option>
                          <option value="other">Other</option>
                       </select>
                    </div>
                    <div className="space-y-2">
                       <label className="text-[10px] font-extrabold text-zinc-500 uppercase tracking-widest ml-1">Status</label>
                       <select 
                        value={formData.status}
                        onChange={e => setFormData({...formData, status: e.target.value as any})}
                        className="w-full bg-zinc-950 border border-white/5 rounded-xl px-4 py-3 text-white font-bold text-xs uppercase tracking-widest focus:outline-none focus:ring-2 focus:ring-accent/50 appearance-none cursor-pointer"
                       >
                          <option value="realized">Realized</option>
                          <option value="pending">Pending</option>
                       </select>
                    </div>
                 </div>

                 <div className="space-y-2">
                    <label className="text-[10px] font-extrabold text-zinc-500 uppercase tracking-widest ml-1 flex items-center gap-2">
                       <Video className="w-3 h-3" />
                       Link to Video Asset (Optional)
                    </label>
                    <select 
                     value={formData.projectId}
                     onChange={e => setFormData({...formData, projectId: e.target.value})}
                     className="w-full bg-zinc-950 border border-white/5 rounded-xl px-4 py-3 text-white font-bold text-xs uppercase tracking-widest focus:outline-none focus:ring-2 focus:ring-accent/50 appearance-none cursor-pointer"
                    >
                       <option value="">General Platform Earning</option>
                       {projects.filter(p => !['idea'].includes(p.status)).map(p => (
                         <option key={p.id} value={p.id}>{p.title}</option>
                       ))}
                    </select>
                 </div>

                 {formData.projectId && (
                    <div className="space-y-2">
                       <label className="text-[10px] font-extrabold text-zinc-500 uppercase tracking-widest ml-1">Incremental Views</label>
                       <input 
                        type="number" 
                        value={formData.views}
                        onChange={e => setFormData({...formData, views: e.target.value})}
                        className="w-full bg-zinc-950 border border-white/5 rounded-xl px-4 py-3 text-white font-bold focus:outline-none focus:ring-2 focus:ring-accent/50 transition-all font-mono"
                        placeholder="0"
                       />
                    </div>
                 )}

                 <div className="pt-4">
                    <button 
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full bg-accent text-white py-4 rounded-xl font-extrabold uppercase text-[11px] tracking-widest hover:bg-accent/90 shadow-xl shadow-accent/20 transition-all active:scale-95 flex items-center justify-center gap-3"
                    >
                      {isSubmitting ? <Loader2 className="w-5 h-5 animate-spin" /> : <ChevronRight className="w-5 h-5" />}
                      Commute Entry
                    </button>
                 </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
