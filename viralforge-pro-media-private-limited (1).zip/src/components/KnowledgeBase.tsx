import React from 'react';
import { motion } from 'framer-motion';
import { 
  Database, 
  Search, 
  Plus, 
  FileText, 
  Globe, 
  MessageSquare, 
  Tag,
  Clock,
  ExternalLink,
  Brain,
  Zap
} from 'lucide-react';
import { cn } from '@/src/lib/utils';

const memories = [
  {
    id: 'truth-1',
    title: 'THE OMEGA TRUTH: System Reality',
    type: 'System Core',
    content: 'ViralForge is a powerful automation tool, but not a magic engine. Growth depends on content quality and consistency.',
    tags: ['Reality', 'Core', 'Truth'],
    updatedAt: 'Just now'
  },
  {
    id: 'truth-2',
    title: 'THE OMEGA TRUTH: Monetization',
    type: 'System Core',
    content: 'Infinite Yield is a UI concept for visualization. Real revenue is synthesized only through viral content, massive views, and enabled monetization APIs.',
    tags: ['Money', 'Monetization'],
    updatedAt: 'Just now'
  },
  {
    id: 'billion-1',
    title: 'THE $1B BLUEPRINT: Strategic Mindset',
    type: 'Billionaire Guide',
    content: 'To reach a multi-billion valuation, focus on assets over cash. Build a content machine that runs without you. Scalability is everything.',
    tags: ['Mindset', 'Strategy', 'Billionaire'],
    updatedAt: 'Just now'
  },
  {
    id: '1',
    title: 'Niche: AI Tech Trends 2026',
    type: 'Research',
    content: 'Deep analysis of generative video models and their impact on YouTube retention.',
    tags: ['AI', 'Tech', 'Retention'],
    updatedAt: '2 hours ago'
  },
  {
    id: '2',
    title: 'Competitor: TechCrunch Style',
    type: 'Competitor Intel',
    content: 'Analysis of TechCrunch editing style, hook patterns, and thumbnail color palettes.',
    tags: ['Editing', 'Branding'],
    updatedAt: '5 hours ago'
  },
  {
    id: '3',
    title: 'Policy: YouTube AdSense 2026',
    type: 'Policy',
    content: 'Updated guidelines for AI-generated content monetization and disclosure requirements.',
    tags: ['Legal', 'Monetization'],
    updatedAt: '1 day ago'
  },
  {
    id: '4',
    title: 'Asset: High-Energy Background Music',
    type: 'Asset',
    content: 'Collection of royalty-free high-energy tracks suitable for tech reviews.',
    tags: ['Audio', 'Assets'],
    updatedAt: '2 days ago'
  }
];

export function KnowledgeBase() {
  return (
    <div className="space-y-8 relative z-10">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white flex items-center gap-3">
            <Database className="text-blue-500 w-8 h-8" />
            Knowledge Base
          </h2>
          <p className="text-zinc-400 mt-1">The collective memory and asset library of the ViralForge X engine.</p>
        </div>
        <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-semibold flex items-center gap-2 transition-all shadow-lg shadow-blue-600/20 active:scale-95">
          <Plus className="w-5 h-5" />
          Add Knowledge
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6">
            <h3 className="text-sm font-bold text-zinc-500 uppercase tracking-wider mb-4">Memory Categories</h3>
            <nav className="space-y-1">
              {[
                { label: 'All Memories', icon: Database, count: 142, active: true },
                { label: 'Research', icon: Globe, count: 45 },
                { label: 'Competitor Intel', icon: Search, count: 28 },
                { label: 'Scripts', icon: FileText, count: 34 },
                { label: 'Policy Guard', icon: Brain, count: 12 },
                { label: 'Assets', icon: Tag, count: 23 },
              ].map((item, i) => (
                <button
                  key={i}
                  className={cn(
                    "w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all",
                    item.active ? "bg-blue-600/10 text-blue-500" : "text-zinc-400 hover:bg-zinc-800 hover:text-zinc-200"
                  )}
                >
                  <div className="flex items-center gap-3">
                    <item.icon className="w-4 h-4" />
                    <span className="text-sm font-medium">{item.label}</span>
                  </div>
                  <span className="text-[10px] font-bold opacity-50">{item.count}</span>
                </button>
              ))}
            </nav>
          </div>

          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6">
            <h3 className="text-sm font-bold text-zinc-500 uppercase tracking-wider mb-4">System Memory</h3>
            <div className="space-y-4">
              <div className="flex justify-between text-xs">
                <span className="text-zinc-500">Storage Used</span>
                <span className="text-white">4.2 GB / 10 GB</span>
              </div>
              <div className="w-full bg-zinc-800 h-1.5 rounded-full overflow-hidden">
                <div className="bg-blue-600 h-full w-[42%]" />
              </div>
              <p className="text-[10px] text-zinc-600 leading-relaxed">
                Memory is automatically indexed and shared across all AI agents for maximum context awareness.
              </p>
            </div>
          </div>
        </div>

        <div className="lg:col-span-3 space-y-8">
          <div className="flex flex-col md:flex-row gap-6">
            <div className="relative flex-1">
              <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-zinc-500 w-5 h-5" />
              <input
                type="text"
                placeholder="Search the collective intelligence..."
                className="w-full bg-zinc-900 border border-white/5 rounded-2xl py-5 pl-16 pr-6 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50 transition-all font-mono uppercase tracking-widest text-xs"
              />
            </div>
            
            <div className="flex bg-zinc-900 p-1.5 rounded-2xl border border-white/5 hardware-border">
               <input 
                 type="text" 
                 placeholder="Paste URL to Ingest..." 
                 className="bg-transparent border-none outline-none px-6 text-xs text-white font-mono uppercase tracking-widest w-64"
               />
               <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-bold text-[10px] uppercase tracking-widest flex items-center gap-2 shadow-lg shadow-blue-600/20 active:scale-95 transition-all">
                  <Zap className="w-4 h-4 fill-white/20" />
                  Ingest
               </button>
            </div>
          </div>

          <div className="p-8 bg-gradient-to-br from-blue-600/10 via-zinc-900 to-zinc-900 border border-blue-600/20 rounded-[2.5rem] relative overflow-hidden group">
             <div className="absolute top-0 right-0 p-10 opacity-5 group-hover:opacity-10 transition-opacity">
                <Brain className="w-40 h-40 text-blue-500 animate-pulse" />
             </div>
             <div className="relative z-10">
                <h3 className="text-2xl font-display text-white uppercase tracking-tight mb-4">Neuro-Ingestion Active</h3>
                <p className="text-zinc-500 text-xs leading-relaxed max-w-2xl font-light italic">
                  "System is currently absorbing new data from 12 regional market signals. Contextual relevance is increasing across all specialized agents."
                </p>
                <div className="mt-8 flex items-center gap-6">
                   <div className="flex -space-x-3">
                      {[1,2,3,4].map(i => (
                        <div key={i} className="w-10 h-10 rounded-full border-2 border-zinc-900 bg-zinc-800 flex items-center justify-center overflow-hidden">
                           <img src={`https://picsum.photos/seed/${i+42}/40/40`} alt="Source" />
                        </div>
                      ))}
                      <div className="w-10 h-10 rounded-full border-2 border-zinc-900 bg-blue-600 flex items-center justify-center text-[10px] font-bold text-white">
                         +8
                      </div>
                   </div>
                   <span className="text-[10px] font-mono text-zinc-600 uppercase tracking-widest">Active Data Streams Found</span>
                </div>
             </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {memories.map((memory) => (
              <motion.div
                key={memory.id}
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6 hover:border-blue-600/30 transition-all group"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-zinc-800 rounded-lg group-hover:bg-blue-600/10 transition-colors">
                      <FileText className="w-5 h-5 text-zinc-500 group-hover:text-blue-500" />
                    </div>
                    <div>
                      <h4 className="text-white font-bold group-hover:text-blue-400 transition-colors">{memory.title}</h4>
                      <span className="text-[10px] font-bold text-blue-500 uppercase tracking-widest">{memory.type}</span>
                    </div>
                  </div>
                  <button className="text-zinc-600 hover:text-white transition-colors">
                    <ExternalLink className="w-4 h-4" />
                  </button>
                </div>
                
                <p className="text-zinc-400 text-sm leading-relaxed mb-6">
                  {memory.content}
                </p>

                <div className="flex items-center justify-between pt-4 border-t border-zinc-800">
                  <div className="flex gap-2">
                    {memory.tags.map((tag, j) => (
                      <span key={j} className="text-[10px] bg-zinc-800 text-zinc-500 px-2 py-1 rounded border border-zinc-700">
                        #{tag}
                      </span>
                    ))}
                  </div>
                  <div className="flex items-center gap-1 text-[10px] text-zinc-600">
                    <Clock className="w-3 h-3" />
                    {memory.updatedAt}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          <button className="w-full py-4 border-2 border-dashed border-zinc-800 rounded-3xl text-zinc-500 font-bold hover:border-zinc-700 hover:text-zinc-400 transition-all">
            Load More Memories
          </button>
        </div>
      </div>
    </div>
  );
}
