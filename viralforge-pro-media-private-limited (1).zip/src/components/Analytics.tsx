import React from 'react';
import { motion } from 'framer-motion';
import { 
  BarChart3, 
  TrendingUp, 
  Users, 
  PlayCircle, 
  Clock,
  Search,
  MousePointer2,
  Share2
} from 'lucide-react';

import { cn } from '@/src/lib/utils';

export function Analytics() {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-white">Analytics</h2>
        <p className="text-zinc-400 mt-1">Deep dive into your performance and AI-driven insights.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {[
          { label: 'Impressions', value: '4.2M', icon: Search, color: 'text-blue-500' },
          { label: 'CTR', value: '8.2%', icon: MousePointer2, color: 'text-blue-500' },
          { label: 'Avg. Duration', value: '4:12', icon: Clock, color: 'text-purple-500' },
          { label: 'Shares', value: '12.4K', icon: Share2, color: 'text-pink-500' },
        ].map((stat, i) => (
          <div key={i} className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl">
            <div className="flex items-center gap-3 mb-4">
              <div className={cn("p-2 bg-zinc-800 rounded-lg", stat.color)}>
                <stat.icon className="w-5 h-5" />
              </div>
              <span className="text-zinc-400 text-sm font-medium">{stat.label}</span>
            </div>
            <p className="text-2xl font-bold text-white">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6">
          <h3 className="text-xl font-bold text-white mb-6">Retention Curve</h3>
          <div className="aspect-video bg-zinc-800/50 rounded-xl border border-zinc-800 flex items-center justify-center relative overflow-hidden">
            {/* Simulated Chart */}
            <svg className="w-full h-full px-4" viewBox="0 0 400 200">
              <path 
                d="M 0 50 Q 50 40 100 80 T 200 100 T 300 120 T 400 150" 
                fill="none" 
                stroke="#3b82f6" 
                strokeWidth="3" 
              />
              <path 
                d="M 0 50 Q 50 40 100 80 T 200 100 T 300 120 T 400 150 L 400 200 L 0 200 Z" 
                fill="url(#gradient)" 
                opacity="0.1" 
              />
              <defs>
                <linearGradient id="gradient" x1="0" x2="0" y1="0" y2="1">
                  <stop offset="0%" stopColor="#3b82f6" />
                  <stop offset="100%" stopColor="transparent" />
                </linearGradient>
              </defs>
            </svg>
            <div className="absolute top-4 right-4 bg-blue-600/10 text-blue-500 text-[10px] font-bold px-2 py-1 rounded border border-blue-600/20">
              AI DETECTED DROP AT 0:45
            </div>
          </div>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6">
          <h3 className="text-xl font-bold text-white mb-6">Audience Insights</h3>
          <div className="space-y-6">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-zinc-400">New Viewers</span>
                <span className="text-white">65%</span>
              </div>
              <div className="w-full bg-zinc-800 h-2 rounded-full overflow-hidden">
                <div className="bg-blue-500 h-full w-[65%]" />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-zinc-400">Returning Viewers</span>
                <span className="text-white">35%</span>
              </div>
              <div className="w-full bg-zinc-800 h-2 rounded-full overflow-hidden">
                <div className="bg-blue-400 h-full w-[35%]" />
              </div>
            </div>
            <div className="pt-4 p-4 bg-zinc-800/30 rounded-xl border border-zinc-800">
              <p className="text-sm text-zinc-400 leading-relaxed">
                <span className="text-white font-bold">AI Insight:</span> Your audience is highly engaged with technical content. Consider making a follow-up video on "AI Automation Tools" to capitalize on current interest.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
