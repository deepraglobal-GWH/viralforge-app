import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Wand2, Save, Copy, Loader2, Sparkles, AlertCircle, CheckCircle } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { cn } from '@/src/lib/utils';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export function ScriptStudio() {
  const [topic, setTopic] = useState('');
  const [script, setScript] = useState('');
  const [loading, setLoading] = useState(false);
  const [explanation, setExplanation] = useState('');

  const generateScript = async () => {
    if (!topic) return;
    setLoading(true);
    try {
      const response = await ai.models.generateContent({
        model: "gemini-2.0-flash",
        contents: `Generate a viral YouTube script for the topic: "${topic}". 
        The script must be optimized for retention and 10x engagement.
        Include:
        1. A high-retention hook (first 15 seconds).
        2. Main content breakdown with rapid-fire value delivery.
        3. Call to action.
        4. Technical explanation of why this script will perform well based on neural retention patterns.
        
        Return as JSON with fields: "script" (string) and "explanation" (string).`,
        config: { responseMimeType: "application/json" }
      });
      
      const data = JSON.parse(response.text || '{}');
      setScript(data.script || '');
      setExplanation(data.explanation || '');
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-12 relative z-10 pb-20">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8">
        <div>
          <div className="flex items-center gap-3 mb-4">
            <div className="px-2 py-1 bg-omega-blue/10 border border-omega-blue/20 rounded text-[10px] font-mono text-omega-blue uppercase tracking-widest">Neural Link Active</div>
            <div className="px-2 py-1 bg-omega-gold/10 border border-omega-gold/20 rounded text-[10px] font-mono text-omega-gold uppercase tracking-widest">High Retention</div>
          </div>
          <h2 className="text-5xl font-display text-white uppercase tracking-tighter">Script Studio</h2>
          <p className="text-zinc-500 font-mono text-xs uppercase tracking-[0.2em] mt-2">Architecting High-Retention Content via Neural Synthesis</p>
        </div>
        
        <div className="flex items-center gap-4">
          <button 
            onClick={() => {
              navigator.clipboard.writeText(script);
            }}
            className="p-5 bg-zinc-900/50 border border-white/5 text-zinc-500 hover:text-omega-blue rounded-2xl transition-all active:scale-95 hardware-border group"
          >
            <Copy className="w-6 h-6 group-hover:scale-110 transition-transform" />
          </button>
          <button 
            className="p-5 bg-zinc-900/50 border border-white/5 text-zinc-500 hover:text-omega-gold rounded-2xl transition-all active:scale-95 hardware-border group"
          >
            <Save className="w-6 h-6 group-hover:scale-110 transition-transform" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        <div className="lg:col-span-2 space-y-8">
          <div className="glass-card p-10 border-omega-blue/20">
            <div className="flex flex-col md:flex-row gap-6 mb-10">
              <div className="relative flex-1 group">
                <Sparkles className="absolute left-6 top-1/2 -translate-y-1/2 text-zinc-500 w-6 h-6 group-focus-within:text-omega-blue transition-colors" />
                <input
                  type="text"
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  placeholder="What's your video about?"
                  className="w-full bg-zinc-900/50 border border-white/5 rounded-2xl py-6 pl-16 pr-6 text-white focus:outline-none focus:ring-2 focus:ring-omega-blue/50 transition-all hardware-border font-mono uppercase tracking-widest text-sm"
                />
              </div>
              <button
                onClick={generateScript}
                disabled={loading}
                className="bg-omega-blue hover:bg-blue-700 disabled:opacity-50 text-white px-10 py-6 rounded-2xl font-bold flex items-center justify-center gap-3 transition-all active:scale-95 shadow-2xl shadow-omega-blue/20 uppercase tracking-widest text-xs"
              >
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Wand2 className="w-5 h-5 fill-white/20" />}
                Synthesize
              </button>
            </div>

            <div className="relative group">
              <div className="absolute top-0 right-0 p-6 opacity-5 pointer-events-none group-focus-within:opacity-10 transition-opacity">
                <Sparkles className="w-32 h-32 text-omega-blue" />
              </div>
              <textarea
                value={script}
                onChange={(e) => setScript(e.target.value)}
                placeholder="Neural synthesis output will appear here..."
                className="w-full h-[600px] bg-black/40 border border-white/5 rounded-[2rem] p-10 text-zinc-300 font-mono text-sm leading-relaxed focus:outline-none focus:ring-2 focus:ring-omega-blue/30 transition-all resize-none hardware-border"
              />
            </div>
          </div>
        </div>

        <div className="space-y-8">
          <div className="glass-card p-8 border-omega-gold/20">
            <div className="flex items-center gap-4 mb-8">
              <div className="w-12 h-12 bg-omega-gold/10 rounded-2xl flex items-center justify-center border border-omega-gold/20">
                <Sparkles className="text-omega-gold w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-display text-white uppercase tracking-tight">AI Transparency</h3>
                <p className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Neural Reasoning</p>
              </div>
            </div>
            
            {explanation ? (
              <div className="space-y-8">
                <p className="text-zinc-500 text-sm leading-relaxed font-light italic">
                  "{explanation}"
                </p>
                <div className="p-6 bg-omega-gold/5 border border-omega-gold/10 rounded-2xl">
                  <div className="flex justify-between items-end mb-4">
                    <h4 className="text-omega-gold text-[10px] font-mono uppercase tracking-widest">Hook Strength</h4>
                    <span className="text-white font-mono text-sm">92%</span>
                  </div>
                  <div className="w-full bg-zinc-900 h-1 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: '92%' }}
                      transition={{ duration: 1.5 }}
                      className="bg-omega-gold h-full shadow-[0_0_10px_rgba(255,170,0,0.5)]" 
                    />
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-20 opacity-20">
                <AlertCircle className="w-16 h-16 text-zinc-500 mb-4" />
                <p className="text-zinc-500 text-[10px] font-mono uppercase tracking-widest text-center">Awaiting Synthesis</p>
              </div>
            )}
          </div>

          <div className="glass-card p-8 border-omega-blue/20">
            <h3 className="text-xl font-display text-white uppercase tracking-tight mb-8">Optimization Matrix</h3>
            <div className="space-y-6">
              {[
                "Strong opening hook",
                "Clear value proposition",
                "Natural transitions",
                "Engagement triggers",
                "Compelling CTA"
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-4 group">
                  <div className={cn(
                    "w-6 h-6 rounded-lg border flex items-center justify-center transition-all duration-500",
                    script ? "bg-omega-blue border-omega-blue shadow-[0_0_10px_rgba(0,102,255,0.5)]" : "border-white/10 bg-white/5"
                  )}>
                    {script && <CheckCircle className="w-3 h-3 text-white" />}
                  </div>
                  <span className={cn(
                    "text-[10px] font-mono uppercase tracking-widest transition-colors",
                    script ? "text-white" : "text-zinc-600"
                  )}>{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
